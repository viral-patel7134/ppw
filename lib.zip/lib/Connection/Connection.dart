class Connection {
  static var version = "0.0.0.8";

  // static var socketaddress = "http://192.168.0.105:3000";
  // static var url = "http://192.168.0.105/gaurav/proplayerwar/public/api";

  // static var socketaddress = "http://3.7.68.14:9000";
  // static var url = "http://3.7.68.14/gaurav/proplayerwar/public";
  // static var url = "http://3.7.68.14";

  // static var urlnew = "http://ppw.rightclickeducation.net";
  // static var urlnew = "http://192.168.0.105:8088";
  // static var urlnew = "http://192.168.1.175:8088";
  // static var urlnewsocket = "http://192.168.1.175:5000";
  // static var urlnew = "http://192.168.0.113:8088";
  static var urlnew = "http://52.66.246.126:80";
  static var urlnewsocket = "http://52.66.246.126:5000";
  
//   static var urlnew = "http://103.158.172.76:60708";
//  static var urlnewsocket = "http://103.158.172.76:5000";
  static var loginsadd = "$urlnew/api/user_master/useradd";
  static var loginsupdate = "$urlnew/api/user_master/userupdate";
  static var tokenupdate = "$urlnew/api/user_master/tokenupdate";
  static var homepage = "$urlnew/api/homepage/homepage";
  static var team = "$urlnew/api/team/team";
  static var teamadd = "$urlnew/api/team/teamadd";
  static var teamlist = "$urlnew/api/team/teamlist";
  static var teamplayerlist = "$urlnew/api/team/teamplayerlist";

  static var getdata = "$urlnew/api/user_master/commondata";

  static var followdata = "$urlnew/api/follow/followgetdata";
  static var follow = "$urlnew/api/follow/followadd";
  static var followerlist = "$urlnew/api/follow/followerlist";
  static var followinglist = "$urlnew/api/follow/followinglist";

  static var gamerequestadd = "$urlnew/api/game/gamerequestadd";
  static var gameverifylist = "$urlnew/api/game/gameverifylist";
  static var tournament = "$urlnew/api/tournament/tournament";

  static var walletdata = "$urlnew/api/wallet/walletdata";
  static var walletadd = "$urlnew/api/wallet/walletadd";
  static var walletaddext = "$urlnew/api/wallet/walletaddext";
  static var withdrawrequest = "$urlnew/api/wallet/withdrawrequest";
  static var matchadd = "$urlnew/api/tournament/matchadd";
  static var playerlist = "$urlnew/api/team/playerlist";
  static var myupcomingmatcheslist = "$urlnew/api/homepage/myupcomingmatcheslist";
  static var teamfrienddelete = "$urlnew/api/team/teamfrienddelete";
  static var topplayer = "$urlnew/api/user_master/topplayer";
  static var requestaccept = "$urlnew/api/team/requestaccept";

  static var sendrequest = "$urlnew/api/homepage/sendrequest";

    // static var homepage = "$urlnew/api/homepage.php";

  // static var follow = "$urlnew/api/followadd.php";
  // static var followdata = "$urlnew/api/followgetdata.php";
  // static var team = "$urlnew/api/team.php";
  // static var teamadd = "$urlnew/api/teamadd.php";
  // static var gamerequestadd = "$urlnew/api/gamerequestadd.php";
  // static var walletadd = "$urlnew/api/walletadd.php";
  // static var walletdata = "$urlnew/api/walletdata.php";
  // static var withdrawrequest = "$urlnew/api/withdrawrequest.php";

  // static var gameverifylist = "$urlnew/api/gameverifylist.php";

  // static var getdata = "$urlnew/api/GetData.php";
  // static var loginsadd = "$urlnew/api/useradd.php";
  // static var loginsupdate = "$urlnew/api/userupdate.php";
  // static var homebanner = "$url/api/banner/list";
  // static var menu = "$url/api/profile/summary";
  // static var topplayer = "$url/api/top/leaderboard";
  // static var follow = "$url/api/profile/follow";
  // static var unfollow = "$url/api/profile/unfollow";

  static var bannerImagePath = "$urlnew/images/banner/";
  static var gameImagePath = "$urlnew/images/game";

  static var profileImagePath = "$urlnew/images/user/50x50/";

  static var teamImagePath = "$urlnew/images/team/";

  static var apkpath = 'https://rightclicksolution.in/ppw.apk';
  static int apksize = 0;
  static var urlmain = 'http://ppw.rightclickeducation.net/api/GetData.php';
  static var localapi = false;
}
