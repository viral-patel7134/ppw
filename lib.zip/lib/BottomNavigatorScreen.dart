import 'package:flutter/material.dart';

import 'package:proplayerwar/pages/ProfilePage.dart';
import 'package:proplayerwar/pages/TopPlayer.dart';
import 'package:proplayerwar/pages/MyUpcomingMatches.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';

class BottomNavigatorScreen extends StatefulWidget {
  @override
  _BottomNavigatorScreenState createState() => _BottomNavigatorScreenState();
}

class _BottomNavigatorScreenState extends State<BottomNavigatorScreen> {
  int _currentindex = 0;
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: _currentindex,
      // type: BottomNavigationBarType.fixed,
      iconSize: 30,

      // selectedFontSize: 20,
      // unselectedFontSize: 15,
      selectedItemColor: Colors.red,
      unselectedItemColor: Colors.black,
      backgroundColor: AppColor.whitecolor,
      type: BottomNavigationBarType.fixed,
      items: [
        BottomNavigationBarItem(
            icon: Icon(
              Icons.home_outlined,
            ),
            title: Text(
              "Home",
              style: AppTextStyle.blacktextstylelight,
            )),
        BottomNavigationBarItem(
            icon: Icon(Icons.sports_esports_outlined),
            title: Text(
              "My Upcoming",
              style: AppTextStyle.blacktextstylelight,
            )),
            
        BottomNavigationBarItem(
            icon: Icon(Icons.search),
            title: Text(
              "Players",
              style: AppTextStyle.blacktextstylelight,
            )),
        BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            title: Text(
              "Me",
              style: AppTextStyle.blacktextstylelight,
            )),
      ],
      onTap: (index) {
        setState(() async {
          _currentindex = index;
          if (_currentindex == 0) {
            // Navigator.push(
            //     context, MaterialPageRoute(builder: (c) => MenuPage()));
          } else if (_currentindex == 1) {
            Navigator.push(
                context, MaterialPageRoute(builder: (c) => MyUpcomingMatchespage()));
          } else if (_currentindex == 2) {
            Navigator.push(
                context, MaterialPageRoute(builder: (c) => TopPlayerpage()));
          } else if (_currentindex == 3) {
            // SharedPreferences prefs = await SharedPreferences.getInstance();
            // prefs.remove("userjsondata");
            // prefs.remove("user_id");

            // ValidationClass.userdata = Map();
            // ValidationClass.userid = 0;
            // ValidationClass.jwttoken = "";
            // ValidationClass.token = "";

            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      ProfilePage(ValidationClass.userlist[0]),
                ));
          }
        });
      },
    );
  }
}
