import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_downloader/flutter_downloader.dart';

import 'package:proplayerwar/login/MobileLogin.dart';
import 'package:proplayerwar/model/FollowerModel.dart';
import 'package:proplayerwar/model/HomePageModel.dart';
import 'package:proplayerwar/model/LeaderBoardModel.dart';
import 'package:proplayerwar/model/JoinModel.dart';
import 'package:proplayerwar/model/NotificationModel.dart';
import 'package:proplayerwar/model/PlayerModel.dart';
import 'package:proplayerwar/model/TeamPlayerModel.dart';
import 'package:proplayerwar/model/WalletModel.dart';
import 'package:proplayerwar/model/matchdetailsModel.dart';
import 'package:proplayerwar/pages/HomePage.dart';
import 'package:proplayerwar/pages/splashscreen.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'Connection/Connection.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await FlutterDownloader.initialize(
  //     debug: true // optional: set false to disable printing logs to console
  //     );
  //  await Firebase.initializeApp();
  FlutterDownloader.initialize(
      debug: true // optional: set false to disable printing logs to console
      );
  await Firebase.initializeApp();

  // runApp(MyApp());

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<WalletModel>(create: (_) => WalletModel()),
        ChangeNotifierProvider<MatchdetailsModel>(
            create: (_) => MatchdetailsModel()),
        ChangeNotifierProvider<HomePageModel>(create: (_) => HomePageModel()),
        ChangeNotifierProvider<JoinModel>(create: (_) => JoinModel()),
        ChangeNotifierProvider<FollowerModel>(create: (_) => FollowerModel()),
        ChangeNotifierProvider<PlayerModel>(create: (_) => PlayerModel()),
        ChangeNotifierProvider<LeaderModel>(create: (_) => LeaderModel()),
        ChangeNotifierProvider<TeamPlayerModel>(
            create: (_) => TeamPlayerModel()),
        ChangeNotifierProvider<NotificationModel>(
            create: (_) => NotificationModel()),
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isLogin = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    checkLogin();
  }

  checkLogin() async {
    if (await FirebaseAuth.instance.currentUser.uid != null) {
      setState(() {
        isLogin = true;
      });
      print("inside is login");
    }

    print(FirebaseAuth.instance.currentUser.phoneNumber);

    print("is login $isLogin");
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    _tokenupdate(token) async {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        ValidationClass.userdata = json.decode(prefs.getString("userjsondata"));
        ValidationClass.userid = ValidationClass.settoint(
            ValidationClass.userdata['user_id'].toString());
      } catch (e) {}

      print("token ValidationClass ${ValidationClass.token}");
      var response = http.post(Connection.tokenupdate, body: {
        "user_id": ValidationClass.userid.toString(),
        "token": token.toString()
      }
          // headers: {
          //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
          // },
          );
      print("success ${token.toString()}");
      print("success ${ValidationClass.userid}");

      // print(response.body);
    }

    final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
    _tokenupdate(_firebaseMessaging.getToken().toString());
    // if (ValidationClass.token !=_firebaseMessaging.getToken().toString())
    //   {
    //     _tokenupdate(_firebaseMessaging.getToken().toString());
    //   }
    // _firebaseMessaging.subscribeToTopic('Proplayerusers');

    _firebaseMessaging.requestNotificationPermissions();

    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        print("onMessage: $message");
        // _showItemDialog(message);
      },

      // onBackgroundMessage: (Map<String, dynamic> message) async {
      //   if (message.containsKey('data')) {
      //     // Handle data message
      //     // final dynamic data = message['data'];
      //   }

      //   if (message.containsKey('notification')) {
      //     // Handle notification message
      //     // final dynamic notification = message['notification'];
      //   }

      // //   // Or do other work.
      // },
      onLaunch: (Map<String, dynamic> message) async {
        print("onLaunch: $message");
        // _navigateToItemDetail(message);
      },
      onResume: (Map<String, dynamic> message) async {
        print("onResume: $message");
        // _navigateToItemDetail(message);
      },
    );

    _firebaseMessaging.getToken().then((String token) async {
      assert(token != null);

      print("estt" + token);
      ValidationClass.token = token;
    });

    return MaterialApp(
        // debugShowCheckedModeBanner: false,
        title: "Pro Player War",
        theme: ThemeData(
          iconTheme: IconThemeData(size: 14, color: Colors.black),
        ),
        // home: Homepage(),
        home: SplashScreen(
          seconds: 5,
          navigateAfterSeconds: (isLogin) ? Homepage() : MobileLogin(),

          backgroundColor: Colors.white,
          loaderColor: Colors.red,
          backimagename: "assets/home/splashscreen.gif",
// useLoader: false,
        ));
  }
}
