import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


import 'package:image_picker/image_picker.dart';

import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/Connection/Connection.dart';

import 'package:proplayerwar/model/LoginModel.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:proplayerwar/pages/HomePage.dart';
import 'package:http/http.dart' as http;

import '../util/AppColor.dart';

// ignore: must_be_immutable
class LoginFormPage extends StatefulWidget {
  var mobile = "";
  LoginFormPage(this.mobile);

  @override
  _LoginFormPageState createState() => _LoginFormPageState();
}

final _nameController = TextEditingController();
final _emailController = TextEditingController();

// final _birthDateController = TextEditingController();

class _LoginFormPageState extends State<LoginFormPage> {
  ProgressDialog pr;
  List<LoginModel> newitm = [];
  var id,
      userid,
      name,
      mobile,
      gender,
      birthdate,
      country,
      image,
      pubgid,
      pubgname,
      pubglevel;

  String base64Image = '';
  File _image;
  bool isverify = false;
  String imgpath;
  bool isedit = false;
  Future getImage() async {
    // ignore: deprecated_member_use
    var image = await ImagePicker.pickImage(
        source: ImageSource.gallery, maxWidth: 150, maxHeight: 150);
    setState(() {
      _image = image;
      // print("image path ${image.path}");
      List<int> imageBytes = image.readAsBytesSync();
      base64Image = base64Encode(imageBytes);

      imgpath = null;
    });
  }

  // bool _value = false;

  Map userdatamap = Map();
  String names = "", starId = "", email = "", profilePic = "";
  int userId = 0;

  @override
  void initState() {
    super.initState();
    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);
    _sharepref();

    _nameController.text = ValidationClass.username;
    _emailController.text = ValidationClass.email;
  }

  _sharepref() async {
    try {
      if (ValidationClass.userimg.toString() != "") {
        http.Response response1 = await http.get(
          Connection.profileImagePath + ValidationClass.userimg.toString(),
        );
        base64Image = base64.encode(response1.bodyBytes);
        imgpath = "";
        isedit = true;
      }
    } catch (e) {}
    setState(() {
      // names = widget.name;
      // email = widget.email;
      // profilePic = widget.profile;
      // _nameController.text = names;
      // _birthDateController.text = birth_date;
      // print("userId $userId");
    });
  }

  String choice;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whitecolor,
      appBar: AppBar(
        backgroundColor: AppColor.primaryColor,
        title: Text(
          "Profile",
          style: TextStyle(fontSize: 20.0, color: Colors.white),
        ),
      ),
      body: ListView(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: 25,
                    ),

                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: imgpath == null
                          ? _image == null
                              ? Center(
                                  child: Container(
                                    height: 150,
                                    width: 150,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.withOpacity(.1),
                                      borderRadius: BorderRadius.circular(100),
                                      // image: DecorationImage(
                                      //   image: AssetImage('assets/pubg1.png'),
                                      // ),
                                    ),
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: GestureDetector(
                                        child: Center(
                                          child: Icon(
                                            Icons.camera_alt,
                                            color: Colors.white,
                                            size: 52,
                                          ),
                                        ),
                                        onTap: getImage,
                                      ),
                                    ),
                                  ),
                                )
                              : Center(
                                  child: Container(
                                    height: 150,
                                    width: 150,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.withOpacity(.6),
                                      borderRadius: BorderRadius.circular(120),
                                      image: DecorationImage(
                                          image: FileImage(_image),
                                          fit: BoxFit.cover),
                                    ),
                                    child: Align(
                                      alignment: Alignment.bottomRight,
                                      child: GestureDetector(
/*
                                        child: Center(
                                          child: Icon(Icons.camera_alt,
                                            color: Colors.white, size: 52,),
                                        ),
*/
                                        onTap: getImage,
                                      ),
                                    ),
                                  ),
                                )
                          : Center(
                              child: Container(
                                height: 150,
                                width: 150,
                                decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(.6),
                                  borderRadius: BorderRadius.circular(120),
                                  image: DecorationImage(
                                      image: NetworkImage(Connection
                                              .profileImagePath
                                              .toString() +
                                          ValidationClass.userimg.toString()),
                                      fit: BoxFit.cover),
                                ),
                                child: Align(
                                  alignment: Alignment.bottomRight,
                                  child: GestureDetector(
/*
                                        child: Center(
                                          child: Icon(Icons.camera_alt,
                                            color: Colors.white, size: 52,),
                                        ),
*/
                                    onTap: getImage,
                                  ),
                                ),
                              ),
                            ),
                    ),

//                     _image == null
//                         ? Center(
//                             child: Container(
//                               height: 200,
//                               width: 200,
//                               decoration: BoxDecoration(
//                                 color: Colors.grey.withOpacity(.1),
//                                 borderRadius: BorderRadius.circular(100),
//                                 image: DecorationImage(
//                                   image: AssetImage(''),
//                                 ),
//                               ),
//                               child: Align(
//                                 alignment: Alignment.center,
//                                 child: GestureDetector(
//                                   child: Center(
//                                     child: Icon(
//                                       Icons.camera_alt,
//                                       color: Colors.white,
//                                       size: 52,
//                                     ),
//                                   ),
//                                   onTap: getImage,
//                                 ),
//                               ),
//                             ),
//                           )
//                         : Center(
//                             child: Container(
//                               height: 200,
//                               width: 200,
//                               decoration: BoxDecoration(
//                                 color: Colors.grey.withOpacity(.6),
//                                 borderRadius: BorderRadius.circular(120),
//                                 image: DecorationImage(
//                                     image: FileImage(_image),
//                                     fit: BoxFit.cover),
//                               ),
//                               child: Align(
//                                 alignment: Alignment.bottomRight,
//                                 child: GestureDetector(
// /*
//                           child: Center(
//                             child: Icon(Icons.camera_alt,
//                               color: Colors.white, size: 52,),
//                           ),
// */
//                                   onTap: getImage,
//                                 ),
//                               ),
//                             ),
//                           ),
                  ],
                ),
                SizedBox(
                  height: 30,
                ),
                Center(
                    child: Text(
                        'Upload your best selfie to make friends easier !')),
                SizedBox(
                  height: 50,
                ),
                Divider(
                  height: 16,
                  color: Colors.grey,
                ),
                TextField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'User Name',
                    border: InputBorder.none,
                    hintStyle: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                Divider(
                  height: 16,
                  color: Colors.grey,
                ),
                TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    border: InputBorder.none,
                    hintStyle: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                Divider(
                  height: 16,
                  color: Colors.grey,
                ),
                // TextField(
                //   controller: _pubgController,
                //   keyboardType: TextInputType.number,
                //   decoration: InputDecoration(
                //     labelText: 'pubg Id',
                //     border: InputBorder.none,
                //     hintStyle: TextStyle(
                //         color: Colors.black, fontWeight: FontWeight.bold),
                //   ),
                // ),
                // Divider(
                //   height: 16,
                //   color: Colors.grey,
                // ),
                // TextField(
                //   controller: _birthDateController,
                //   onTap: () {
                //     // FocusScope.of(context).requestFocus(new FocusNode());
                //     _selectDate(context);
                //   },
                //   style: TextStyle(fontWeight: FontWeight.bold),
                //   cursorColor: Colors.black87,
                //   decoration: InputDecoration(
                //     //prefixIcon: Icon(FontAwesomeIcons.birthdayCake, size: 18,),
                //     hintText: "Date of Birth",
                //     border: InputBorder.none,
                //   ),
                // ),
                // Divider(
                //   height: 16,
                //   color: Colors.grey,
                // ),
                // Row(
                //   children: <Widget>[
                //     Row(
                //       children: <Widget>[
                //         Radio(
                //           value: 'Male',
                //           groupValue: _radioValue,
                //           onChanged: radioButtonChanges,
                //         ),
                //       ],
                //     ),
                //     Text(
                //       "Male",
                //     ),
                //     VerticalDivider(
                //       width: 80,
                //     ),
                //     Radio(
                //       value: 'Female',
                //       groupValue: _radioValue,
                //       onChanged: radioButtonChanges,
                //     ),
                //     Text(
                //       "Female",
                //     ),
                //   ],
                // ),
                // Divider(
                //   height: 15,
                //   color: Colors.grey,
                // ),
                // SizedBox(
                //   height: 100,
                // ),

                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                  child: GestureDetector(
                    child: Container(
                      alignment: Alignment.center,
                      height: 60,
                      width: MediaQuery.of(context).size.width,
                      color: AppColor.primaryColor,
                      // decoration: BoxDecoration(
                      //   borderRadius: BorderRadius.all(Radius.circular(20.0)),
                      //   gradient: LinearGradient(
                      //     colors: <Color>[AppColor.primaryColor,AppColor.primaryColor],
                      //   ),
                      // ),
                      padding: const EdgeInsets.all(12.0),
                      child: Text(
                        'Submit',
                        style: AppTextStyle.button,
                      ),
                    ),
                    onTap: () async {
                      if (base64Image == "") {
                        // Fluttertoast.showToast(msg: "oops.. Missing image....");
                        ValidationClass.onBasicAlertPressed(
                            context, "Validation", "oops.. Missing Image ....");
                      } else if (_nameController.text == "") {
                        // Fluttertoast.showToast(msg: "oops.. Missing name....");
                        ValidationClass.onBasicAlertPressed(
                            context, "Validation", "oops.. Missing name....");
                      } else if (_emailController.text == "") {
                        // Fluttertoast.showToast(msg: "oops.. Missing Email....");
                        ValidationClass.onBasicAlertPressed(
                            context, "Validation", "oops.. Missing Email....");
                      } else {
                        mobilelogin();
                      }

                      // if (buttonlabel == 'VERIFY OTP') {
                      //   _signInWithPhoneNumber();
                      // } else {
                      //   _verifyPhoneNumber();

                      //   setState(() {
                      //     buttonlabel = 'VERIFY OTP';
                      //     labelmobile = "ENTER OTP";

                      //     count = true;
                      //   });
                      // }
                    },
                  ),
                  // child: GestureDetector(
                  //   child: ClipRRect(
                  //     borderRadius: BorderRadius.circular(13),
                  //     child: Container(
                  //       height: 40,
                  //       decoration: BoxDecoration(
                  //         gradient: LinearGradient(
                  //             begin: FractionalOffset.topLeft,
                  //             end: FractionalOffset.bottomRight,
                  //             colors: [AppColor.gradient2, AppColor.gradient1]),
                  //       ),
                  //       child: Center(
                  //           child: Text(
                  //         'Submit',
                  //         style: TextStyle(
                  //             fontWeight: FontWeight.bold,
                  //             fontSize: 16,
                  //             color: Colors.white),
                  //       )),
                  //     ),
                  //   ),
                  //   onTap: () {
                  //     mobileLogin();
                  //   },
                  // ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // _showAlert(String title, String message) {
  //   showDialog(
  //     context: context,
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: new Text(title),
  //         content: new Text(message),
  //         actions: <Widget>[
  //           new FlatButton(
  //             child: new Text("Okay"),
  //             onPressed: () {
  //               Navigator.of(context).pop();
  //             },
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  Future<List<LoginModel>> mobilelogin() async {
    if (_nameController.text.toString() == "" ||
        _nameController.text.toString() == null) {
      //return Navigator.pushReplacement(context, MaterialPageRoute(builder: (c)=>HomePage()));
      print("empty name");
    }
    var response = await http.post(Connection.loginsupdate, body: {
      //if(loginType == "Google"){

      'mobile': widget.mobile,
      'image': base64Image,
      "step": '2',
      'name': _nameController.text.toString(),
      'email': _emailController.text.toString()
      /* 'login_type': 'Username',
      'email': 'grv@gmail.com',
      'password': '12345678',*/

//      }else if(loginType == "Facebook"){
//        'login_type': 'Facebook',
//        'facebook_email': emailid,
//        'facebook_id': uid.toString(),
//        'image': profilepics,
//        'facebook_mobile': "",
      // }
    });
    // var decodedData = json.decode(response.body);
    var decodedData = json.decode(utf8.decode(response.bodyBytes));
    print("data api == > :} $decodedData");

    // var status = decodedData['status'];
    // var user_type = decodedData['user_type'];

    /*   if(user_type == 'Old'){
      return     Navigator.pushReplacement(context, MaterialPageRoute(builder: (c) => MainPage()));
    }*/

    var webresp = decodedData["Table"];
    var flg = decodedData["Table1"];

    if (flg[0]["flg"] == "2") {
      ValidationClass.onBasicAlertPressed(
          context, "Validation", "Same Name Already Exists");
      return null;
    } else {
      // id = webresp["id"];
      userid = webresp[0]["user_id"];
      name = webresp[0]["name"];
      mobile = webresp[0]["mobile"];
      gender = webresp[0]["gender"];
      birthdate = webresp[0]["birth_date"];
      // country = webresp["country"];
      image = webresp[0]["image"];

      // pubgid = webresp["pubg_id"];
      // pubgname = webresp["pubg_name"];
      // pubglevel = webresp["pubg_level"];

      var jwt = webresp[0]["jwt"];

      // var ppwid = webresp["ppw_id"];
      var token = webresp[0]["token"];

      Map map = Map();
      // map['id'] = id;

      map['user_id'] = userid;
      map['name'] = name;
      map['mobile'] = mobile;
      map['email'] = webresp[0]["email"];
      map['gender'] = gender;
      map['birth_date'] = birthdate;
      // map['country'] = country;
      map['image'] = image;

      // map['pubgid'] = pubgid;
      // map['pubgname'] = pubgname;
      // map['pubg_level'] = pubglevel;

      map['jwt'] = jwt;
      map['token'] = token;
      // map['ppw_id'] = ppwid;

      String userdata = json.encode(map);
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString("userjsondata", userdata);
      prefs.setString("user_id", webresp[0]["user_id"].toString());

      ValidationClass.userdata = map;
      ValidationClass.jwttoken = ValidationClass.settostring(
          ValidationClass.userdata['jwt'].toString());
      ValidationClass.userid = userid;
      ValidationClass.username = name;
      // ValidationClass.token = ValidationClass.settostring(
      //     ValidationClass.userdata['token'].toString());

      ValidationClass.userimg = ValidationClass.settostring(
          ValidationClass.userdata['image'].toString());

      ValidationClass.mobile = ValidationClass.settostring(
          ValidationClass.userdata['mobile'].toString());

      ValidationClass.email = ValidationClass.settostring(
          ValidationClass.userdata['email'].toString());

      if (isedit == true) {
        Navigator.pop(context);
      } else {
        return Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (c) => Homepage()));
      }
    }
     return null;
  }
  // DateTime selectedDate = DateTime.now();
  // DateTime currentdate = DateTime.now();
  // String formatted;

  // Future<Null> _selectDate(BuildContext context) async {
  //   print("current date : $currentdate");
  //   final DateTime picked = await showDatePicker(
  //       context: context,
  //       initialDate: currentdate,
  //       firstDate: DateTime(1925),
  //       lastDate: currentdate);

  //   if (picked != null && picked != selectedDate)
  //     setState(() {
  //       selectedDate = picked;

  //       var formatter = new DateFormat('yyyy-MM-dd');
  //       formatted = formatter.format(picked);
  //       print('formated date: $formatted');
  //       _birthDateController.text = formatted;
  //       print(picked);
  //     });
  // }
}
