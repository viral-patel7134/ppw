import 'dart:convert';

import 'package:country_pickers/country.dart';
import 'package:country_pickers/country_pickers.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/AutoUpdate.dart';
import 'package:proplayerwar/Connection/Connection.dart';

import 'package:proplayerwar/login/LoginFormPage.dart';
import 'package:proplayerwar/pages/HomePage.dart';
import 'package:proplayerwar/model/LoginModel.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:http/http.dart' as http;
import 'package:update_app/update_app.dart';

class MobileLogin extends StatefulWidget {
  @override
  _MobileLoginState createState() => _MobileLoginState();
}

class _MobileLoginState extends State<MobileLogin> {
  String message = '';
  String _verificationId;

  var mob;
  ProgressDialog pr;

  bool islogin = false;
  final _mobileController = TextEditingController();
  bool checkBoxValue = false;
  double height;
  double width;
  double pixelRatio;
  bool large;
  bool _enablebutton = false;
  String labelmobile = 'MOBILE NO';
  String buttonlabel = 'SEND OTP';
  bool count = false;

  @override
  void initState() {
    super.initState();
    print("inside mobile Login page");
    // if (Connection.localapi == true) {
    //   getpreference();
    // } else {
    //   getJSONData();
    // }

    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);
  }

  Future<List<dynamic>> getJSONData() async {
    print('getJSONData');
    List<dynamic> _profilelist = [];
    try {
      var res;

      print('before SettingsGetData'+ DateTime.now().toString());
      res = await http.post(
        Connection.urlmain.toString(),
        body: {"SpName": "SettingsGetData", "SearchParam": "1=1"},
        // headers: {
        //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // },
      );

      print("response" + res.body);
      print('after SettingsGetData'+ DateTime.now().toString());
      var decodedData = json.decode(res.body);
      _profilelist = decodedData;
      var version = _profilelist[0]["Version"].toString();
      var url = _profilelist[0]["url"].toString();
      var socketurl = _profilelist[0]["socketurl"].toString();
      var apkpath = _profilelist[0]["apkpath"].toString();
      var apksize =
          ValidationClass.settoint(_profilelist[0]["apksize"].toString());

      Connection.urlnew = url.toString();
      Connection.urlnewsocket = socketurl.toString();
      Connection.apkpath = apkpath.toString();
      Connection.apksize = apksize;

      if (Connection.version.toString() != version.toString()) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.remove("user_id");
        prefs.remove("userjsondata");

        ValidationClass.userdata = Map();
        ValidationClass.userid = 0;
        ValidationClass.jwttoken = "";
        ValidationClass.token = "";

        await Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => AutoUpdate(),
            ));
      } else {
        getpreference();
      }
      // print("data : ${decodedData['match_played']}");

      // matchplayed = decodedData['match_played'];
      // matchkills = decodedData['total_kills'];
      // matchprizewon = decodedData['win_prize'];

      // for (var i in decodedData) {
      //   print("inside");
      //   MenuProfileModel s = MenuProfileModel(
      //       matchplayed: i["match_played"],
      //       totalkills: i["total_kills"],
      //       winprizes: i["win_prize"]);

      //   setState(() {
      //     profilelist.add(s);
      //   });
      // }

      // final int statusCode = res.statusCode;

      // var resBody;
      // if (statusCode < 200 || statusCode > 400) {
      //   resBody = [];
      // }

      // if (res.body == "null") {
      //   resBody = [];
      // } else {
      //   resBody = json.decode(res.body);
      // }

      // setState(() {
      //   profilelist = decodedData;
      // });

      // print(decodedData.toString());
    } catch (e) {
      print('exeception' + e.message.toString());
      // return "Occur Error...";
      // getpreference();
    }
    print('end SettingsGetData'+ DateTime.now().toString());

    return _profilelist;
  }

  void download() async {
    var name = await UpdateApp.updateApp(
        url: "https://mofada.cn/apks/example.apk", appleId: "375380948");
    print(name);

    setState(() {});
  }

  Future<String> getpreference() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      setState(() {
        ValidationClass.userdata = json.decode(prefs.getString("userjsondata"));
        ValidationClass.userid = ValidationClass.settoint(
            ValidationClass.userdata['user_id'].toString());

        ValidationClass.jwttoken = ValidationClass.settostring(
            ValidationClass.userdata['jwt'].toString());

        // ValidationClass.token = ValidationClass.settostring(
        //     ValidationClass.userdata['token'].toString());

        ValidationClass.username = ValidationClass.settostring(
            ValidationClass.userdata['name'].toString());

        ValidationClass.userimg = ValidationClass.settostring(
            ValidationClass.userdata['image'].toString());

        ValidationClass.email = ValidationClass.settostring(
            ValidationClass.userdata['email'].toString());

        ValidationClass.mobile = ValidationClass.settostring(
            ValidationClass.userdata['mobile'].toString());

        ValidationClass.ingamename = ValidationClass.settostring(
            ValidationClass.userdata['pubgname'].toString());
      });
      if (ValidationClass.settoint(ValidationClass.userid.toString()) == 0) {
      } else {
        await Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => Homepage(),
            ));
      }
      setState(() {
        islogin = true;
      });
    } catch (e) {
      setState(() {
        islogin = true;
      });
    }
    return "Success";
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    pixelRatio = MediaQuery.of(context).devicePixelRatio;
    large = false;
    //_medium =  ResponsiveWidget.isScreenMedium(width, pixelRatio);
    return
        Stack(
            children: <Widget>[
              Image.asset(
                "assets/home/login.png",
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.cover,
              ),
              Scaffold(
                backgroundColor: Colors.transparent,
                appBar: AppBar(
                  backgroundColor: AppColor.primaryColor,
                  title: Row(
                    children: <Widget>[
                      Icon(
                        Icons.lock,
                        size: 20,
                      ),
                      SizedBox(
                        width: 5.0,
                      ),
                      Text(
                        "Login",
                        style: TextStyle(fontSize: 23.0, color: Colors.white),
                      )
                      // AppTextStyle.textWithStroke(
                      //     "Login", 23.0, 3.0, Colors.white, Colors.red),
                    ],
                  ),
                ),
                body: ListView(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0, bottom: 20.0),
                      child: Container(
                        color: Colors.transparent,
                        height: 200,
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: Image.asset("assets/icon/icon.png"),
                      ),
                    ),
                    Visibility(
                      visible:  buttonlabel == 'VERIFY OTP' ? false : true,
                                          child: ListTile(
                        onTap: _openCountryPickerDialog,
                        title: _buildDialogItem(_selectedDialogCountry),
                      ),
                    ),
                    ListTile(
                      // onTap: _openCountryPickerDialog,
                      title: phoneTextFormField(),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    ListTile(
                      // onTap: _openCountryPickerDialog,
                      title: button(),
                    ),
                  ],
                ),
              ),
            ],
          );
  }

  Widget phoneTextFormField() {
    return Container(
      color: Colors.white,
      child: TextFormField(
        style: AppTextStyle.textfromfieldstyle,
        maxLength: 10,
        decoration: InputDecoration(
          counterText: '',
          counterStyle: TextStyle(fontSize: 0),
          fillColor: Colors.white,
          contentPadding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
          // border: new OutlineInputBorder(
          //   borderRadius: new BorderRadius.circular(10.0),
          //   borderSide: new BorderSide(),
          // ),
        ),
        keyboardType: TextInputType.number,
        controller: _mobileController,
        onChanged: (value) {
          if (_mobileController.text.length >= 5 &&
              labelmobile == "MOBILE NO") {
            setState(() {
              _enablebutton = true;
              count = true;
            });
          } else if (_mobileController.text.length == 4 &&
              labelmobile == "SEND OTP") {
            setState(() {
              _enablebutton = true;
              count = true;
            });
          } else if (_mobileController.text.length == 6 &&
              buttonlabel == "VERIFY OTP") {
            setState(() {
              _enablebutton = true;
              count = true;
            });
          } else {
            setState(() {
              _enablebutton = false;
              count = false;
            });
          }
          setState(() {});
        },
      ),
    );
  }

  Widget button() {
    return GestureDetector(
      child: Container(
        alignment: Alignment.center,
        height: height / 15,
        width: MediaQuery.of(context).size.width * .70,
        color: _enablebutton == true ? Color(0xffFF1493) : Color(0xffA9A9A9),
        // decoration: BoxDecoration(
        //   borderRadius: BorderRadius.all(Radius.circular(20.0)),
        //   gradient: LinearGradient(
        //     colors: <Color>[AppColor.primaryColor,AppColor.primaryColor],
        //   ),
        // ),
        padding: const EdgeInsets.all(12.0),
        child: Text(
          buttonlabel,
          style: AppTextStyle.button,
        ),
      ),
      onTap: () async {
        if (_enablebutton == true) {
          // mob = "${countrycode.toString()}${_mobileController.text}";
           //login();
          if (buttonlabel == 'VERIFY OTP') {
           _signInWithPhoneNumber();
            
     
          } else {
            _verifyPhoneNumber();
            setState(() {
              buttonlabel = 'VERIFY OTP';
              labelmobile = "ENTER OTP";

              count = true;
            });
          } 
        }
      },
    );
  }

  Country _selectedDialogCountry =
      CountryPickerUtils.getCountryByPhoneCode('91');

  void _openCountryPickerDialog() => showDialog(
        context: context,
        builder: (context) => Theme(
            data: Theme.of(context).copyWith(
                primaryColor: Colors.pink,
                dialogBackgroundColor: AppColor.whitecolor),
            child: CountryPickerDialog(
                titlePadding: EdgeInsets.all(8.0),
                searchCursorColor: Colors.pinkAccent,
                searchInputDecoration: InputDecoration(
                    hintText: 'Search...',
                    hintStyle: AppTextStyle.blacktextstylelight),
                isSearchable: true,
                title: Text('Select your phone code',
                    style: AppTextStyle.blacktextstyle4),
                onValuePicked: (Country country) {
                  print("object=> ${country.phoneCode}");
                  setState(() {
                    _selectedDialogCountry = country;
                    countrycode = country.phoneCode;
                  });
                },
                itemBuilder: _buildDialogItem)),
      );
  var countrycode = '+91';
  Widget _buildDialogItem(Country country) => (count = false)
      ? Container(
          height: 1,
          width: 1,
        )
      : Container(
          child: Row(
            children: <Widget>[
              CountryPickerUtils.getDefaultFlagImage(country),
              SizedBox(width: 8.0),
              Text(
                "+${country.phoneCode}",
                style: AppTextStyle.whitetextstyle3,
              ),
              SizedBox(width: 8.0),
              Flexible(
                  child: Text(
                country.name,
                style: AppTextStyle.whitetextstyle3,
              )),
            ],
          ),
        );

  // Example code of how to verify phone number
  void _verifyPhoneNumber() async {
    // var firebaseAuth = await FirebaseAuth.instance;

    print("inside verify");
    setState(() {
      message = '';
    });
    final PhoneVerificationCompleted verificationCompleted =
        (AuthCredential phoneAuthCredential) {
      FirebaseAuth _auth = FirebaseAuth.instance;

      _auth.signInWithCredential(phoneAuthCredential);
      setState(() {
        print(
            "Received phone auth credential: ${phoneAuthCredential.providerId}");
        // Navigator.pushReplacement(
        //   context,
        //   MaterialPageRoute(builder: (context) => Homepage()),
        // );

        login();
        _mobileController.text = "";
        message = 'Received phone auth credential: $phoneAuthCredential';
      });

      print("verificatopm success");
    };

    final PhoneVerificationFailed verificationFailed = (authException) {
      print(
          "Phone number verification failed. Code: ${authException.code}. Message: ${authException.message}");
      setState(() {
        message =
            'Phone number verification failed. Code: ${authException.code}. Message: ${authException.message}';
      });
    };

    final PhoneCodeSent codeSent =
        (String verificationId, [int forceResendingToken]) async {
//      widget._scaffold.showSnackBar(const SnackBar(
//        content: Text('Please check your phone for the verification code.'),
//      ));
      print("chec code sned to devide $verificationId");
      mob = "${countrycode.toString()}${_mobileController.text}";
      _mobileController.text = "";
      setState(() {
        _verificationId = verificationId;
      });
    };

    final PhoneCodeAutoRetrievalTimeout codeAutoRetrievalTimeout =
        (String verificationId) {
      _verificationId = verificationId;
    };

    print("mobile ${countrycode.toString()}${_mobileController.text}");
    FirebaseAuth _auth = FirebaseAuth.instance;

    await _auth.verifyPhoneNumber(
        phoneNumber:
            "+${countrycode.toString()}${_mobileController.text}", //_mobileController.text,
    timeout: const Duration(minutes: 1),
    verificationCompleted: verificationCompleted,
    verificationFailed: verificationFailed,
    codeSent: codeSent,
    codeAutoRetrievalTimeout: codeAutoRetrievalTimeout);
  }


  void _signInWithPhoneNumber() async {
    FirebaseAuth _auth = FirebaseAuth.instance;

    print(
        "_mobileController.text ${_mobileController.text} _verificationId $_verificationId ");

    final AuthCredential credential = PhoneAuthProvider.getCredential(
      verificationId: _verificationId,
      smsCode: _mobileController.text.toString().trim(),
    );
    final user = (await _auth.signInWithCredential(credential)).user;
   
    setState(() {
      if (user != null) {
        message = 'Successfully signed in, uid: ' + user.uid;
        print("inside succes ");
        login();
      } else {
        message = 'Sign in failed';
        print("inside failed ");
      }
    });
  }

  List<LoginModel> newitm = [];
  var id,
      userid,
      name,
      mobile,
      gender,
      birthdate,
      image,
      pubgid,
      pubgname,
      pubglevel;

  Future<List<LoginModel>> login() async {
    print("mob $mob");
    await pr.show();
    print('Connection.loginsadd' + Connection.loginsadd.toString());
    try {
      var response = await http.post(Connection.loginsadd, body: {
        'mobile': mob
         
      }, headers: {
        'Content-type': 'application/x-www-form-urlencoded'
      });
      print("status cpde ${response.statusCode}");
      print('response.bodyBytes ${response.bodyBytes}');
      var decodedData = json.decode(utf8.decode(response.bodyBytes));
      print("data api == > :} $decodedData");

      // var status = decodedData['status'];
      var usertype = decodedData[0]['user_type'].toString();
      var webresp = decodedData[0];
      if (usertype == 'New') {
        pr.hide().then((isHidden) {
          print(isHidden);
        });
      
        return Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (c) => LoginFormPage(mob)));
      }

      // var webresp = decodedData[0];

      userid = webresp["user_id"];
      name = webresp["name"];
      mobile = webresp["mobile"];

      gender = webresp["gender"];
      birthdate = webresp["birth_date"];

      image = webresp["image"];

      var jwt = webresp["jwt"];

      var token = webresp["token"];

      Map map = Map();

      map['user_id'] = userid;
      map['name'] = name;
      map['mobile'] = mobile;
      map['email'] = webresp["email"];
      map['gender'] = gender;
      map['birth_date'] = birthdate;

      map['image'] = image;

      map['jwt'] = jwt;
      map['token'] = token;

      String userdata = json.encode(map);
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString("userjsondata", userdata);
      prefs.setString("user_id", webresp["user_id"].toString());

      ValidationClass.userdata = map;
      ValidationClass.jwttoken = ValidationClass.settostring(
          ValidationClass.userdata['jwt'].toString());

      ValidationClass.token = ValidationClass.settostring(
          ValidationClass.userdata['token'].toString());

      ValidationClass.mobile = ValidationClass.settostring(
          ValidationClass.userdata['mobile'].toString());

      ValidationClass.email = ValidationClass.settostring(
          ValidationClass.userdata['email'].toString());

      ValidationClass.userimg = ValidationClass.settostring(
          ValidationClass.userdata['image'].toString());

      ValidationClass.userid = userid;
      ValidationClass.username = name;

      pr.hide().then((isHidden) {
        print(isHidden);
      });

       Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => Homepage(),
          ));
    } catch (e) {
      pr.hide().then((isHidden) {
        print(isHidden);
      });
    }
    return newitm;
  }
}
