import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/Connection/Connection.dart';

import 'package:proplayerwar/model/TeamPlayerModel.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;

class PlayerRequest extends StatefulWidget {
  final data, matchid;
  PlayerRequest(this.data, this.matchid);
  @override
  _PlayerRequestState createState() => _PlayerRequestState(data, matchid);
}

class _PlayerRequestState extends State<PlayerRequest> {
  final data, matchid;
  _PlayerRequestState(this.data, this.matchid);

  ProgressDialog pr;

  Future<List<dynamic>> listfriendfuture;
  var flag = false;
  var indexnew = 0;

  List listplayer;
  @override
  void initState() {
    super.initState();

    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);

    listfriendfuture = convertlist(data);
    listplayer = data;

    Provider.of<TeamPlayerModel>(context, listen: false)
        .refreshPlayer(listplayer);
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 0,
      backgroundColor:AppColor.headerColor,
      insetPadding: EdgeInsets.only(top: 120, left: 40, right: 40, bottom: 120),
      child: Stack(
        children: <Widget>[
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // DrawerHeader(
              //   decoration: BoxDecoration(color: Colors.red),
              //   margin: EdgeInsets.all(0.0),
              //   padding: EdgeInsets.all(0.0),
              //   child: TextField(
              //     autofocus: false,
              //     decoration: InputDecoration(
              //       contentPadding: EdgeInsets.all(9.0),
              //       border: InputBorder.none,
              //       hintText: 'Please enter text',
              //     ),
              //   ),
              // ),
              // SizedBox(
              //   height: 1,
              // ),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: Container(
                  // color: AppColor.headerColor,
                  decoration: BoxDecoration(
                    // border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.only(topLeft:Radius.circular(15.0),topRight:Radius.circular(15.0)),
                  color: Colors.greenAccent,
                  ),
                  child: TextField(

                    style: AppTextStyle.whitetextstyle1,
                    autofocus: false,
                    enabled: false,

                    decoration: InputDecoration(
                        contentPadding:  EdgeInsets.all(15.0),
                        border: InputBorder.none,
                        hintText: 'Player List',
                        hintStyle: TextStyle(color: Colors.black87)),
                  textAlign: TextAlign.center,
                  ),
                ),
              ),
              Expanded(
                child: _friendFuture(),
              ),
              // Expanded(
              //   child: ListView.builder(
              //     padding: EdgeInsets.only(top: 0),
              //     scrollDirection: Axis.vertical,

              //     // itemCount: myorder.length,
              //     itemCount: 20,
              //     itemBuilder: (BuildContext context, int index) {
              //       return addFriend(index, context);
              //     },
              //   ),
              // ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _friendFuture() {
    return FutureBuilder(
        future: listfriendfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyfriend(s, c);
            }
          }
        });
  }

  Widget bodyfriend(s, c) {
    return Container(
      color: AppColor.whitecolor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 0),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return addFriend(s, index);
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addFriend(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0,left: 10.0,right: 10.0),
      child: Material(
        elevation: 3,
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : Colors.white,
        child: ListTile(
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(top: 5.0, bottom: 5.0, left: 0.0),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                    color: AppColor.whitecolor,
                  ),
                  // color: Colors.grey,
                  height: 50,
                  width: 50,
                  // child: Center(
                  //   child: Icon(
                  //     Icons.person,
                  //     size: 40,
                  //     color: Colors.black,
                  //   ),
                  // ),

                 child: Container(
                   decoration: BoxDecoration(
                     border: Border.all(width: 2.0),
                     borderRadius: BorderRadius.all(Radius.circular(5.0)),
                     color: AppColor.cancelbtn,
                   ),
                   child: CachedNetworkImage(
                     fit: BoxFit.fill,
                     imageUrl:
                     Connection.profileImagePath.toString() +
                                    s.data[index]["image"].toString(),
                     // "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
                     placeholder: (context, url) =>
                         CircularProgressIndicator(),
                     // CircularProgressIndicator(),
                     errorWidget: (context, url, error) =>
                     new Icon(Icons.error),
                   ),
                 ),

                  // child: CircleAvatar(
                  //   backgroundImage: NetworkImage(
                  //       // ValidationClass.userdata["Profiledata"].toString(),
                  //       Connection.profileImagePath.toString() +
                  //           s.data[index]["image"].toString()
                  //       //  ValidationClass.userimg.toString(),
                  //       // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                  //       ),
                  //   radius: 50.0,
                  // ),
                ),
              ),
              Padding(
                  padding: const EdgeInsets.only(top: 10.0, left: 10.0),
                  child: Text(
                    s.data[index]["name"],
                    style: AppTextStyle.blacktextstyle4,
                  )),
            ],
          ),
          trailing: Consumer<TeamPlayerModel>(builder: (context, model, child) {
            return InkWell(
              onTap: () async {
                flag = true;
                indexnew = index;

                setState(() {});
                await Future.delayed(const Duration(seconds: 1), () {});

                setState(() {
                  flag = false;
                });

                int cnt = 1;
                for (var i in model.playerdata) {
                  if (ValidationClass.settostring(i['request_accept']) != '') {
                    cnt++;
                  }
                }
                if (ValidationClass.settodouble(
                        model.playerdata[index]['teamsize'].toString()) >=
                    cnt) {
                  sendrequest(model.playerdata[index]);
                } else if (listplayer[index]["request_accept"] == 'REQUESTED') {
                  sendrequest(model.playerdata[index]);
                }
              },
              child: (indexnew == index && flag == true)
                  ? Container(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                          backgroundColor: Colors.grey, color: Colors.green),
                    )
                  : Icon(
                      listplayer[index]["request_accept"] == 'REQUESTED'
                          ? Icons.remove
                          : listplayer[index]["request_accept"] == 'ACCEPT'
                              ? Icons.check
                              : Icons.add,
                      size: 23,
                      color: listplayer[index]["request_accept"] == 'REQUESTED'
                          ? Colors.red
                          : listplayer[index]["request_accept"] == 'ACCEPT'
                              ? Colors.green
                              : Colors.black87,
                    ),
            );
          }),
        ),
      ),
    );
  }

  Future<List<dynamic>> sendrequest(propertydata) async {
    List _list = [];
    try {
      var res;
      print('propertydata["user_id"].toString() : ' +
          propertydata["user_id"].toString());
      res = await http.post(
        Connection.sendrequest.toString(),
        body: {
          "user_id": propertydata["user_id"].toString(),
          "request_from_id": ValidationClass.userid.toString(),
          "match_id": matchid.toString(),
          "type": "REQUEST",
          "request_accept": "REQUESTED",
          "room_id": "",
          "room_password": "",
          "room_slot": "",
          "win_description": "",
          "win_price": "",
          "youtube_link": "",
          "announcement": "",
          "is_view": 0.toString()
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );
      print("response");
      print("response" + res.body);
      var aa = json.decode(utf8.decode(res.bodyBytes));
      print('aa ' + aa.toString());
      // print('aa["Table"] : ' + aa["Table"].toString());
      listplayer = aa;

      if (listplayer == null) {
        listplayer = [];
      }

      Provider.of<TeamPlayerModel>(context, listen: false)
          .refreshPlayer(listplayer);

      // listfriendfuture = convertlist(friendlist1);
      // setState(() {});
      print('msg : success');
      // Fluttertoast.showToast(msg: 'Request Send Successfully');
    } catch (e) {
      print('msg : ' + e.toString());
    }
    // pr.hide().then((isHidden) {
    //   print(isHidden);
    // });
    // Navigator.pop(context);
    return _list;
  }
}
