import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:image_picker/image_picker.dart';
import 'package:progress_dialog/progress_dialog.dart';

import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/model/FriendModel.dart';

import 'package:proplayerwar/model/PlayerModel.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';

import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:proplayerwar/pages/Team/PlayerAdd.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

class TeamCreatepage extends StatefulWidget {
  final data, players;
  TeamCreatepage(this.data, this.players);
  @override
  _TeamCreatepageState createState() => _TeamCreatepageState(data, players);
}

class _TeamCreatepageState extends State<TeamCreatepage> {
  var data, players;
  _TeamCreatepageState(this.data, this.players);



  bool imagePrecached = false;

  String base64Image = '';
  File _image;
  String imgpath;
  TextEditingController teamnamecontroller = TextEditingController();

  Future<List<dynamic>> listfriendfuture;

  // var _teamsize = "2";

  var _gameid = "";
  var _teamsizeid = "";
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  List listgame = [];
  List listteamsize = [];

  var _teamid = 0;
  var listteamsize1;

  ProgressDialog pr;

  File fileData;
  int _teamsizevalue = 0;
  @override
  void initState() {
    super.initState();

    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);

    ValidationClass.teamdata = [];
    teamnamecontroller.text = "";

    _tournament();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  Future<String> _tournament() async {
    await pr.show();

    try {
      if (data != 0) {
        if (data["image"].toString() != "") {
          imgpath = data["image"].toString();

          http.Response response1 = await http.get(
            Connection.teamImagePath + data["image"].toString(),
          );
          base64Image = base64.encode(response1.bodyBytes);
        }
      }
    } catch (e) {}

    print("token ValidationClass ${ValidationClass.token}");
    var response = await http.post(Connection.team,
        body: {"user_id": ValidationClass.userid.toString()}
        // headers: {
        //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // },
        );

    // print(candidate)
    print(response.body);
    var aa = json.decode(response.body);
    // var decodedData = json.decode(aa[0]);
    // // var decodedData = response.body;
    // print("data : $decodedData");

    //friend

    var friendlist = aa["Table"];

    if (friendlist == null) {
      friendlist = [];
    }

    listfriendfuture = convertlist(friendlist);

    //game

    listgame = aa["Table1"];

    if (listgame == null) {
      listgame = [];
    }
    try {
      if (data != 0) {
        _gameid = data["game_id"].toString();
      } else {
        _gameid = listgame[0]["game_id"].toString();
      }
    } catch (e) {}

    //game

    listteamsize1 = aa["Table2"];

    if (listteamsize1 == null) {
      listteamsize1 = [];
    }
    listteamsize = [];
    for (var i in listteamsize1) {
      setState(() {
        if (i["game_id"].toString() == _gameid.toString()) {
          print("game:${i["game_id"]}");
          listteamsize.add(i);
        }
      });
    }

    try {
      _teamsizeid = listteamsize[0]["team_size_id"].toString();
      _teamsizevalue = ValidationClass.settoint(
          listteamsize[0]["team_size_value"].toString());
    } catch (e) {}

    if (data == 0) {
      FriendModel friendModel = FriendModel();

      friendModel.userid = ValidationClass.userid;
      friendModel.frienduserid = ValidationClass.userid;
      // friendModel.frienduserid = s.data[index]["user_id"];
      friendModel.type = ValidationClass.matchtype;
      friendModel.name = ValidationClass.username;
      friendModel.image = ValidationClass.userimg;

      ValidationClass.teamdata.add(friendModel);
    } else {
      teamnamecontroller.text = data["team_name"].toString();
      // _teamsize = data["team_size"].toString();
      _gameid = data["game_id"].toString();
      _teamsizeid = data["team_size_id"].toString();
      _teamid = ValidationClass.settoint(data["team_id"].toString());

      _teamsizevalue =
          ValidationClass.settoint(data["team_size_value"].toString());

      if (players == 0) {
        FriendModel friendModel = FriendModel();

        friendModel.userid = ValidationClass.userid;
        friendModel.frienduserid = ValidationClass.userid;
        // friendModel.frienduserid = s.data[index]["user_id"];
        friendModel.type = ValidationClass.matchtype;
        friendModel.name = ValidationClass.username;
        friendModel.image = ValidationClass.userimg;

        ValidationClass.teamdata.add(friendModel);
      } else {
        for (var item in players) {
          FriendModel friendModel = FriendModel();

          friendModel.userid = ValidationClass.userid;
          friendModel.frienduserid =
              ValidationClass.settoint(item["friend_user_id"].toString());
          // friendModel.frienduserid = s.data[index]["user_id"];
          friendModel.type = ValidationClass.matchtype;
          friendModel.image = item["image"];
          friendModel.name = item["name"];
          ValidationClass.teamdata.add(friendModel);
        }
      }
    }
    Provider.of<PlayerModel>(context, listen: false)
        .refreshPlayer(ValidationClass.teamdata);

    setState(() {});

    pr.hide().then((isHidden) {
      print(isHidden);
    });
    return "";
  }

  Future<String> _playerlist() async {
    await pr.show();

    print("token ValidationClass ${ValidationClass.token}");
    var response = await http.post(Connection.playerlist, body: {
      "user_id": ValidationClass.userid.toString(),
      "game_id": _gameid.toString()
    }
        // headers: {
        //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // },
        );

    // print(candidate)
    print(response.body);
    // var aa = json.decode(response.body);
    var aa = json.decode(utf8.decode(response.bodyBytes));
    // var decodedData = json.decode(aa[0]);
    // // var decodedData = response.body;
    // print("data : $decodedData");

    //friend

    var friendlist = aa["Table"];

    if (friendlist == null) {
      friendlist = [];
    }

    listfriendfuture = convertlist(friendlist);

    pr.hide().then((isHidden) {
      print(isHidden);
    });

    showDialog(
        context: context, builder: (context) => PlayerAdd(listfriendfuture));

    return "";
  }

  // void updateImageList(BuildContext context) async {
  //   for (int i = 1; i <= 1; i++) {
  //     imageList.add(AssetImage('assets/pubg$i.png'));
  //     //* To precache images so that when required they are loaded faster.
  //     await precacheImage(AssetImage('assets/pubg$i.png'), context);
  //   }
  //   setState(() {
  //     imagePrecached = true;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: IconButton(
        //     icon: Icon(Icons.person_add),
        //     onPressed: () {
        //       scaffoldKey.currentState.openDrawer();
        //     },
        //   ),
        // ),
        // backgroundColor: Theme.of(context).primaryColor,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "TeamCreate", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "Team Create",
              style: TextStyle(fontSize: 20.0, color: Colors.white),
            ),
          ],
        ),
        // actions: <Widget>[
        //   InkWell(
        //       onTap: () {},
        //       child: Icon(
        //         Icons.save,
        //         size: 25,
        //       )),
        //   Padding(padding: EdgeInsets.all(10.0)),
        //   // CartIcon(cartlist.length),
        // ],
        elevation: 0,
      ),
      body: bodyTeamCreate(context),
      // drawer: Drawer(
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.start,
      //     crossAxisAlignment: CrossAxisAlignment.start,
      //     children: <Widget>[
      //       // DrawerHeader(
      //       //   decoration: BoxDecoration(color: Colors.red),
      //       //   margin: EdgeInsets.all(0.0),
      //       //   padding: EdgeInsets.all(0.0),
      //       //   child: TextField(
      //       //     autofocus: false,
      //       //     decoration: InputDecoration(
      //       //       contentPadding: EdgeInsets.all(9.0),
      //       //       border: InputBorder.none,
      //       //       hintText: 'Please enter text',
      //       //     ),
      //       //   ),
      //       // ),
      //       SizedBox(
      //         height: 25,
      //       ),
      //       Padding(
      //         padding: const EdgeInsets.all(2.0),
      //         child: Container(
      //           color: AppColor.primaryColor,
      //           child: TextField(
      //             style: AppTextStyle.whitetextstyle1,
      //             autofocus: false,
      //             decoration: InputDecoration(
      //                 // suffixIcon: InkWell(
      //                 //   onTap: () {},
      //                 //   child: Icon(
      //                 //     Icons.search,
      //                 //     size: 25,
      //                 //     color: AppColor.whitecolor,
      //                 //   ),
      //                 // ),
      //                 // suffixIcon: InkWell(
      //                 //   onTap: () {

      //                 //   },
      //                 //   child: Icon(
      //                 //     Icons.search,
      //                 //     size: 25,
      //                 //     color: AppColor.whitecolor,
      //                 //   ),
      //                 // ),
      //                 contentPadding: EdgeInsets.all(15.0),
      //                 border: InputBorder.none,
      //                 hintText: 'Player List..',
      //                 hintStyle: AppTextStyle.whitetextstyle1),
      //           ),
      //         ),
      //       ),
      //       Expanded(
      //         child: _friendFuture(),
      //       ),
      //       // Expanded(
      //       //   child: ListView.builder(
      //       //     padding: EdgeInsets.only(top: 0),
      //       //     scrollDirection: Axis.vertical,

      //       //     // itemCount: myorder.length,
      //       //     itemCount: 20,
      //       //     itemBuilder: (BuildContext context, int index) {
      //       //       return addFriend(index, context);
      //       //     },
      //       //   ),
      //       // ),
      //     ],
      //   ),
      // ),
    );
  }

  Future getImage() async {
    // ignore: deprecated_member_use
    var image = await ImagePicker.pickImage(
        source: ImageSource.gallery, maxWidth: 200, maxHeight: 200);
    setState(() {
      _image = image;
      // print("image path ${image.path}");
      List<int> imageBytes = image.readAsBytesSync();
      base64Image = base64Encode(imageBytes);

      imgpath = null;
    });
  }

  Widget bodyTeamCreate(context) {
    return SingleChildScrollView(
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // SizedBox(
                //   height: 5,
                // ),

                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Container(
                    color: AppColor.whitecolor,
                    child: Padding(
                      padding: const EdgeInsets.all(0.0),
                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 0.0, top: 0, bottom: 0),
                            child: Container(
                              height: 25,
                              color: AppColor.headerColor,
                              child: Center(
                                child: Text(
                                  "Upload image",
                                  style: AppTextStyle.blacktextstylenormal5,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: imgpath == null
                                ? _image == null
                                    ? Center(
                                        child: Container(
                                          height: 150,
                                          width: 150,
                                          decoration: BoxDecoration(
                                            color: Colors.grey.withOpacity(.1),
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            // image: DecorationImage(
                                            //   image: AssetImage('assets/pubg1.png'),
                                            // ),
                                          ),
                                          child: Align(
                                            alignment: Alignment.center,
                                            child: GestureDetector(
                                              child: Center(
                                                child: Icon(
                                                  Icons.camera_alt,
                                                  color: Colors.white,
                                                  size: 52,
                                                ),
                                              ),
                                              onTap: getImage,
                                            ),
                                          ),
                                        ),
                                      )
                                    : Center(
                                        child: Container(
                                          height: 150,
                                          width: 150,
                                          decoration: BoxDecoration(
                                            color: Colors.grey.withOpacity(.6),
                                            borderRadius:
                                                BorderRadius.circular(120),
                                            image: DecorationImage(
                                                image: FileImage(_image),
                                                fit: BoxFit.cover),
                                          ),
                                          child: Align(
                                            alignment: Alignment.bottomRight,
                                            child: GestureDetector(
/*
                                        child: Center(
                                          child: Icon(Icons.camera_alt,
                                            color: Colors.white, size: 52,),
                                        ),
*/
                                              onTap: getImage,
                                            ),
                                          ),
                                        ),
                                      )
                                : Center(
                                    child: Container(
                                      height: 150,
                                      width: 150,
                                      decoration: BoxDecoration(
                                        color: Colors.grey.withOpacity(.6),
                                        borderRadius:
                                            BorderRadius.circular(120),
                                        image: DecorationImage(
                                            image: NetworkImage(Connection
                                                    .teamImagePath
                                                    .toString() +
                                                imgpath.toString()),
                                            fit: BoxFit.cover),
                                      ),
                                      child: Align(
                                        alignment: Alignment.bottomRight,
                                        child: GestureDetector(
/*
                                        child: Center(
                                          child: Icon(Icons.camera_alt,
                                            color: Colors.white, size: 52,),
                                        ),
*/
                                          onTap: getImage,
                                        ),
                                      ),
                                    ),
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Container(
                    color: AppColor.whitecolor,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 0.0, top: 0, bottom: 5),
                          child: Container(
                            height: 25,
                            color: AppColor.headerColor,
                            child: Center(
                              child: Text(
                                "Team Name & Type",
                                style: AppTextStyle.blacktextstylenormal5,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 8.0, right: 8.0, bottom: 8.0),
                          child: Container(
                            // color: Colors.grey,
                            child: TextFormField(
                              controller: teamnamecontroller,
                              // style: AppTextStyle.textfromfieldstyle,
                              // maxLength: 10,
                              decoration: InputDecoration(
                                hintText: "Team Name",
                                counterText: '',
                                counterStyle: TextStyle(fontSize: 0),
                                // fillColor: Colors.white,
                                contentPadding: EdgeInsets.symmetric(
                                    vertical: 0, horizontal: 5),
                                // contentPadding:
                                //     EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                                border: new OutlineInputBorder(
                                  borderRadius: new BorderRadius.circular(0.0),
                                  borderSide:
                                      new BorderSide(color: AppColor.backColor),
                                ),
                              ),
                              // keyboardType: TextInputType.number,
                              // controller: _mobileController,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 8.0, left: 8.0, right: 8.0),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(0.0)),
                              border: new Border.all(color: AppColor.backColor),
                              color: AppColor.whitecolor,
                            ),
                            padding: const EdgeInsets.only(
                                left: 5.0, top: 0, bottom: 0),
                            child: IgnorePointer(
                              ignoring: data != 0 ? true : false,
                              child: new DropdownButtonFormField(
                                decoration: InputDecoration(
                                  enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white)),
                                ),
                                style: AppTextStyle.blacktextstylenormal1,

                                // focusColor: Colors.green,
                                isExpanded: false,

                                items: listgame.map((item) {
                                  return new DropdownMenuItem(
                                    child:
                                        new Text(item['game_name'].toString()),
                                    value: item['game_id'].toString(),
                                  );
                                }).toList(),

                                hint: Text("--Select--"),

                                onChanged: (newVal) {
                                  setState(() {
                                    _gameid = newVal;
                                    print(_gameid);

                                    listteamsize = [];
                                    for (var i in listteamsize1) {
                                      setState(() {
                                        if (i["game_id"].toString() ==
                                            _gameid.toString()) {
                                          print("game:${i["game_id"]}");
                                          listteamsize.add(i);
                                        }
                                      });
                                    }
                                    try {
                                      _teamsizeid = listteamsize[0]
                                              ["team_size_id"]
                                          .toString();
                                      _teamsizevalue = ValidationClass.settoint(
                                          listteamsize[0]["team_size_value"]
                                              .toString());
                                    } catch (e) {}

                                    // for (var i = 0; i < listgame.length; i++) {
                                    //   if (listgame[i]["game_id"].toString() ==
                                    //       _gameid) {
                                    //     listteamsize = [];
                                    //     listteamsize = listgame[i]["team_size"];
                                    //     _teamsizeid = listteamsize[0]["team_size_id"];
                                    //   }
                                    // }
                                  });
                                },
                                isDense: true,
                                value: _gameid.toString(),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 8.0, left: 8.0, right: 8.0),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(0.0)),
                              border: new Border.all(color: AppColor.backColor),
                              color: AppColor.whitecolor,
                            ),
                            padding: const EdgeInsets.only(
                                left: 5.0, top: 0, bottom: 0),
                            child: IgnorePointer(
                              ignoring: data != 0 ? true : false,
                              child: new DropdownButtonFormField(
                                decoration: InputDecoration(
                                  enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white)),
                                ),
                                style: AppTextStyle.blacktextstylenormal1,

                                // focusColor: Colors.green,
                                isExpanded: true,

                                items: listteamsize.map((item) {
                                  return new DropdownMenuItem(
                                    child: new Text(
                                        item['team_size_value'].toString()),
                                    value: item['team_size_id'].toString(),
                                  );
                                }).toList(),
                                // items: <String>['Duo', 'Squad'].map((String value) {
                                //   return new DropdownMenuItem<String>(
                                //     value: value,
                                //     child: new Text(value),
                                //   );
                                // }).toList(),
                                hint: Text("--Select--"),
                                onChanged: (newVal) {
                                  setState(() {
                                    _teamsizeid = newVal;
                                    print(_teamsizeid);

                                    for (var i in listteamsize) {
                                      if (i["team_size_id"].toString() ==
                                          _teamsizeid.toString()) {
                                        _teamsizevalue =
                                            ValidationClass.settoint(
                                                i["team_size_value"]
                                                    .toString());
                                      }
                                    }
                                  });
                                },

                                value: _teamsizeid.toString(),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // SizedBox(
                //   height: 8,
                // ),
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Container(
                    color: AppColor.whitecolor,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 0.0, top: 0, bottom: 5),
                          child: Container(
                            height: 25,
                            color: AppColor.headerColor,
                            child: Center(
                              child: Text(
                                "Player",
                                style: AppTextStyle.blacktextstylenormal5,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6.0, vertical: 6.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              InkWell(
                                onTap: () {
                                  Scaffold.of(context).openDrawer();
                                },
                                child: Consumer<PlayerModel>(
                                  builder: (context, model, child) {
                                    return Container(
                                      height: 120,
                                      width: MediaQuery.of(context).size.width,
                                      // color: AppColor.whitecolor,
                                      child: ListView.builder(
                                        // padding: EdgeInsets.only(top: 0),
                                        scrollDirection: Axis.horizontal,
                                        shrinkWrap: false,
                                        // physics: NeverScrollableScrollPhysics(),
                                        itemCount: model.teamdata.length,
                                        // itemCount: 4,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return Row(
                                            children: <Widget>[
                                              addcard(index, context),
                                              Visibility(
                                                visible: model.teamdata.length -
                                                                1 ==
                                                            index &&
                                                        model.teamdata.length !=
                                                            _teamsizevalue
                                                    ? true
                                                    : false,
                                                child: addcardDummy(context),
                                              )
                                            ],
                                          );
                                        },
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 5.0, right: 5.0, top: 10, bottom: 10),
                  child: InkWell(
                    onTap: () {
                      if (_image == null && _teamid == 0) {
                        ValidationClass.onBasicAlertPressed(
                            context, "Validation", "oops.. Missing Image ....");
                        // Fluttertoast.showToast(
                        //     msg: "oops.. Missing Image ....");
                      } else if (teamnamecontroller.text == "") {
                        ValidationClass.onBasicAlertPressed(context,
                            "Validation", "oops.. Missing Team Name....");
                        // Fluttertoast.showToast(
                        //     msg: "oops.. Missing Team Name ....");
                      } else {
                        teamadd();
                      }
                    },
                    child: Container(
                      height: 40,
                      decoration: BoxDecoration(
                        border:
                            Border.all(width: 0.0, color: AppColor.buttonColor),
                        borderRadius: BorderRadius.all(Radius.circular(0.0)),
                        color: AppColor.buttonColor,
                      ),
                      child: Center(
                          child: Text(
                        data != 0 ? "Create Team" : "Create Team",
                        style: AppTextStyle.button,
                      )),
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Widget _friendFuture() {
  //   return FutureBuilder(
  //       future: listfriendfuture,
  //       builder: (c, s) {
  //         if (s.connectionState != ConnectionState.done) {
  //           return Center(
  //               child: CircularProgressIndicator(
  //             valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
  //           ));
  //         } else {
  //           if (s.hasError) {
  //             return Center(
  //               child: Text(
  //                 'No Data Found. Error',
  //                 style: TextStyle(color: Colors.black87, fontSize: 18),
  //               ),
  //             );
  //           } else if (s.data.isEmpty) {
  //             return Center(
  //               child: Text(
  //                 'No Data Found.',
  //                 style: TextStyle(color: Colors.black87, fontSize: 18),
  //               ),
  //             );
  //           } else {
  //             return bodyfriend(s, c);
  //           }
  //         }
  //       });
  // }

  Widget bodyfriend(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 2),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return addFriend(s, index);
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addcard(int index, BuildContext context) {
    return Container(
      height: 130,
      width: (MediaQuery.of(context).size.width / 4) - 6,
      color: AppColor.whitecolor,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(right: 8.0, bottom: 0),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,

                // border: Border.all(width: 0.0, color: AppColor.buttonColor),
                // borderRadius: BorderRadius.all(Radius.circular(50.0)),
                color: AppColor.whitecolor,
              ),

              height: 80,
              width: 80,
              // color: AppColor.backColor,
              // child: Image.asset(
              //   "assets/plate1.png",
              //   fit: BoxFit.cover,
              // ),

              child: CircleAvatar(
                backgroundImage: NetworkImage(Connection.profileImagePath +
                        ValidationClass.teamdata[index].image.toString()
                    // ValidationClass.userdata["Profiledata"].toString(),
                    // img.toString()
                    //  ValidationClass.userimg.toString(),
                    // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                    ),
                radius: 50.0,
              ),
              //   child: CachedNetworkImage(
              //   fit: BoxFit.fill,
              //   imageUrl: img.toString(),
              //   placeholder: (context, url) => CircularProgressIndicator(),
              //   errorWidget: (context, url, error) => new Icon(Icons.error),
              // ),

              // child: Image.asset(
              //   "assets/player1.png",
              //   fit: BoxFit.fill,
              // ),

              // child: (imagePrecached == true)
              //     ? ImageView360(
              //         key: UniqueKey(),
              //         imageList: imageList,
              //         autoRotate: false,
              //         rotationCount: 2,
              //         rotationDirection: RotationDirection.anticlockwise,
              //         frameChangeDuration: Duration(milliseconds: 30),
              //         swipeSensitivity: 2,
              //         allowSwipeToRotate: true,
              //         onImageIndexChanged: (currentImageIndex) {
              //           print("currentImageIndex: $currentImageIndex");
              //         },
              //       )
              //     : Image.asset(
              //         "assets/pubg1.png",
              //         fit: BoxFit.fill,
              //       ),

              // child: Cube(
              //   onSceneCreated: (Scene scene) {
              //     scene.world.add(Object(
              //       fileName: 'assets/cube/cube.obj',
              //     ));
              //   },
              // ),

              // child:  Image.network(

              //       _imageUrl,
              //       fit: BoxFit.cover,
              //     ),
              // child: ClipRRect(
              //   child: Icon(
              //     Icons.person,
              //     size: 75,
              //     color: AppColor.whitecolor,
              //   ),
              // ),

              // child: ClipRRect(

              //   borderRadius: BorderRadius.circular(50),
              //   child: SizedBox(
              //     width: 100,
              //     height: 100,
              //     child: Image.network(
              //       _imageUrl,
              //       fit: BoxFit.cover,
              //     ),
              //   ),
              // ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              // mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0, color: AppColor.buttonColor),
                    borderRadius: BorderRadius.all(Radius.circular(15.0)),
                    color: AppColor.headerColor,
                  ),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 0.0, bottom: 0.0, right: 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          height: 20,
                          width: 54,
                          child: Padding(
                            padding: const EdgeInsets.all(3.0),
                            child: Center(
                              child: Text(
                                ValidationClass.teamdata[index].name.toString(),
                                style: AppTextStyle.whitetextstylenormal6,
                              ),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            setState(() {
                              ValidationClass.teamdata.removeAt(index);
                            });
                            if (ValidationClass.teamdata.length == 0) {
                              FriendModel friendModel = FriendModel();

                              friendModel.userid = ValidationClass.userid;
                              friendModel.frienduserid = ValidationClass.userid;
                              // friendModel.frienduserid = s.data[index]["user_id"];
                              friendModel.type = ValidationClass.matchtype;
                              friendModel.name = ValidationClass.username;
                              friendModel.image = ValidationClass.userimg;

                              ValidationClass.teamdata.add(friendModel);
                            }
                          },
                          child: Icon(
                            Icons.cancel,
                            size: 18,
                            color: AppColor.whitecolor,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget addcardDummy(BuildContext context) {
    return InkWell(
      onTap: () {
        _playerlist();
      },
      child: Container(
        height: 130,
        width: (MediaQuery.of(context).size.width / 4) - 6,
        color: AppColor.whitecolor,
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 8.0, bottom: 0),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,

                  // border: Border.all(width: 0.0, color: AppColor.buttonColor),
                  // borderRadius: BorderRadius.all(Radius.circular(50.0)),
                  color: AppColor.whitecolor,
                ),

                height: 80,
                width: 80,
                // color: AppColor.backColor,
                // child: Image.asset(
                //   "assets/plate1.png",
                //   fit: BoxFit.cover,
                // ),

                child: CircleAvatar(
                  child: Icon(Icons.add),
                  // backgroundImage: NetworkImage(Connection.profileImagePath +
                  //         ValidationClass.teamdata[index].image.toString()
                  //     // ValidationClass.userdata["Profiledata"].toString(),
                  //     // img.toString()
                  //     //  ValidationClass.userimg.toString(),
                  //     // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                  //     ),
                  radius: 50.0,
                ),
                //   child: CachedNetworkImage(
                //   fit: BoxFit.fill,
                //   imageUrl: img.toString(),
                //   placeholder: (context, url) => CircularProgressIndicator(),
                //   errorWidget: (context, url, error) => new Icon(Icons.error),
                // ),

                // child: Image.asset(
                //   "assets/player1.png",
                //   fit: BoxFit.fill,
                // ),

                // child: (imagePrecached == true)
                //     ? ImageView360(
                //         key: UniqueKey(),
                //         imageList: imageList,
                //         autoRotate: false,
                //         rotationCount: 2,
                //         rotationDirection: RotationDirection.anticlockwise,
                //         frameChangeDuration: Duration(milliseconds: 30),
                //         swipeSensitivity: 2,
                //         allowSwipeToRotate: true,
                //         onImageIndexChanged: (currentImageIndex) {
                //           print("currentImageIndex: $currentImageIndex");
                //         },
                //       )
                //     : Image.asset(
                //         "assets/pubg1.png",
                //         fit: BoxFit.fill,
                //       ),

                // child: Cube(
                //   onSceneCreated: (Scene scene) {
                //     scene.world.add(Object(
                //       fileName: 'assets/cube/cube.obj',
                //     ));
                //   },
                // ),

                // child:  Image.network(

                //       _imageUrl,
                //       fit: BoxFit.cover,
                //     ),
                // child: ClipRRect(
                //   child: Icon(
                //     Icons.person,
                //     size: 75,
                //     color: AppColor.whitecolor,
                //   ),
                // ),

                // child: ClipRRect(

                //   borderRadius: BorderRadius.circular(50),
                //   child: SizedBox(
                //     width: 100,
                //     height: 100,
                //     child: Image.network(
                //       _imageUrl,
                //       fit: BoxFit.cover,
                //     ),
                //   ),
                // ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget addFriend(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 1.0),
      child: Material(
        elevation: 0,
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        child: ListTile(
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.all(Radius.circular(50.0)),
                    color: AppColor.whitecolor,
                  ),
                  // color: Colors.grey,
                  height: 40,
                  width: 40,
                  // child: Center(
                  //   child: Icon(
                  //     Icons.person,
                  //     size: 40,
                  //     color: Colors.black,
                  //   ),
                  // ),
                  child: CircleAvatar(
                    backgroundImage: NetworkImage(
                        // ValidationClass.userdata["Profiledata"].toString(),
                        Connection.profileImagePath.toString() +
                            s.data[index]["image"].toString()
                        //  ValidationClass.userimg.toString(),
                        // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                        ),
                    radius: 50.0,
                  ),
                ),
              ),
              Padding(
                  padding: const EdgeInsets.only(top: 10.0, left: 10.0),
                  child: Text(
                    s.data[index]["name"],
                    style: AppTextStyle.blacktextstyle4,
                  )),
            ],
          ),
          trailing: InkWell(
            onTap: () {
              setState(() {
                int chklength = 0;
                // if (_teamsize.toUpperCase() == "DUO") {
                //   chklength = 1;
                // } else {
                //   chklength = 3;
                // }

                chklength = _teamsizevalue;
                if (ValidationClass.teamdata.length < chklength) {
                  FriendModel friendModel = FriendModel();

                  friendModel.userid = ValidationClass.userid;
                  friendModel.frienduserid = ValidationClass.settoint(
                      s.data[index]["user_id"].toString());
                  // friendModel.frienduserid = s.data[index]["user_id"];
                  friendModel.type = ValidationClass.matchtype;
                  friendModel.name = s.data[index]["name"].toString();
                  friendModel.image = s.data[index]["image"].toString();

                  int cnt = 0;
                  for (var item in ValidationClass.teamdata) {
                    FriendModel friendModel1 = FriendModel();
                    friendModel1 = item;
                    if (ValidationClass.settoint(
                            friendModel1.frienduserid.toString()) ==
                        friendModel.frienduserid) {
                      cnt = cnt + 1;
                    }
                  }
                  if (cnt == 0) {
                    ValidationClass.teamdata.add(friendModel);
                  }
                }
              });
            },
            child: Icon(
              Icons.add,
              size: 25,
            ),
          ),
        ),
      ),
    );
  }

  Future<List<dynamic>> teamadd() async {
    await pr.show();

    var str = "";
    int cnt = 1;

    for (var item in ValidationClass.teamdata) {
      FriendModel friendModel = FriendModel();
      friendModel = item;
      str = str.toString() + friendModel.frienduserid.toString();
      if (cnt != ValidationClass.teamdata.length) {
        str = str.toString() + ",";
      }
      cnt = cnt + 1;
    }

    List<dynamic> _list = [];

    try {
      var res;

      res = await http.post(
        Connection.teamadd.toString(),
        body: {
          "team_id": _teamid.toString(),
          "team_name": teamnamecontroller.text.toString(),
          "user_id": ValidationClass.userid.toString(),
          "game_id": _gameid.toString(),
          "team_size_id": _teamsizeid.toString(),
          "image": base64Image,
          "players": str.toString()
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);
      var decodedData = json.decode(res.body);
      _list = decodedData;

      if (_list.length > 0) {
        //  Fluttertoast.showToast(msg: _list[0]["Msg"].toString());
        pr.hide().then((isHidden) {
          print(isHidden);
        });
        ValidationClass.onBasicAlertPressed2(
            context, "Save", _list[0]["Msg"].toString());
      }
    } catch (e) {}
    // pr.hide().then((isHidden) {
    //   print(isHidden);
    // });
    // Navigator.pop(context);
    return _list;
  }
}
