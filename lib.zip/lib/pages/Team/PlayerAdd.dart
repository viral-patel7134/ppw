import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/model/FriendModel.dart';
import 'package:proplayerwar/model/PlayerModel.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:provider/provider.dart';

class PlayerAdd extends StatefulWidget {
  final data;
  PlayerAdd(this.data);
  @override
  _PlayerAddState createState() => _PlayerAddState(data);
}

class _PlayerAddState extends State<PlayerAdd> {
  final data;
  _PlayerAddState(this.data);

  ProgressDialog pr;

  Future<List<dynamic>> listfriendfuture;

  @override
  void initState() {
    super.initState();

    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);

    listfriendfuture = data;
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Stack(
        children: <Widget>[
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // DrawerHeader(
              //   decoration: BoxDecoration(color: Colors.red),
              //   margin: EdgeInsets.all(0.0),
              //   padding: EdgeInsets.all(0.0),
              //   child: TextField(
              //     autofocus: false,
              //     decoration: InputDecoration(
              //       contentPadding: EdgeInsets.all(9.0),
              //       border: InputBorder.none,
              //       hintText: 'Please enter text',
              //     ),
              //   ),
              // ),
              SizedBox(
                height: 25,
              ),
              Padding(
                padding: const EdgeInsets.all(2.0),
                child: Container(
                  color: AppColor.primaryColor,
                  child: TextField(
                    style: AppTextStyle.whitetextstyle1,
                    autofocus: false,
                    decoration: InputDecoration(
                        // suffixIcon: InkWell(
                        //   onTap: () {},
                        //   child: Icon(
                        //     Icons.search,
                        //     size: 25,
                        //     color: AppColor.whitecolor,
                        //   ),
                        // ),
                        // suffixIcon: InkWell(
                        //   onTap: () {

                        //   },
                        //   child: Icon(
                        //     Icons.search,
                        //     size: 25,
                        //     color: AppColor.whitecolor,
                        //   ),
                        // ),
                        contentPadding: EdgeInsets.all(15.0),
                        border: InputBorder.none,
                        hintText: 'Player List..',
                        hintStyle: AppTextStyle.whitetextstyle1),
                  ),
                ),
              ),
              Expanded(
                child: _friendFuture(),
              ),
              // Expanded(
              //   child: ListView.builder(
              //     padding: EdgeInsets.only(top: 0),
              //     scrollDirection: Axis.vertical,

              //     // itemCount: myorder.length,
              //     itemCount: 20,
              //     itemBuilder: (BuildContext context, int index) {
              //       return addFriend(index, context);
              //     },
              //   ),
              // ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _friendFuture() {
    return FutureBuilder(
        future: listfriendfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyfriend(s, c);
            }
          }
        });
  }

  Widget bodyfriend(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 2),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return addFriend(s, index);
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addFriend(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 1.0),
      child: Material(
        elevation: 0,
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        child: ListTile(
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.all(Radius.circular(50.0)),
                    color: AppColor.whitecolor,
                  ),
                  // color: Colors.grey,
                  height: 40,
                  width: 40,
                  // child: Center(
                  //   child: Icon(
                  //     Icons.person,
                  //     size: 40,
                  //     color: Colors.black,
                  //   ),
                  // ),
                  child: CircleAvatar(
                    backgroundImage: NetworkImage(
                        // ValidationClass.userdata["Profiledata"].toString(),
                        Connection.profileImagePath.toString() +
                            s.data[index]["image"].toString()
                        //  ValidationClass.userimg.toString(),
                        // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                        ),
                    radius: 50.0,
                  ),
                ),
              ),
              Padding(
                  padding: const EdgeInsets.only(top: 10.0, left: 10.0),
                  child: Text(
                    s.data[index]["name"],
                    style: AppTextStyle.blacktextstyle4,
                  )),
            ],
          ),
          trailing: InkWell(
            onTap: () {
              setState(() {
                // int chklength = 0;
                // if (_teamsize.toUpperCase() == "DUO") {
                //   chklength = 1;
                // } else {
                //   chklength = 3;
                // }

                // chklength = _teamsizevalue;
                // if (ValidationClass.teamdata.length < chklength) {
                FriendModel friendModel = FriendModel();

                friendModel.userid = ValidationClass.userid;
                friendModel.frienduserid = ValidationClass.settoint(
                    s.data[index]["user_id"].toString());
                // friendModel.frienduserid = s.data[index]["user_id"];
                friendModel.type = ValidationClass.matchtype;
                friendModel.name = s.data[index]["name"].toString();
                friendModel.image = s.data[index]["image"].toString();

                int cnt = 0;
                for (var item in ValidationClass.teamdata) {
                  FriendModel friendModel1 = FriendModel();
                  friendModel1 = item;
                  if (ValidationClass.settoint(
                          friendModel1.frienduserid.toString()) ==
                      friendModel.frienduserid) {
                    cnt = cnt + 1;
                  }
                }
                if (cnt == 0) {
                  ValidationClass.teamdata.add(friendModel);
                }
                // }
              });
              Provider.of<PlayerModel>(context, listen: false)
                  .refreshPlayer(ValidationClass.teamdata);
                   Navigator.pop(context);
            },
            child: Icon(
              Icons.add,
              size: 25,
            ),
          ),
        ),
      ),
    );
  }
}
