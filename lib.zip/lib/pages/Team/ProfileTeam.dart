import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/pages/Team/TeamCreate.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:http/http.dart' as http;

class ProfileTeam extends StatefulWidget {
  final data;
  ProfileTeam(this.data);
  @override
  _ProfileTeamState createState() => _ProfileTeamState(data);
}

class _ProfileTeamState extends State<ProfileTeam> {
  var data;
  _ProfileTeamState(this.data);

  Future<List<dynamic>> listteamprofilefuture;
  List players = [];

  ProgressDialog pr;

  @override
  void initState() {
    super.initState();
    // listteamprofilefuture = convertlist(
    //   data["players"],
    // );

    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);

    listteamprofilefuture = getJSONData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    List list1 = list;
    return list1;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        backgroundColor: AppColor.primaryColor,
        elevation: 0,
        // title: Column(
        //   crossAxisAlignment: CrossAxisAlignment.start,
        //   mainAxisAlignment: MainAxisAlignment.start,
        //   children: <Widget>[
        //     // AppTextStyle.textWithStroke(
        //     //     "TeamCreate", 23.0, 3.0, Colors.black, AppColor.backColor),
        //     Text(
        //       "Team Profile",
        //       style: TextStyle(fontSize: 23.0, color: Colors.white),
        //     ),
        //   ],
        // ),
        // title: Row(
        //   mainAxisAlignment: MainAxisAlignment.end,
        //   children: <Widget>[
        //     Padding(
        //       padding: const EdgeInsets.only(right: 15.0),
        //       child: Visibility(
        //         visible: ValidationClass.userid ==
        //                 ValidationClass.settoint(data["user_id"].toString())
        //             ? false
        //             : true,
        //         child: InkWell(
        //           onTap: () {
        //             Navigator.of(context).push(
        //                 MaterialPageRoute(builder: (context) => MessageChat()));
        //           },
        //           child: Icon(
        //             Icons.chat,
        //             size: 25,
        //           ),
        //         ),
        //       ),
        //     ),
        //   ],
        // ),
      ),
      body: ListView(
        children: <Widget>[
          Column(
            children: <Widget>[
              Container(
                color: AppColor.primaryColor,
                width: double.infinity,
                height: 190.0,
                child: Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      CircleAvatar(
                        backgroundImage: NetworkImage(
                          // ValidationClass.userdata["Profiledata"].toString(),
                          // Connection.profileImagePath.toString() +
                          Connection.teamImagePath.toString() +
                              data["image"].toString(),
                        ),
                        radius: 50.0,
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    TeamCreatepage(data, players),
                              ));
                        },
                        child: Text(
                          "Edit Team",
                          style: TextStyle(
                            fontSize: 12.0,
                            color: Colors.red,
                          ),
                        ),
                      ),
                      Text(
                        data["team_name"].toString(),
                        style: TextStyle(
                          fontSize: 18.0,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(
                        height: 2.0,
                      ),
                      Text(
                        data["team_size"].toString(),
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0, left: 20.0),
                    child: Container(
                      child: Text(
                        "Players",
                        style: AppTextStyle.blacktextstyle4,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 20.0, right: 10.0),
                    child: Container(
                      height: 120,
                      child: _teamprofileFuture(),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0, left: 20.0),
                    child: Container(
                      child: Text(
                        "Tournaments",
                        style: AppTextStyle.blacktextstyle4,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 5.0, horizontal: 12.0),
                    child: Column(
                      // mainAxisAlignment: MainAxisAlignment.center,
                      // crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            addcard(
                                Icon(
                                  Icons.home,
                                  size: 20,
                                ),
                                ValidationClass.settoint(
                                        data["tournament_played"].toString())
                                    .toString(),
                                // "0",
                                "Tournaments Played"),
                            addcard(
                                Icon(
                                  Icons.home,
                                  size: 20,
                                ),
                                // "0",
                                ValidationClass.settoint(
                                        data["tournament_won"].toString())
                                    .toString(),
                                "Tournaments Won"),
                          ],
                        ),
                        Row(
                          children: <Widget>[
                            addcard(
                                Icon(
                                  Icons.home,
                                  size: 20,
                                ),
                                ValidationClass.settoint(
                                        data["games_played"].toString())
                                    .toString(),

                                // "1",
                                "Games Played"),
                            addcard(
                                Icon(
                                  Icons.home,
                                  size: 20,
                                ),
                                // "0",
                                ValidationClass.settoint(
                                        data["games_won"].toString())
                                    .toString(),
                                "Games Won"),
                          ],
                        ),
                        // addcard(Icon(Icons.ac_unit), "Support", tap),
                        // addcard(Icon(Icons.ac_unit), "Logout", taplogoup),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget addcard(Icon icon, String name, String name1) {
    return Container(
      width: (MediaQuery.of(context).size.width / 2) - 12,
      // height: MediaQuery.of(context).size.width / 3.7,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              // icon,
              // SizedBox(
              //   height: 3,
              // ),
              Text(
                name.toString(),
                style: AppTextStyle.blacktextstyle3,
              ),
              SizedBox(
                height: 3,
              ),
              Container(
                child: Text(
                  name1.toString(),
                  style: AppTextStyle.blacktextstylelight2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _teamprofileFuture() {
    return FutureBuilder(
        future: listteamprofilefuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyteamprofile(s, c);
            }
          }
        });
  }

  Widget bodyteamprofile(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 2),
        scrollDirection: Axis.horizontal,
        // itemCount: myorder.length,

        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return addTeam(s, index);
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addTeam(s, int index) {
    return Container(
      width: 100,
      child: Padding(
        padding: const EdgeInsets.only(top: 4.0, right: 4.0),
        child: Material(
          elevation: 0,
          color: index == 0 || index % 2 == 0
              ? AppColor.whitecolor
              : AppColor.whitecolor,
          child: Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding:
                      const EdgeInsets.only(top: 5.0, bottom: 0.0, left: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(width: 0.0),
                      borderRadius: BorderRadius.all(Radius.circular(50.0)),
                      color: AppColor.whitecolor,
                    ),
                    // color: Colors.grey,
                    height: 70,
                    width: 70,
                    child: CircleAvatar(
                      backgroundImage: NetworkImage(
                        // ValidationClass.userdata["Profiledata"].toString(),
                        Connection.profileImagePath.toString() +
                            //     ValidationClass.userimg.toString(),
                            s.data[index]["image"].toString(),
                        // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                      ),
                      radius: 50.0,
                    ),
                    // child: Center(
                    //   child: Icon(
                    //     Icons.person,
                    //     size: 40,
                    //     color: Colors.black,
                    //   ),
                    // ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10.0, left: 4, right: 4),
                  child: Text(
                    s.data[index]["name"],
                    style: AppTextStyle.blacktextstylenormal5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<List<dynamic>> getJSONData() async {
    await pr.show();
    List<dynamic> _topplayerlist = [];

    try {
      // var res;

      // res = await http.get(
      //   Connection.topplayer.toString(),
      //   // body: {},
      //   headers: {
      //     HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
      //   },
      // );
      var searchcrite =
          "team_player_master.team_id=" + data["team_id"].toString();
      var res = await http.post(Connection.teamplayerlist, body: {
        "SpName": "App_team_player_masterGetData",
        "SearchParam": searchcrite
      });

      print("response" + res.body);
      // var decodedData = json.decode(res.body);
      var decodedData = json.decode(utf8.decode(res.bodyBytes));
      // print("data : ${decodedData['match_played']}");

      // for (var i in decodedData) {
      //   print("inside");
      //   MenuProfileModel s = MenuProfileModel(
      //       matchplayed: i["match_played"],
      //       totalkills: i["total_kills"],
      //       winprizes: i["win_prize"]);

      //   setState(() {
      //     profilelist.add(s);
      //   });
      // }

      // final int statusCode = res.statusCode;

      // var resBody;
      // if (statusCode < 200 || statusCode > 400) {
      //   resBody = [];
      // }

      // if (res.body == "null") {
      //   resBody = [];
      // } else {
      //   resBody = json.decode(res.body);
      // }
      _topplayerlist = decodedData;

      if (_topplayerlist == null) {
        _topplayerlist = [];
      }
      players = _topplayerlist;
      // print(decodedData.toString());
    } catch (e) {
      // return "Occur Error...";
    }

    pr.hide().then((isHidden) {
      print(isHidden);
    });

    return _topplayerlist;
  }
}
