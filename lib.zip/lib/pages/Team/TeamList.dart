import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/pages/Team/ProfileTeam.dart';

import 'package:proplayerwar/pages/Team/TeamCreate.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';

import 'package:proplayerwar/util/ValidationClass.dart';

import 'package:http/http.dart' as http;

class TeamList extends StatefulWidget {
  @override
  _TeamListState createState() => _TeamListState();
}

class _TeamListState extends State<TeamList> {
  Future<List<dynamic>> listteamfuture;

  @override
  void initState() {
    super.initState();
    listteamfuture = getJSONData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  // void updateImageList(BuildContext context) async {
  //   for (int i = 1; i <= 1; i++) {
  //     imageList.add(AssetImage('assets/pubg$i.png'));
  //     //* To precache images so that when required they are loaded faster.
  //     await precacheImage(AssetImage('assets/pubg$i.png'), context);
  //   }
  //   setState(() {
  //     imagePrecached = true;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: IconButton(
        //     icon: Icon(Icons.person_add),
        //     onPressed: () {

        //     },
        //   ),
        // ),
        // backgroundColor: Theme.of(context).primaryColor,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "TeamChoose", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "Team List",
              style: TextStyle(fontSize: 20.0, color: Colors.white),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
              onTap: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TeamCreatepage(0, 0),
                    ));
              },
              child: Icon(
                Icons.add,
                size: 25,
              )),
          Padding(padding: EdgeInsets.all(10.0)),
          // CartIcon(cartlist.length),
        ],
        elevation: 0,
      ),
      body: bodyTeamChoose(context),
    );
  }

  Widget bodyTeamChoose(context) {
    return _teamFuture();
  }

  Widget _teamFuture() {
    return FutureBuilder(
        future: listteamfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyteam(s, c);
            }
          }
        });
  }

  Widget bodyteam(s, c) {
    return Container(
      color: AppColor.backColor,
      child: GridView.builder(
        padding: EdgeInsets.only(top: 2),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        gridDelegate:
            new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return addTeam(s, index);
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addTeam(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 4.0, right: 4.0),
      child: Material(
        elevation: 0,
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(top: 5.0, bottom: 0.0, left: 0.0),
                child: InkWell(
                  onTap: () {
                    var data = s.data[index];
                    // data = {
                    //   // "ppw_id": s.data[index]["ppw_id"],
                    //   // "user_id": s.data[index]["user_id"],
                    //   "team_name": s.data[index]["name"],
                    //   "type": s.data[index]["type"],
                    //   // "gender": s.data[index]["gender"],
                    //   // "birth_date": s.data[index]["birth_date"],
                    //   "image": s.data[index]["image"],

                    //   "pubg_id": s.data[index]["pubg_id"],
                    //   "pubg_name": s.data[index]["pubg_name"],
                    //   "players": s.data[index]["players"],
                    //   "tournament_played": s.data[index]["tournament_played"],
                    //   "tournament_won": s.data[index]["tournament_won"],
                    //   "games_played": s.data[index]["games_played"],
                    //   "games_won": s.data[index]["games_won"],

                    //   // "match_played": s.data[index]["match_played"],
                    //   // "total_kills": s.data[index]["total_kills"],
                    //   // "point": s.data[index]["point"]
                    // };

                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ProfileTeam(data),
                        ));
                  },
                  // child: Container(
                  //   decoration: BoxDecoration(
                  //     border: Border.all(width: 0.0),
                  //     borderRadius: BorderRadius.all(Radius.circular(50.0)),
                  //     color: AppColor.whitecolor,
                  //   ),
                  //   height: 100,
                  //   width: 100,
                  //   // color: AppColor.primaryColor,
                  //   // child: Image.asset(
                  //   //   "assets/plate1.png",
                  //   //   fit: BoxFit.cover,
                  //   // ),

                  //   child: CircleAvatar(

                  //     child: CachedNetworkImage(
                  //       imageUrl:
                  //           "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
                  //       placeholder: (context, url) =>
                  //           CircularProgressIndicator(),
                  //       // CircularProgressIndicator(),
                  //       errorWidget: (context, url, error) =>
                  //           new Icon(Icons.error),
                  //     ),
                  //   ),

                  //   // child:  Image.network(

                  //   //       _imageUrl,
                  //   //       fit: BoxFit.cover,
                  //   //     ),
                  //   // child: ClipRRect(
                  //   //   child: Icon(
                  //   //     Icons.person,
                  //   //     size: 75,
                  //   //     color: AppColor.whitecolor,
                  //   //   ),
                  //   // ),

                  //   // child: ClipRRect(

                  //   //   borderRadius: BorderRadius.circular(50),
                  //   //   child: SizedBox(
                  //   //     width: 100,
                  //   //     height: 100,
                  //   //     child: Image.network(
                  //   //       _imageUrl,
                  //   //       fit: BoxFit.cover,
                  //   //     ),
                  //   //   ),
                  //   // ),
                  // ),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(width: 0.0),
                      borderRadius: BorderRadius.all(Radius.circular(50.0)),
                      color: AppColor.whitecolor,
                    ),
                    // color: Colors.grey,
                    height: 50,
                    width: 50,
                    child: CircleAvatar(
                      backgroundImage: NetworkImage(
                        // ValidationClass.userdata["Profiledata"].toString(),
                        // Connection.profileImagePath.toString() +
                        //     ValidationClass.userimg.toString(),
                        Connection.teamImagePath.toString() +
                            s.data[index]["image"].toString(),
                        // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                      ),
                      radius: 50.0,
                    ),
                    // child: Center(
                    //   child: Icon(
                    //     Icons.person,
                    //     size: 40,
                    //     color: Colors.black,
                    //   ),
                    // ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: Text(
                  s.data[index]["game_name"],
                  // "PUBG Mobile",
                  style: AppTextStyle.bluetextstyle,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 1.0),
                child: Container(
                  child: Text(
                    s.data[index]["team_name"],
                    style: AppTextStyle.blacktextstyle5,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 1.0),
                child: Text(
                  s.data[index]["team_size"],
                  // "Squad",
                  style: AppTextStyle.blacktextstylelight2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<List<dynamic>> getJSONData() async {
    List<dynamic> _teamlist = [];

    try {
      var searchcrite =
          "team_master.user_id=" + ValidationClass.userid.toString();
      var res = await http.post(Connection.teamlist, body: {
        "SpName": "App_team_masterGetData",
        "SearchParam": searchcrite
      });

      print("response" + res.body);
      // var decodedData = json.decode(res.body);
      var decodedData = json.decode(utf8.decode(res.bodyBytes));
      _teamlist = decodedData;

      if (_teamlist == null) {
        _teamlist = [];
      }

      // print(decodedData.toString());
    } catch (e) {
      // return "Occur Error...";
    }

    return _teamlist;
  }
}
