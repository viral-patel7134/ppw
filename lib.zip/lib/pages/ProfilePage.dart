import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:intl/intl.dart';
import 'package:proplayerwar/pages/Followers.dart';
import 'package:proplayerwar/pages/MessageChat.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:http/http.dart' as http;
import 'package:proplayerwar/util/ValidationClass.dart';

class ProfilePage extends StatefulWidget {
  final data;
  ProfilePage(this.data);
  @override
  _ProfilePageState createState() => _ProfilePageState(data);
}

class _ProfilePageState extends State<ProfilePage> {
  var data;
  _ProfilePageState(this.data);

  var follow = "Follow";
  var _formattedfollowers;
  var _formattedfollowing;
  var isloader = false;
  var follower;
  var following;

  @override
  void initState() {
    super.initState();

    // if (ValidationClass.settoint(data["followed"].toString()) == 1) {
    //   follow = "UnFollow";
    // } else {
    //   follow = "Follow";
    // }
    followgetdata();

    follower = ValidationClass.settodouble(data["followers"].toString());
    following = ValidationClass.settodouble(data["following"].toString());
    _formattedfollowers = NumberFormat.compact().format(follower);
    _formattedfollowing = NumberFormat.compact().format(following);
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        backgroundColor: AppColor.primaryColor,
        elevation: 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 15.0),
              child: Visibility(
                visible: false,
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => MessageChat()));
                  },
                  child: Icon(
                    Icons.chat,
                    size: 25,
                  ),
                ),
              ),
              // child: Visibility(
              //   visible: ValidationClass.userid ==
              //           ValidationClass.settoint(data["user_id"].toString())
              //       ? false
              //       : true,
              //   child: InkWell(
              //     onTap: () {
              //       Navigator.of(context).push(
              //           MaterialPageRoute(builder: (context) => MessageChat()));
              //     },
              //     child: Icon(
              //       Icons.chat,
              //       size: 25,
              //     ),
              //   ),
              // ),
            ),
          ],
        ),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(bottom: 15.0),
            child: Container(
              color: AppColor.primaryColor,
              width: double.infinity,
              // height: 270.0,
              child: Center(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    CircleAvatar(
                      backgroundImage: NetworkImage(
                        // ValidationClass.userdata["Profiledata"].toString(),
                        Connection.profileImagePath.toString() +
                            data["image"].toString(),
                      ),
                      radius: 50.0,
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Text(
                      data["name"].toString(),
                      style: TextStyle(
                        fontSize: 20.0,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      height: 5.0,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Card(
                        margin: EdgeInsets.symmetric(
                            horizontal: 20.0, vertical: 5.0),
                        clipBehavior: Clip.antiAlias,
                        color: AppColor.primaryColor,
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8.0, vertical: 10.0),
                          child: Row(

                            children: <Widget>[
                              Expanded(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                Followers("FOLLOWER", data)));
                                  },
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        //  data["name"].toString(),
                                        _formattedfollowers.toString(),
                                        // "17k",
                                        style: AppTextStyle.whitetextstyle6,
                                      ),
                                      SizedBox(
                                        height: 5.0,
                                      ),
                                      Text(
                                        "followers",
                                        style: AppTextStyle.whitetextstyle3,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                Followers("FOLLOWING", data)));
                                  },
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        //  data["name"].toString(),
                                        _formattedfollowing.toString(),
                                        style: AppTextStyle.whitetextstyle6,
                                      ),
                                      SizedBox(
                                        height: 5.0,
                                      ),
                                      Text(
                                        "following",
                                        style: AppTextStyle.whitetextstyle3,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Visibility(
                                visible: ValidationClass.userid ==
                                    ValidationClass.settoint(
                                        data["user_id"].toString())
                                    ? false
                                    : true,
                                child: Expanded(
                                  child: Column(
                                    children: <Widget>[
                                      InkWell(
                                        onTap: () {
                                          followrequest();
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              color: follow == "Follow"
                                                  ? Colors.redAccent
                                                  : Colors.greenAccent),
                                          // color: AppColor.buttonColor,
                                          child: Padding(
                                            padding: const EdgeInsets.all(10.0),
                                            child: isloader == true
                                                ? Container(
                                                    width: 15,
                                                    height: 15,
                                                    child:
                                                        CircularProgressIndicator(
                                                      valueColor:
                                                          AlwaysStoppedAnimation<
                                                                  Color>(
                                                              Colors.red),
                                                    ),
                                                  )
                                                : Text(
                                                    follow.toString(),
                                                    style: follow == "Follow"
                                                        ? AppTextStyle
                                                            .whitetextstyle7
                                                        : AppTextStyle
                                                            .blacktextstyle7,
                                                  ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0, left: 20.0),
                    child: Container(
                      child: Text(
                        "Tournaments",
                        style: AppTextStyle.blacktextstyle1,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 5.0, horizontal: 12.0),
                    child: Column(
                      // mainAxisAlignment: MainAxisAlignment.center,
                      // crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            addcard(
                                Icon(
                                  Icons.home,
                                  size: 20,
                                ),
                                //  data["name"].toString(),
                                ValidationClass.settodouble(
                                        data["win_prize"].toString())
                                    .toString(),
                                "Games Earnings"),
                            addcard(
                                Icon(
                                  Icons.home,
                                  size: 20,
                                ),
                                ValidationClass.settoint(
                                        data["match_played"].toString())
                                    .toString(),
                                "Games Played"),
                          ],
                        ),
                        Row(
                          children: <Widget>[
                            addcard(
                                Icon(
                                  Icons.home,
                                  size: 20,
                                ),
                                ValidationClass.settodouble(
                                        data["tournament_won"].toString())
                                    .toString(),
                                "Tournament Earnings"),
                            addcard(
                                Icon(
                                  Icons.home,
                                  size: 20,
                                ),
                                ValidationClass.settoint(
                                        data["tournament_played"].toString())
                                    .toString(),
                                "Tournament Played"),
                          ],
                        ),
                        // addcard(Icon(Icons.ac_unit), "Support", tap),
                        // addcard(Icon(Icons.ac_unit), "Logout", taplogoup),
                      ],
                    ),
                  ),
                  // Padding(
                  //   padding: const EdgeInsets.only(top: 8.0, left: 20.0),
                  //   child: Container(s
                  //     child: Text(
                  //       "About",
                  //       style: AppTextStyle.blacktextstyle1,
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget addcard(Icon icon, String name, String name1) {
    return Container(
      width: (MediaQuery.of(context).size.width / 2) - 12,
      // height: MediaQuery.of(context).size.width / 3.7,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              // icon,
              // SizedBox(
              //   height: 3,
              // ),
              Text(
                name.toString(),
                style: AppTextStyle.blacktextstyle3,
              ),
              SizedBox(
                height: 3,
              ),
              Container(
                child: Text(
                  name1.toString(),
                  style: AppTextStyle.blacktextstyle5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<List<dynamic>> followrequest() async {
    List<dynamic> _list = [];

    try {
      setState(() {
        isloader = true;
      });
      var res;

      res = await http.post(
        Connection.follow.toString(),
        body: {
          "user_id": ValidationClass.userid.toString(),
          "follow_id": data["user_id"].toString(),
          "followed": follow == "Follow" ? "1" : "0"
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);
      var decodedData = json.decode(res.body);

      List resultlist = decodedData["Table"];
      List followerlist = decodedData["Table1"];

      if (followerlist.length > 0) {
        _formattedfollowers = NumberFormat.compact().format(
            ValidationClass.settoint(followerlist[0]['followers'].toString()));

        _formattedfollowing = NumberFormat.compact().format(
            ValidationClass.settoint(followerlist[0]['following'].toString()));
        // _formattedfollowers = NumberFormat.compact().format(follower - 1);
      }
      setState(() {
        if (resultlist[0]['Flag'] == "1") {
          if (follow == "Follow") {
            follow = "UnFollow";
          } else {
            follow = "Follow";
          }
        } else if (resultlist[0]['Flag'] == "2") {
          ValidationClass.onBasicAlertPressed(
              context, "Validation", "Friend Already in Team....");
          // Fluttertoast.showToast(msg: "Friend Already in Team....");
        }
      });

      // print("data : ${decodedData['match_played']}");

      // for (var i in decodedData) {
      //   print("inside");
      //   MenuProfileModel s = MenuProfileModel(
      //       matchplayed: i["match_played"],
      //       totalkills: i["total_kills"],
      //       winprizes: i["win_prize"]);

      //   setState(() {
      //     profilelist.add(s);
      //   });
      // }

      // final int statusCode = res.statusCode;

      // var resBody;
      // if (statusCode < 200 || statusCode > 400) {
      //   resBody = [];
      // }

      // if (res.body == "null") {
      //   resBody = [];
      // } else {
      //   resBody = json.decode(res.body);
      // }

      // setState(() {
      //   _list = decodedData;
      // });

      // print(decodedData.toString());

    } catch (e) {
      setState(() {
        isloader = false;
      }); // return "Occur Error...";
    }
    setState(() {
      isloader = false;
    }); // return "Occur Error...";
    // await ValidationClass.hubConnection
    //     .invoke('followuser', args: [ValidationClass.userid.toString()]);

    return _list;
  }

  Future<List<dynamic>> followgetdata() async {
    List<dynamic> _list = [];

    try {
      setState(() {
        isloader = true;
      });
      var res;

      res = await http.post(
        Connection.followdata.toString(),
        body: {
          "user_id": ValidationClass.userid.toString(),
          "follow_id": data["user_id"].toString()
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);
      // var decodedData = json.decode(res.body);
      var decodedData = json.decode(utf8.decode(res.bodyBytes));

      List resultlist = decodedData["Table"];
      List followerlist = decodedData["Table1"];

      setState(() {
        if (resultlist[0]['followed'].toString() == "1") {
          follow = "UnFollow";
        } else {
          follow = "Follow";
        }

        if (followerlist.length > 0) {
          _formattedfollowers = NumberFormat.compact().format(
              ValidationClass.settoint(
                  followerlist[0]['followers'].toString()));

          _formattedfollowing = NumberFormat.compact().format(
              ValidationClass.settoint(
                  followerlist[0]['following'].toString()));
          // _formattedfollowers = NumberFormat.compact().format(follower - 1);
        }
      });

      // print("data : ${decodedData['match_played']}");

      // for (var i in decodedData) {
      //   print("inside");
      //   MenuProfileModel s = MenuProfileModel(
      //       matchplayed: i["match_played"],
      //       totalkills: i["total_kills"],
      //       winprizes: i["win_prize"]);

      //   setState(() {
      //     profilelist.add(s);
      //   });
      // }

      // final int statusCode = res.statusCode;

      // var resBody;
      // if (statusCode < 200 || statusCode > 400) {
      //   resBody = [];
      // }

      // if (res.body == "null") {
      //   resBody = [];
      // } else {
      //   resBody = json.decode(res.body);
      // }

      // setState(() {
      //   _list = decodedData;
      // });

      // print(decodedData.toString());
    } catch (e) {
      setState(() {
        isloader = false;
      }); // return "Occur Error...";
    }
    setState(() {
      isloader = false;
    }); // return "Occur Error...";

    return _list;
  }
}
