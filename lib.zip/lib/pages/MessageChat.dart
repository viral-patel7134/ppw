import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';

class MessageChat extends StatefulWidget {
  @override
  _MessageChatState createState() => _MessageChatState();
}

class _MessageChatState extends State<MessageChat> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: Icon(
        //     Icons.home,
        //     size: 30,
        //   ),
        // ),
        // backgroundColor: Theme.of(context).primaryColor,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "TeamChoose", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "Alice James",
              style: TextStyle(fontSize: 20.0, color: Colors.white),
            ),
          ],
        ),
        // actions: <Widget>[
        //   InkWell(
        //       onTap: () {},
        //       child: Icon(
        //         Icons.power_settings_new,
        //         size: 35,
        //       )),
        //   Padding(padding: EdgeInsets.all(10.0)),
        //   // CartIcon(cartlist.length),
        // ],
        elevation: 0,
      ),
      body: bodyTeamChoose(context),
    );
  }

  Widget bodyTeamChoose(context) {
    return Column(
      children: <Widget>[
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.only(bottom: 5, top: 5.0),
            scrollDirection: Axis.vertical,
            // itemCount: myorder.length,
            reverse: true,
            itemCount: 20,
            itemBuilder: (BuildContext context, int index) {
              return Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 5.0),
                    child: index % 2 == 0
                        ? Padding(
                            padding: const EdgeInsets.only(left: 50.0),
                            child: addcard(index, context, true),
                          )
                        : Padding(
                            padding: const EdgeInsets.only(right: 50.0),
                            child: addcard(index, context, false),
                          ),
                  ),
                ],
              );
            },
          ),
        ),
        new Container(
          height: MediaQuery.of(context).size.height / 12,
          child: new Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              new Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Material(
                    child: new Container(
                      child: new TextField(
                        autofocus: false,
                        decoration: InputDecoration(
                          suffixIcon: InkWell(
                            onTap: () {},
                            child: Icon(
                              Icons.send,
                              size: 30,
                            ),
                          ),
                          contentPadding: EdgeInsets.all(9.0),
                          border: InputBorder.none,
                          hintText: 'Please enter text',
                        ),
                      ),
                      width: MediaQuery.of(context).size.width - 10,
                    ),
                    elevation: 4.0,
                    /*borderRadius: new BorderRadius.all(new Radius.circular(45.0)),*/
                    clipBehavior: Clip.antiAlias,
                    type: MaterialType.card,
                  )
                ],
              ),
              // new Column(
              //   mainAxisAlignment: MainAxisAlignment.spaceAround,
              //   children: <Widget>[
              //     new Container(
              //       child: new Icon(
              //         Icons.send,
              //         size: 30,
              //       ),
              //       width: MediaQuery.of(context).size.height / 20,
              //     ),
              //   ],
              // ),
              // new Column(
              //   mainAxisAlignment: MainAxisAlignment.spaceAround,
              //   children: <Widget>[
              //     new Container(
              //       child: Text('HELLO C1'),
              //       color: Colors.green,
              //       width: MediaQuery.of(context).size.height / 6,
              //     ),
              //   ],
              // )
            ],
          ),
        ),
      ],
    );
  }

  Widget addcard(int index, BuildContext context, bool left) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: AppColor.backColor,
        // color: Colors.redAccent,
      ),
      width: MediaQuery.of(context).size.width - 60,
      // height: 80,

      child: Column(
        crossAxisAlignment:
            left == true ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: AppColor.successbtn,
              // color: Colors.redAccent,
            ),
            child: Padding(
              padding: const EdgeInsets.all(6.0),
              child: Column(
                crossAxisAlignment: left == true
                    ? CrossAxisAlignment.end
                    : CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    left == true ? "Viru" : "Alice James",
                    style: AppTextStyle.msghead,
                  ),
                  Text(
                    "Under which circumstances textAlign property works in Flutter",
                    style: AppTextStyle.msg,
                    textAlign: left == true ? TextAlign.right : TextAlign.left,
                  ),
                  Text(
                    "9:18 pm",
                    style: AppTextStyle.msgtime,
                    textAlign: left == true ? TextAlign.right : TextAlign.left,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
