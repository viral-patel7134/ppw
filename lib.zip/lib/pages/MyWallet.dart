import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:provider/provider.dart';
import 'package:proplayerwar/pages/payment/PaymentPage.dart';
import 'package:proplayerwar/pages/payment/WithdrawPage.dart';

import 'package:http/http.dart' as http;

import 'package:proplayerwar/model/WalletModel.dart';

class MyWallet extends StatefulWidget {
  @override
  _MyWalletState createState() => _MyWalletState();
}

class _MyWalletState extends State<MyWallet> {
  int requestcount = 5;

  @override
  void initState() {
    super.initState();
    getJSONData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  Future<List<dynamic>> getJSONData() async {
    List<dynamic> _profilelist = [];

    try {
      var res;

      res = await http.post(
        Connection.walletdata.toString(),
        body: {"user_id": ValidationClass.userid.toString()},
        // headers: {
        //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // },
      );

      print("response" + res.body);

      // var aa = json.decode(res.body);
      var aa = json.decode(utf8.decode(res.bodyBytes));

      List walletlist = aa["Table"];

      var transactionlist = convertlist(aa["Table1"]);
      var wallet =
          ValidationClass.settodouble(walletlist[0]["wallet"].toString());
      var bonuswallet =
          ValidationClass.settodouble(walletlist[0]["bonus_wallet"].toString());

      Provider.of<WalletModel>(context, listen: false)
          .refreshwallet(wallet, bonuswallet, transactionlist);
      // walletmodel.refreshwallet(wallet, bonuswallet, transactionlist);

    } catch (e) {
      // return "Occur Error...";
    }

    return _profilelist;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        backgroundColor: AppColor.primaryColor,
        elevation: 0,
        // actions: <Widget>[
        //   Container(
        //     width: 60,
        //     // color: Colors.green,
        //     alignment: Alignment.center,
        //     child: Padding(
        //       padding: const EdgeInsets.all(10.0),
        //       child: InkWell(
        //         onTap: () {
        //           Navigator.of(context).push(
        //               MaterialPageRoute(builder: (context) => FriendRequest()));
        //         },
        //         child: Stack(
        //           children: <Widget>[
        //             Icon(
        //               Icons.people,
        //               color: Colors.white,
        //               size: 25,
        //             ),
        //             requestcount.toString() != "0"
        //                 ? Align(
        //                     alignment: Alignment.topRight,
        //                     child: Container(
        //                       height: 20,
        //                       width: 30,
        //                       decoration: BoxDecoration(
        //                           shape: BoxShape.circle, color: Colors.red),
        //                       child: Center(
        //                         child: Text(
        //                           requestcount.toString(),
        //                           style: TextStyle(
        //                               fontSize: 12, color: Colors.white),
        //                         ),
        //                       ),
        //                     ),
        //                   )
        //                 : Text("")
        //           ],
        //         ),
        //       ),
        //     ),
        //   ),
        // ],
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "Tournament", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "My Wallet",
              style: TextStyle(fontSize: 20.0, color: Colors.white),
            ),
          ],
        ),
        // actions: <Widget>[
        //   InkWell(
        //       onTap: () {},
        //       child: Icon(
        //         Icons.power_settings_new,
        //         size: 35,
        //       )),
        //   Padding(padding: EdgeInsets.all(10.0)),
        //   // CartIcon(cartlist.length),
        // ],
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Column(
              children: <Widget>[
                Container(
                  color: AppColor.whitecolor,
                  height: 100,
                  child: Row(
                     crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(left:8.0),
                              child: Text(
                                "Total Coin",
                                style: AppTextStyle.blacktextstylelight,
                              ),
                            ),
                            Consumer<WalletModel>(
                              builder: (context, walletmodel, child) {
                                return Row(
                                  children: <Widget>[
                                    Image.asset(
                                      "assets/coin.png",
                                      height: 50,
                                      width: 50,
                                    ),
                                    Text(
                                      "${ValidationClass.settodouble(walletmodel.wallet.toString()) + ValidationClass.settodouble(walletmodel.bonuswallet.toString())}",
                                      style: AppTextStyle.blacktextstyle3,
                                    ),
                                  ],
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          // tripEditModalBottomSheet(context, "Add Cash");

                          showDialog(
                              context: context,
                              builder: (context) => PaymentPage("Add Coin"));
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(right: 15.0),
                          child: Container(
                            decoration: BoxDecoration(
                                // border: Border.all(width: 0.0),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5.0)),
                                color: Colors.green),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Add Coin",
                                style: AppTextStyle.whitetextstyle2,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 1,
                ),
                Container(
                  color: AppColor.whitecolor,
                  height: 80,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              "Main Coin",
                              style: AppTextStyle.blacktextstylelight,
                            ),
                            Consumer<WalletModel>(
                              builder: (context, walletmodel, child) {
                                return Row(
                                  children: <Widget>[
                                    Image.asset(
                                      "assets/coin.png",
                                      height: 30,
                                      width: 30,
                                    ),
                                    Text(
                                      "${walletmodel.wallet.toString()}",
                                      style: AppTextStyle.blacktextstyle4,
                                    ),
                                  ],
                                );
                              },
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width / 1.5,
                              child: Text(
                                "minimum coin you can withdraw 100",
                                style: AppTextStyle.blacktextstylelight,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          // tripEditModalBottomSheet(context, "Withdraw");
                          showDialog(
                              context: context,
                              builder: (context) => WithdrawPage("Withdraw"));
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(right: 15.0),
                          child: Container(
                            decoration: BoxDecoration(
                                // border: Border.all(width: 0.0),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5.0)),
                                color: Colors.green),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Withdraw",
                                style: AppTextStyle.whitetextstyle2,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 1,
                ),
                Container(
                  color: AppColor.whitecolor,
                  height: 80,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              "Bonus",
                              style: AppTextStyle.blacktextstylelight,
                            ),
                            Consumer<WalletModel>(
                              builder: (context, walletmodel, child) {
                                return Row(
                                  children: <Widget>[
                                    Image.asset(
                                      "assets/coin.png",
                                      height: 30,
                                      width: 30,
                                    ),
                                    Text(
                                      "${walletmodel.bonuswallet.toString()}",
                                      style: AppTextStyle.blacktextstyle4,
                                    ),
                                  ],
                                );
                              },
                            ),
                            Text(
                              "Maximum usable bonus as per match fees",
                              style: AppTextStyle.blacktextstylelight,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  color: AppColor.whitecolor,
                  height: 35,
                  child: Center(child: Text("My Transaction")),
                ),
                SizedBox(
                  height: 1,
                ),
                Consumer<WalletModel>(
                  builder: (context, model, child) {
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 0.0),
                        child: _transactionFuture(model.listtransaction),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          // SizedBox(
          //   height: 20.0,
          // ),
        ],
      ),
    );
  }

  Widget _transactionFuture(listtransaction) {
    return FutureBuilder(
        future: listtransaction,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodytransaction(s, c);
            }
          }
        });
  }

  Widget bodytransaction(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 0),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(0.0),
            child: Column(
              children: <Widget>[
                addcardtransaction(s, index),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addcardtransaction(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 0.5),
      child: Container(
        color: AppColor.whitecolor,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 15.0, top: 8.0, bottom: 8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    s.data[index]["description"]
                        .toString(), // "ATM Transaction",
                    style: AppTextStyle.blacktextstyle5,
                  ),
                  Text(
                    s.data[index]["datetime1"].toString(),
                    style: AppTextStyle.blacktextstylelight,
                  ),
                ],
              ),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(right: 15.0, top: 8.0, bottom: 8.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    s.data[index]["addless"] == "ADD"
                        ? "${s.data[index]["amount"].toString()} Cr"
                        : "${s.data[index]["amount"].toString()} Dr",
                    style: AppTextStyle.blacktextstyle5,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
