import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/pages/ProfilePage.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';

class FriendRequest extends StatefulWidget {
  @override
  _FriendRequestState createState() => _FriendRequestState();
}

class _FriendRequestState extends State<FriendRequest> {
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: IconButton(
        //     icon: Icon(Icons.person_add),
        //     onPressed: () {
        //       scaffoldKey.currentState.openDrawer();
        //     },
        //   ),
        // ),
        // backgroundColor: Theme.of(context).primaryColor,
        // title: Column(
        //   crossAxisAlignment: CrossAxisAlignment.start,
        //   mainAxisAlignment: MainAxisAlignment.start,
        //   children: <Widget>[
        //     // AppTextStyle.textWithStroke(
        //     //     "TopPlayer", 23.0, 3.0, Colors.black, AppColor.backColor),
        //     Text(
        //       "Top Player",
        //       style: TextStyle(fontSize: 23.0, color: Colors.white),
        //     ),
        //   ],
        // ),

        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "Tournament", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "Friend Request",
              style: TextStyle(fontSize: 23.0, color: Colors.white),
            ),
          ],
        ),

        elevation: 0,
      ),
      body: bodyTopPlayer(context),
      // drawer: Drawer(
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.start,
      //     crossAxisAlignment: CrossAxisAlignment.start,
      //     children: <Widget>[
      //       // DrawerHeader(
      //       //   decoration: BoxDecoration(color: Colors.red),
      //       //   margin: EdgeInsets.all(0.0),
      //       //   padding: EdgeInsets.all(0.0),
      //       //   child: TextField(
      //       //     autofocus: false,
      //       //     decoration: InputDecoration(
      //       //       contentPadding: EdgeInsets.all(9.0),
      //       //       border: InputBorder.none,
      //       //       hintText: 'Please enter text',
      //       //     ),
      //       //   ),
      //       // ),
      //       SizedBox(
      //         height: 25,
      //       ),
      //       Padding(
      //         padding: const EdgeInsets.all(2.0),
      //         child: Container(
      //           color: AppColor.primaryColor,
      //           child: TextField(
      //             style: AppTextStyle.whitetextstyle1,
      //             autofocus: false,
      //             decoration: InputDecoration(
      //                 // suffixIcon: InkWell(
      //                 //   onTap: () {},
      //                 //   child: Icon(
      //                 //     Icons.search,
      //                 //     size: 25,
      //                 //     color: AppColor.whitecolor,
      //                 //   ),
      //                 // ),
      //                 prefixIcon: Icon(
      //                   Icons.search,
      //                   size: 25,
      //                   color: AppColor.whitecolor,
      //                 ),
      //                 contentPadding: EdgeInsets.all(15.0),
      //                 border: InputBorder.none,
      //                 hintText: 'Search Here..',
      //                 hintStyle: AppTextStyle.whitetextstyle1),
      //           ),
      //         ),
      //       ),
      //       Expanded(
      //         child: ListView.builder(
      //           padding: EdgeInsets.only(top: 0),
      //           scrollDirection: Axis.vertical,

      //           // itemCount: myorder.length,
      //           itemCount: 20,
      //           itemBuilder: (BuildContext context, int index) {
      //             return addFriend(index, context);
      //           },
      //         ),
      //       ),
      //     ],
      //   ),
      // ),
    );
  }

  Widget bodyTopPlayer(context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.only(top: 0),
            scrollDirection: Axis.vertical,

            // itemCount: myorder.length,
            itemCount: 20,
            itemBuilder: (BuildContext context, int index) {
              return addFriend(index, context);
            },
          ),
        ),
      ],
    );
  }

  Widget addFriend(int index, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 1.0),
      child: Material(
        elevation: 0,
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        child: ListTile(
          leading: Padding(
            padding: const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
            child: InkWell(
              onTap: () {
                var data;
                data = {
                  // "ppw_id": s.data[index]["ppw_id"],
                  // "user_id": s.data[index]["user_id"],
                  // "name": s.data[index]["name"],
                  // "mobile": s.data[index]["mobile"],
                  // "gender": s.data[index]["gender"],
                  // "birth_date": s.data[index]["birth_date"],
                  // "image": s.data[index]["image"],
                  // "pubg_id": s.data[index]["pubg_id"],
                  // "pubg_name": s.data[index]["pubg_name"],
                  // "pubg_level": s.data[index]["pubg_level"],
                  // "match_played": s.data[index]["match_played"],
                  // "total_kills": s.data[index]["total_kills"],
                  // "point": s.data[index]["point"]
                };

                Navigator.push(context,
                    MaterialPageRoute(builder: (c) => ProfilePage(data)));
              },
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(width: 0.0),
                  borderRadius: BorderRadius.all(Radius.circular(5.0)),
                  color: AppColor.whitecolor,
                ),
                // color: Colors.grey,
                height: 40,
                width: 40,
                child: Center(
                  child: Icon(
                    Icons.person,
                    size: 40,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
          title: Column(
            children: <Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Padding(
                      padding: const EdgeInsets.only(top: 0.0, left: 0.0),
                      child: Text(
                        "Viral Patel",
                        style: AppTextStyle.blacktextstyle5,
                      )),
                  Text(
                    "9:00 pm",
                    style: AppTextStyle.blacktextstylelight,
                  ),
                ],
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 2.0, left: 0.0),
                    child: Container(
                      height: 25,
                      width: 70,
                      decoration: BoxDecoration(
                        border: Border.all(width: 0.0),
                        borderRadius: BorderRadius.all(Radius.circular(5.0)),
                        color: AppColor.greyColor,
                      ),
                      child: Center(
                        child: Text(
                          "Confirm",
                          style: AppTextStyle.whitetextstylenormal2,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 2.0, left: 10.0),
                    child: Container(
                      height: 25,
                      width: 70,
                      decoration: BoxDecoration(
                        border: Border.all(width: 0.0),
                        borderRadius: BorderRadius.all(Radius.circular(5.0)),
                        color: AppColor.greyColor,
                      ),
                      child: Center(
                        child: Text(
                          "Delete",
                          style: AppTextStyle.whitetextstylenormal2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
