import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/Connection/Connection.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';

import 'package:http/http.dart' as http;
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:proplayerwar/pages/GameVerify.dart';

class GameList extends StatefulWidget {
  @override
  _GameListState createState() => _GameListState();
}

class _GameListState extends State<GameList> {
  Future<List<dynamic>> listgamefuture;

  @override
  void initState() {
    super.initState();

    listgamefuture = getJSONData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        backgroundColor: AppColor.primaryColor,
        elevation: 0,

        title: Text(
          "Verified Game List",
          style: AppTextStyle.whitetextstyle1,
        ),
        // actions: <Widget>[
        //   Container(
        //     width: 60,
        //     // color: Colors.green,
        //     alignment: Alignment.center,
        //     child: Padding(
        //       padding: const EdgeInsets.all(10.0),
        //       child: InkWell(
        //         onTap: () {
        //           Navigator.of(context).push(
        //               MaterialPageRoute(builder: (context) => FriendRequest()));
        //         },
        //         child: Stack(
        //           children: <Widget>[
        //             Icon(
        //               Icons.people,
        //               color: Colors.white,
        //               size: 25,
        //             ),
        //             requestcount.toString() != "0"
        //                 ? Align(
        //                     alignment: Alignment.topRight,
        //                     child: Container(
        //                       height: 20,
        //                       width: 30,
        //                       decoration: BoxDecoration(
        //                           shape: BoxShape.circle, color: Colors.red),
        //                       child: Center(
        //                         child: Text(
        //                           requestcount.toString(),
        //                           style: TextStyle(
        //                               fontSize: 12, color: Colors.white),
        //                         ),
        //                       ),
        //                     ),
        //                   )
        //                 : Text("")
        //           ],
        //         ),
        //       ),
        //     ),
        //   ),
        // ],
      ),
      body: bodygameChoose(context),
    );
  }

  Widget bodygameChoose(context) {
    return _gameFuture();
  }

  Widget _gameFuture() {
    return FutureBuilder(
        future: listgamefuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodygame(s, c);
            }
          }
        });
  }

  Widget bodygame(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 0),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return addcard(s, index);
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addcard(s, int index) {
    return InkWell(
      onTap: () {
        if (s.data[index]["is_verification"].toString() == "1") {
        //  } else if (s.data[index]["is_canceled"].toString() == "1") {
        } else if (s.data[index]["is_requested"].toString() == "1" && s.data[index]["is_canceled"].toString() == "0") {
        } else {
          var data = s.data[index];
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => GameVerify(data),
              ));
        }
      },
      child: Padding(
        padding:
            const EdgeInsets.only(bottom: 4.0, left: 2.0, right: 2.0, top: 2.0),
        child: Container(
          color: AppColor.whitecolor,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Container(
                    height: 70,
                    width: 70,
                    color: AppColor.primaryColor,
                    child: CachedNetworkImage(
                      fit: BoxFit.fill,
                      imageUrl:
                          '${Connection.gameImagePath}/${s.data[index]["image"]}',
                      // "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
                      placeholder: (context, url) =>
                          CircularProgressIndicator(),
                      // CircularProgressIndicator(),
                      errorWidget: (context, url, error) =>
                          new Icon(Icons.error),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          s.data[index]["game_name"].toString(),
                          style: AppTextStyle.blacktextstyle4,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Container(
                          width: 150,
                          child: Text(
                            s.data[index]["is_verification"].toString() == "1"
                                ? ""
                                : s.data[index]["remark"].toString(),
                            style: AppTextStyle.blacktextstylelight,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(right: 20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      width: 80,
                      child: Text(
                        s.data[index]["is_verification"].toString() == "1"
                            ? "Verified"
                            : s.data[index]["is_canceled"].toString() == "1"
                                ? "Rejected"
                                : s.data[index]["is_requested"].toString() ==
                                        "1"
                                    ? "Waiting For Approval"
                                    : "Verify Now",
                        textAlign: TextAlign.center,
                        style:
                            s.data[index]["is_verification"].toString() == "1"
                                ? TextStyle(
                                    fontSize: 11.0,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.green)
                                : TextStyle(
                                    fontSize: 11.0,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.red),
                      ),
                    ),
                    s.data[index]["is_verification"].toString() == "1"
                        ? Icon(
                            Icons.verified_user,
                            color: Colors.green,
                            size: 16,
                          )
                        : s.data[index]["is_canceled"].toString() == "1"
                            ? Icon(
                                Icons.cancel,
                                color: Colors.red,
                                size: 16,
                              )
                            : s.data[index]["is_requested"].toString() == "1"
                                ? Icon(
                                    Icons.warning,
                                    color: Colors.red,
                                    size: 16,
                                  )
                                : Icon(
                                    Icons.contacts,
                                    color: Colors.red,
                                    size: 16,
                                  )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<List<dynamic>> getJSONData() async {
    List<dynamic> _profilelist = [];

    try {
      var res;

      res = await http.post(
        Connection.gameverifylist.toString(),
        body: {"user_id": ValidationClass.userid.toString()},
        // headers: {
        //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // },
      );

      print("response" + res.body);
      var decodedData = json.decode(res.body);
      _profilelist = decodedData;

      // print("data : ${decodedData['match_played']}");

      // matchplayed = decodedData['match_played'];
      // matchkills = decodedData['total_kills'];
      // matchprizewon = decodedData['win_prize'];

      // for (var i in decodedData) {
      //   print("inside");
      //   MenuProfileModel s = MenuProfileModel(
      //       matchplayed: i["match_played"],
      //       totalkills: i["total_kills"],
      //       winprizes: i["win_prize"]);

      //   setState(() {
      //     profilelist.add(s);
      //   });
      // }

      // final int statusCode = res.statusCode;

      // var resBody;
      // if (statusCode < 200 || statusCode > 400) {
      //   resBody = [];
      // }

      // if (res.body == "null") {
      //   resBody = [];
      // } else {
      //   resBody = json.decode(res.body);
      // }

      // setState(() {
      //   profilelist = decodedData;
      // });

      // print(decodedData.toString());
    } catch (e) {
      // return "Occur Error...";
    }

    return _profilelist;
  }
}
