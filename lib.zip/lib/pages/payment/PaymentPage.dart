import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/model/WalletModel.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:http/http.dart' as http;

class PaymentPage extends StatefulWidget {
  final String type;
  PaymentPage(this.type);
  @override
  _PaymentPageState createState() => _PaymentPageState(type);
}

class _PaymentPageState extends State<PaymentPage> {
  var type;
  _PaymentPageState(this.type);

  Razorpay razorpay;

  TextEditingController amountEditingController = TextEditingController();

  var _character = 0;
  double _amount = 0;

  @override
  void initState() {
    super.initState();

    ValidationClass.paymentcancel = "1";
    razorpay = Razorpay();
    razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    super.dispose();
  }

  void calculation() {
    if (_character == 0) {
      // _amount = ValidationClass.formatwithtwodigit(
      //     (ValidationClass.settodouble(amountEditingController.text) +
      //             (ValidationClass.settodouble(amountEditingController.text) *
      //                 0.025))
      //         .toString());
      _amount = ValidationClass.formatwithtwodigit(ValidationClass.settodouble(
              (ValidationClass.settodouble(amountEditingController.text) / 2)
                  .toString())
          .toString());
    } else {
       _amount = ValidationClass.formatwithtwodigit(ValidationClass.settodouble(
              (ValidationClass.settodouble(amountEditingController.text) / 2)
                  .toString())
          .toString());
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    // print("Payment id..${response.paymentId}");
    // print("order id..${response.orderId}");
    // print("Payment id..${response.signature}");
    // print("Payment Success..$response");

    walletadd(
        ValidationClass.settodouble(amountEditingController.text),
        "Credited in Wallet",
        response.signature.toString(),
        response.paymentId.toString());

    ValidationClass.paymentcancel = "0";
    // Do something when payment succeeds
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    print("Payment Error..${response.message}");
    print("Payment Error..${response.code}");
    // Do something when payment fails

    ValidationClass.paymentcancel = "1";
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    print("External Wallet..${response.walletName}");
    // Do something when an external wallet is selected
    // var aa = json.decode(response.toString());
    // walletadd(ValidationClass.settodouble(amountEditingController.text),
    //     "Add Wallet", '', '', response.walletName.toString());
  }

  onpayment() {
    var options = {
      'key': 'rzp_live_rHgzDOedWMUcYH',
      'amount': ValidationClass.settodouble(_amount.toString()) *
          100, //in the smallest currency sub-unit.
      'name': 'Pro Player War',
      'reference_id': ValidationClass.userid.toString(),
      'description': 'credited in Wallet',
      'timeout': 60, // in seconds
      'prefill': {
        'contact': ValidationClass.mobile.toString(),
        'email': ValidationClass.email.toString()
      }
    };

    razorpay.open(options);
  }

  Future<List<dynamic>> walletadd(
      amount, description, signature, paymentid) async {
    List<dynamic> _list = [];

    try {
      var res;

      res = await http.post(
        Connection.walletadd.toString(),
        body: {
          "transaction_type": "W",
          "user_id": ValidationClass.userid.toString(),
          "amount": amount.toString(),
          "addless": "ADD",
          "description": description.toString(),
          "signature": signature.toString(),
          "payment_id": paymentid.toString(),
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);

      var aa = json.decode(res.body);

      List walletlist = aa["Table"];

      var transactionlist = convertlist(aa["Table1"]);
      var wallet =
          ValidationClass.settodouble(walletlist[0]["wallet"].toString());
      var bonuswallet =
          ValidationClass.settodouble(walletlist[0]["bonus_wallet"].toString());

      Provider.of<WalletModel>(context, listen: false)
          .refreshwallet(wallet, bonuswallet, transactionlist);

      Navigator.pop(context);
    } catch (e) {}

    return _list;
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Stack(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(bottom: 16),
            margin: EdgeInsets.only(top: 0),
            decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10.0,
                    offset: Offset(0.0, 10.0),
                  )
                ]),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: AppColor.headerColor,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10)),
                  ),
                  // color: AppColor.headerColor,
                  width: MediaQuery.of(context).size.width,
                  height: 35.0,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      type.toString(),
                      style: TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.w700,
                        color: AppColor.whitecolor,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                Visibility(
                  visible: false,
                  child: new Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      new Radio(
                        value: 0,
                        groupValue: _character,
                        onChanged: (value) {
                          setState(() {
                            _character = value;
                            calculation();
                          });
                        },
                      ),
                      new Text(
                        'RazorPay',
                        style: new TextStyle(fontSize: 14.0),
                      ),
                      new Radio(
                        value: 1,
                        groupValue: _character,
                        onChanged: (value) {
                          setState(() {
                            _character = value;
                            calculation();
                          });
                        },
                      ),
                      new Text(
                        'GPay',
                        style: new TextStyle(
                          fontSize: 14.0,
                        ),
                      ),
                      // new Radio(
                      //   value: 2,
                      //   groupValue: _character,
                      //   onChanged: (value) {
                      //     setState(() {
                      //       _character = value;
                      //     });
                      //   },
                      // ),
                      // new Text(
                      //   'PhonePay',
                      //   style: new TextStyle(
                      //     fontSize: 15.0,
                      //   ),
                      // ),
                    ],
                  ),
                ),
                Visibility(
                  visible: _character == 0 ? false : false,
                  child: Text(
                    '2.5 % Extra Charges',
                    style: new TextStyle(
                      fontSize: 12.0,
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.all(Radius.circular(15.0)),
                    color: AppColor.whitecolor,
                  ),
                  // color: AppColor.backColor,
                  width: MediaQuery.of(context).size.width * 0.70,

                  child: TextField(
                    onChanged: (value) {
                      setState(() {
                        calculation();
                      });
                    },
                    keyboardType: TextInputType.phone,
                    controller: amountEditingController,
                    style: AppTextStyle.textfromfieldstyle,
                    decoration: InputDecoration(
                      prefix: Image.asset(
                        "assets/coin.png",
                        height: 18,
                        width: 18,
                      ),
                      // prefixText: "₹",
                      counterText: '',
                      counterStyle: TextStyle(fontSize: 0),
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                InkWell(
                  onTap: () {
                    if (amountEditingController.text == "") {
                                     ValidationClass.onBasicAlertPressed(
                          context, "Validation", "oops.. Missing Amount....");
                      // Fluttertoast.showToast(msg: "oops.. Missing Amount....");
                    } else {
                      onpayment();
                    }
                  },
                  child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(width: 0.0),
                        borderRadius: BorderRadius.all(Radius.circular(0.0)),
                        color: AppColor.greenColor,
                      ),
                      // color: AppColor.backColor,
                      width: MediaQuery.of(context).size.width * 0.70,
                      height: 40,
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(
                          "Add Cash ₹${_amount.toString()}",
                          style: new TextStyle(
                            fontSize: 16.0,
                            color: AppColor.whitecolor,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      )),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
