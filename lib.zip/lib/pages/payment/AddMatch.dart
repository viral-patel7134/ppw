import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/model/FriendModel.dart';
import 'package:proplayerwar/model/JoinModel.dart';
import 'package:proplayerwar/model/PlayerModel.dart';
import 'package:proplayerwar/model/WalletModel.dart';
import 'package:proplayerwar/pages/Team/TeamCreate.dart';
import 'package:proplayerwar/model/LeaderBoardModel.dart';

import 'package:proplayerwar/pages/payment/PaymentPage.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';

import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:provider/provider.dart';

import 'package:http/http.dart' as http;

class AddMatch extends StatefulWidget {
  final data;
  AddMatch(this.data);
  @override
  _AddMatchState createState() => _AddMatchState(data);
}

class _AddMatchState extends State<AddMatch> {
  final data;
  _AddMatchState(this.data);

  ProgressDialog pr;
  var entryfee,
      bonusper,
      wallet,
      bonuswallet,
      bonuswalletfees,
      bonuswalletused,
      walletused;
  @override
  void initState() {
    super.initState();

    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);

    WalletModel walletModel;
    entryfee = data["entry_fee"].toString();
    bonusper =
        ValidationClass.settodouble(data["bonus_per"].toString()).toString();
    walletModel = Provider.of<WalletModel>(context, listen: false);

    wallet =
        ValidationClass.settodouble(walletModel.wallet.toString()).toString();
    bonuswallet =
        ValidationClass.settodouble(walletModel.bonuswallet.toString())
            .toString();

    // wallet = data["wallet"].toString();
    // bonuswallet = data["bonus_wallet"].toString();
    bonuswalletfees = ValidationClass.settodouble(entryfee) *
        ValidationClass.settodouble(bonusper) /
        100;
    bonuswalletused = 0;

    if (ValidationClass.settodouble(bonuswallet.toString()) >=
        ValidationClass.settodouble(bonuswalletfees.toString())) {
      bonuswalletused = bonuswalletfees;
    } else if (ValidationClass.settodouble(bonuswallet.toString()) <
        ValidationClass.settodouble(bonuswalletfees.toString())) {
      bonuswalletused = bonuswallet;
    } else if (ValidationClass.settodouble(bonuswallet.toString()) == 0) {
      bonuswalletused = 0;
    }

    walletused = 0;
    if (ValidationClass.settodouble(wallet) >=
        ValidationClass.settodouble(entryfee.toString()) -
            ValidationClass.settodouble(bonuswalletused.toString())) {
      walletused = ValidationClass.settodouble(entryfee.toString()) -
          ValidationClass.settodouble(bonuswalletused.toString());
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List<dynamic>> walletadd(
      amount, description, signature, paymentid) async {
    List<dynamic> _list = [];

    try {
      var res;

      res = await http.post(
        Connection.walletadd.toString(),
        body: {
          "transaction_type": "W",
          "user_id": ValidationClass.userid.toString(),
          "amount": amount.toString(),
          "addless": "ADD",
          "description": description.toString(),
          "signature": signature.toString(),
          "payment_id": paymentid.toString(),
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);

      var aa = json.decode(res.body);

      List walletlist = aa["Table"];

      var transactionlist = convertlist(aa["Table1"]);
      var wallet =
          ValidationClass.settodouble(walletlist[0]["wallet"].toString());
      var bonuswallet =
          ValidationClass.settodouble(walletlist[0]["bonus_wallet"].toString());

      Provider.of<WalletModel>(context, listen: false)
          .refreshwallet(wallet, bonuswallet, transactionlist);

      Navigator.pop(context);
    } catch (e) {}

    return _list;
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Stack(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(bottom: 16),
            margin: EdgeInsets.only(top: 0),
            decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10.0,
                    offset: Offset(0.0, 10.0),
                  )
                ]),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: AppColor.headerColor,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10)),
                  ),
                  // color: AppColor.headerColor,
                  width: MediaQuery.of(context).size.width,
                  height: 50.0,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(

                      children: <Widget>[
                        Text(
                          "Confirmation",
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.w700,
                            color: AppColor.whitecolor,
                          ),
                          textAlign: TextAlign.left,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 0.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  "Coin Added + Winnings = ",
                                  style: TextStyle(
                                    fontSize: 9.0,
                                    fontWeight: FontWeight.w700,
                                    color: AppColor.whitecolor,
                                  ),
                                  textAlign: TextAlign.left,
                                ),
                                Image.asset(
                                  "assets/coin.png",
                                  height: 13,
                                  width: 13,
                                ),
                                Text(
                                  wallet.toString(),
                                  style: TextStyle(
                                    fontSize: 11.0,
                                    fontWeight: FontWeight.w700,
                                    color: AppColor.whitecolor,
                                  ),
                                  textAlign: TextAlign.left,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10.0, vertical: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text("Entry"),
                      Row(
                        children: <Widget>[
                          Image.asset(
                            "assets/coin.png",
                            height: 18,
                            width: 18,
                          ),
                          Text(
                            "${data["entry_fee"].toString()}",
                            style: AppTextStyle.blacktextstyle4,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10.0, vertical: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text("Usable Cash Bonus(${bonusper.toString()}%)"),
                      Consumer<WalletModel>(
                        builder: (context, walletmodel, child) {
                          return Row(
                            children: <Widget>[
                              Image.asset(
                                "assets/coin.png",
                                height: 18,
                                width: 18,
                              ),
                              Text(
                                "${bonuswalletused.toString()}",
                                style: AppTextStyle.blacktextstyle4,
                              ),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                ),
                Divider(
                  height: 15.0,
                  color: Colors.grey,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10.0, vertical: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text("To Pay"),
                      Consumer<WalletModel>(
                        builder: (context, walletmodel, child) {
                          return Row(
                            children: <Widget>[
                              Image.asset(
                                "assets/coin.png",
                                height: 18,
                                width: 18,
                              ),
                              Text(
                                "${ValidationClass.settodouble(data["entry_fee"].toString()) - ValidationClass.settodouble(bonuswalletused.toString())}",
                                style: AppTextStyle.blacktextstyle4,
                              ),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                ),
                InkWell(
                  onTap: () {
                    matchdd(data["match_id"].toString());
                  },
                  child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(width: 0.0),
                        borderRadius: BorderRadius.all(Radius.circular(0.0)),
                        color: AppColor.buttonColor,
                      ),
                      // color: AppColor.backColor,
                      width: MediaQuery.of(context).size.width * 0.70,
                      height: 40,
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(
                          "Continue",
                          style: new TextStyle(
                            fontSize: 16.0,
                            color: AppColor.whitecolor,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      )),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Future<List<dynamic>> matchdd(_matchid) async {
    await pr.show();

    List<dynamic> _list = [];

    try {
      // await ValidationClass.hubConnection.invoke('InsertMatch', args: [_lclmatchid.toString(), ValidationClass.userid.toString()]);

      var res;

      res = await http.post(
        Connection.matchadd.toString(),
        body: {
          "match_id": _matchid.toString(),
          "user_id": ValidationClass.userid.toString(),
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);

      var aa = json.decode(res.body);

      List resultlist = aa["Table"];

      if (resultlist.length > 0) {
        if (resultlist[0]["status"].toString() == "1") {
          pr.hide().then((isHidden) {
            print(isHidden);
          });
          Navigator.pop(context);
          await showDialog(
              context: context, builder: (context) => PaymentPage("Add Cash"));

          if (ValidationClass.paymentcancel == "0") {
            matchdd(_matchid);
            //  await ValidationClass.hubConnection.invoke('InsertMatch', args: [_matchid.toString(), ValidationClass.userid.toString()]);

          }
        } else if (resultlist[0]["status"].toString() == "3") {
          pr.hide().then((isHidden) {
            print(isHidden);
          });
          Navigator.pop(context);

          var data1;
          data1 = {
            "team_id": "0",
            "game_id": data["game_id"].toString(),
            "team_size_id": data["team_size_id"].toString(),
            "team_size": data["team_size"].toString(),
            "team_name": "",
            "image": ""
          };

          Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => TeamCreatepage(data1, 0)));
        } else if (resultlist[0]["status"].toString() == "4") {
          pr.hide().then((isHidden) {
            print(isHidden);
          });
          Navigator.pop(context);

          showDialog<String>(
            context: context,
            barrierDismissible: false, // user must tap button!
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text('Validation'),
                content: SingleChildScrollView(
                  child: ListBody(
                    children: <Widget>[
                      Text('Your Friend already in this match'),
                      // Text('You\’re like me. I’m never satisfied.'),
                    ],
                  ),
                ),
                actions: <Widget>[
                  Container(
                    width: MediaQuery.of(context).size.width,
                    child: FlatButton(
                      child: Text('OK', style: TextStyle(color: Colors.white)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      color: Color.fromRGBO(0, 179, 134, 1.0),
                    ),
                  ),
                ],
              );
            },
          );

          // ValidationClass.onBasicAlertPressed(
          //     context, "Validation", "You are already in this match");

          List joinedlist = aa["Table3"];

          var joined;
          if (joinedlist.length > 0) {
            joined = joinedlist[0]["joined"].toString();
          }
          Provider.of<JoinModel>(context, listen: false)
              .refreshjoin(joined.toString());
        } else {
          List walletlist = aa["Table1"];

          var transactionlist = convertlist(aa["Table2"]);

          List joinedlist = aa["Table3"];

          var joined;
          if (joinedlist.length > 0) {
            joined = joinedlist[0]["joined"].toString();
          }

          var wallet =
              ValidationClass.settodouble(walletlist[0]["wallet"].toString());
          var bonuswallet = ValidationClass.settodouble(
              walletlist[0]["bonus_wallet"].toString());

          Provider.of<WalletModel>(context, listen: false)
              .refreshwallet(wallet, bonuswallet, transactionlist);

          Provider.of<JoinModel>(context, listen: false)
              .refreshjoin(joined.toString());

          List leaderboardlist = aa["Table4"];

          Future<List<dynamic>> listleaderboardfuture;

          listleaderboardfuture= convertlist(leaderboardlist);
          Provider.of<LeaderModel>(context, listen: false)
              .refreshleaderboard(listleaderboardfuture);



          List teamplayer = aa["Table5"];


          ValidationClass.teamdata.clear();
          if (teamplayer.length == 0) {
            FriendModel friendModel = FriendModel();

            friendModel.userid = ValidationClass.userid;
            friendModel.frienduserid = ValidationClass.userid;
            friendModel.type = ValidationClass.matchtype;
            friendModel.name = ValidationClass.username;
            friendModel.image = ValidationClass.userimg;
            friendModel.teamid = 0;

            ValidationClass.teamdata.add(friendModel);
          } else {
            for (var item in teamplayer) {
              FriendModel friendModel = FriendModel();

              friendModel.userid = ValidationClass.userid;
              friendModel.frienduserid =
                  ValidationClass.settoint(item["friend_user_id"].toString());
              // friendModel.frienduserid = s.data[index]["user_id"];
              friendModel.type = item["match_type"];
              friendModel.image = item["image"];
              friendModel.name = item["ingame_name"];
              friendModel.teamid =
                  ValidationClass.settoint(item["team_id"].toString());
              ValidationClass.teamdata.add(friendModel);
            }
          }


          Provider.of<PlayerModel>(context, listen: false)
              .refreshPlayer(ValidationClass.teamdata);


          print('before pop');
          setState(() {});

          Navigator.pop(context);
          print('after pop');
        }
      }

      await ValidationClass.hubConnection
          .invoke('MyMatch', args: [_matchid.toString()]);

      // Navigator.pop(context);
    } catch (e) {}
    pr.hide().then((isHidden) {
      print(isHidden);
    });
    return _list;
  }
}
