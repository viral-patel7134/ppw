import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/model/WalletModel.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:provider/provider.dart';

import 'package:http/http.dart' as http;

class WithdrawPage extends StatefulWidget {
  final String type;
  WithdrawPage(this.type);
  @override
  _WithdrawPageState createState() => _WithdrawPageState(type);
}

class _WithdrawPageState extends State<WithdrawPage> {
  var type;
  _WithdrawPageState(this.type);

  TextEditingController amountEditingController = TextEditingController();
  TextEditingController phoneEditingController = TextEditingController();

  var _character = 1;
  double _amount = 0;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void calculation() {
    _amount = ValidationClass.formatwithtwodigit(
        ((ValidationClass.settodouble(amountEditingController.text) / 2) -
                ((ValidationClass.settodouble(amountEditingController.text) /
                        2) *
                    0.025))
            .toString());
  }

  Future<List<dynamic>> withdrawrequest(context) async {
    List<dynamic> _list = [];

    try {
      var res;

      res = await http.post(
        Connection.withdrawrequest.toString(),
        body: {
          "payment_type": _character == 1 ? "GPAY" : "UPI",
          "user_id": ValidationClass.userid.toString(),
          "amount": _amount.toString(),
          "coin": amountEditingController.text.toString(),
          "phone": phoneEditingController.text.toString()
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);

      var aa = json.decode(res.body);
      List walletlist = aa["Table"];

      var transactionlist = convertlist(aa["Table1"]);

      var wallet =
          ValidationClass.settodouble(walletlist[0]["wallet"].toString());
      var bonuswallet =
          ValidationClass.settodouble(walletlist[0]["bonus_wallet"].toString());

      Navigator.pop(context);

      if (walletlist[0]["status"].toString() == "failure") {
        //  ValidationClass.onBasicAlertPressed(
        //     context, "Validation", "Please insert min 100 coin.....");

        showDialog<String>(
          context: context,
          barrierDismissible: false, // user must tap button!
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Validation'),
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    Text('Minimum 100 Coin Can be Withdraw.....'),
                    // Text('You\’re like me. I’m never satisfied.'),
                  ],
                ),
              ),
              actions: <Widget>[
                Container(
                  width: MediaQuery.of(context).size.width,
                  child: FlatButton(
                    child: Text('OK', style: TextStyle(color: Colors.white)),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    color: Color.fromRGBO(0, 179, 134, 1.0),
                  ),
                ),
              ],
            );
          },
        );

        // Alert(
        //   context: context,
        //   title: "Validation",
        //   desc: "Please insert min 100 coin.....",
        //   buttons: [

        //     DialogButton(
        //       child: Text(
        //         "Ok",
        //         style: TextStyle(color: Colors.white, fontSize: 20),
        //       ),
        //       onPressed: () {
        //         Navigator.pop(context);
        //       },
        //       color: Color.fromRGBO(0, 179, 134, 1.0),
        //       radius: BorderRadius.circular(0.0),

        //     ),
        //   ],
        // ).show();

        // Fluttertoast.showToast(msg: "Please insert min 100 coin.....");
      } else {
        Provider.of<WalletModel>(context, listen: false)
            .refreshwallet(wallet, bonuswallet, transactionlist);

        showDialog<String>(
          context: context,
          barrierDismissible: false, // user must tap button!
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Validation'),
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    Container(
                        width: MediaQuery.of(context).size.width,
                        child:
                            Text('Your Payment will be Clear Within 24 hr.')),
                    // Text('You\’re like me. I’m never satisfied.'),
                  ],
                ),
              ),
              actions: <Widget>[
                FlatButton(
                  child: Text('OK', style: TextStyle(color: Colors.white)),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  color: Color.fromRGBO(0, 179, 134, 1.0),
                ),
              ],
            );
          },
        );

        // Alert(
        //   context: context,
        //   title: "Validation",
        //   desc: "Your Payment will be Clear 24 hr.",
        // ).show();

        // ValidationClass.onBasicAlertPressed(
        //     context, "Validation", "Your Payment will be Clear 24 hr.");

        //  Fluttertoast.showToast(msg: "Your Payment will be Clear 24 hr.");
        // Navigator.pop(context);
      }
    } catch (e) {}

    return _list;
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Stack(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(bottom: 16),
            margin: EdgeInsets.only(top: 0),
            decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10.0,
                    offset: Offset(0.0, 10.0),
                  )
                ]),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: AppColor.headerColor,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10)),
                  ),
                  // color: AppColor.headerColor,
                  width: MediaQuery.of(context).size.width,
                  height: 35.0,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      type.toString(),
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w700,
                        color: AppColor.whitecolor,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                new Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Radio(
                      value: 1,
                      groupValue: _character,
                      onChanged: (value) {
                        setState(() {
                          _character = value;
                          calculation();
                          print(_character.toString());
                        });
                      },
                    ),
                    new Text(
                      'GPay',
                      style: new TextStyle(
                        fontSize: 13.0,
                      ),
                    ),
                    new Radio(
                      value: 0,
                      groupValue: _character,
                      onChanged: (value) {
                        setState(() {
                          _character = value;
                          print(_character.toString());
                          calculation();
                        });
                      },
                    ),
                    new Text(
                      'UPI',
                      style: new TextStyle(fontSize: 14.0),
                    ),

                    // new Radio(
                    //   value: 2,
                    //   groupValue: _character,
                    //   onChanged: (value) {
                    //     setState(() {
                    //       _character = value;
                    //     });
                    //   },
                    // ),
                    // new Text(
                    //   'PhonePay',
                    //   style: new TextStyle(
                    //     fontSize: 15.0,
                    //   ),
                    // ),
                  ],
                ),
                Text(
                  '2.5 % Extra Charges',
                  style: new TextStyle(
                    fontSize: 11.0,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.all(Radius.circular(15.0)),
                    color: AppColor.whitecolor,
                  ),
                  // color: AppColor.backColor,
                  width: MediaQuery.of(context).size.width * 0.70,

                  child: TextField(

                    // keyboardType:_character == 1 ? TextInputType.phone : TextInputType.text,
                    controller: phoneEditingController,
                    style: AppTextStyle.textfromfieldstyle,
                    decoration: InputDecoration(
                      prefix: _character == 1
                          ? Icon(Icons.phone_android)
                          : Image.asset(
                              "assets/bhim.png",
                              height: 18,
                              width: 18,
                            ), // prefixText: "₹",
                      counterText: '',
                      counterStyle: TextStyle(fontSize: 0),
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.all(Radius.circular(15.0)),
                    color: AppColor.whitecolor,
                  ),
                  // color: AppColor.backColor,
                  width: MediaQuery.of(context).size.width * 0.70,

                  child: TextField(
                    onChanged: (value) {
                      setState(() {
                        calculation();
                      });
                    },
                    keyboardType: TextInputType.phone,
                    controller: amountEditingController,
                    style: AppTextStyle.textfromfieldstyle,
                    decoration: InputDecoration(
                      prefix: Image.asset(
                        "assets/coin.png",
                        height: 18,
                        width: 18,
                      ), // prefixText: "₹",
                      counterText: '',
                      counterStyle: TextStyle(fontSize: 0),
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                InkWell(
                  onTap: () {
                    if (amountEditingController.text == "") {
                      ValidationClass.onBasicAlertPressed(
                          context, "Validation", "oops.. Missing Amount....");

                      // Fluttertoast.showToast(msg: "oops.. Missing Amount....");
                    } else {
                      withdrawrequest(context);
                    }
                  },
                  child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(width: 0.0),
                        borderRadius: BorderRadius.all(Radius.circular(0.0)),
                        color: AppColor.greenColor,
                      ),
                      // color: AppColor.backColor,
                      width: MediaQuery.of(context).size.width * 0.70,
                      height: 35,
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(
                          "Request ₹${_amount.toString()}",
                          style: new TextStyle(
                            fontSize: 15.0,
                            color: AppColor.whitecolor,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      )),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
