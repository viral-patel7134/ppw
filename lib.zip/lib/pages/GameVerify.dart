import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/Connection/Connection.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';

import 'package:http/http.dart' as http;
import 'package:proplayerwar/util/ValidationClass.dart';

class GameVerify extends StatefulWidget {
  final data;
  GameVerify(this.data);
  @override
  _GameVerifyState createState() => _GameVerifyState(data);
}

class _GameVerifyState extends State<GameVerify> {
  var data;
  _GameVerifyState(this.data);

  ProgressDialog pr;
  Future<List<dynamic>> listgamefuture;

  TextEditingController _ingamenameController = TextEditingController();
  TextEditingController _appidController = TextEditingController();
  TextEditingController _levelController = TextEditingController();

  @override
  void initState() {
    super.initState();

    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        backgroundColor: AppColor.primaryColor,
        elevation: 0,

        title: Text(
          data["game_name"].toString(),
          // "Game List",
          style: AppTextStyle.whitetextstyle1,
        ),
        // actions: <Widget>[
        //   Container(
        //     width: 60,
        //     // color: Colors.green,
        //     alignment: Alignment.center,
        //     child: Padding(
        //       padding: const EdgeInsets.all(10.0),
        //       child: InkWell(
        //         onTap: () {
        //           Navigator.of(context).push(
        //               MaterialPageRoute(builder: (context) => FriendRequest()));
        //         },
        //         child: Stack(
        //           children: <Widget>[
        //             Icon(
        //               Icons.people,
        //               color: Colors.white,
        //               size: 25,
        //             ),
        //             requestcount.toString() != "0"
        //                 ? Align(
        //                     alignment: Alignment.topRight,
        //                     child: Container(
        //                       height: 20,
        //                       width: 30,
        //                       decoration: BoxDecoration(
        //                           shape: BoxShape.circle, color: Colors.red),
        //                       child: Center(
        //                         child: Text(
        //                           requestcount.toString(),
        //                           style: TextStyle(
        //                               fontSize: 12, color: Colors.white),
        //                         ),
        //                       ),
        //                     ),
        //                   )
        //                 : Text("")
        //           ],
        //         ),
        //       ),
        //     ),
        //   ),
        // ],
      ),
      body: bodygameverify(context),
    );
  }

  Widget bodygameverify(context) {
    return ListView(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: 30),
              Container(
                color: AppColor.whitecolor,
                child: TextField(
                  controller: _ingamenameController,
                  decoration: InputDecoration(
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 0, horizontal: 5),
                    labelText: 'Ingame Name',
                    border: InputBorder.none,
                    hintStyle: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SizedBox(height: 15),
              Container(
                color: AppColor.whitecolor,
                child: TextField(
                  controller: _appidController,
                  decoration: InputDecoration(
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 0, horizontal: 5),
                    labelText: 'Game Id',
                    border: InputBorder.none,
                    hintStyle: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SizedBox(height: 15),
              Container(
                color: AppColor.whitecolor,
                child: TextField(
                  controller: _levelController,
                  decoration: InputDecoration(
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 0, horizontal: 5),
                    labelText: 'Game Level',
                    border: InputBorder.none,
                    hintStyle: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                  keyboardType: TextInputType.number,
                ),
              ),
              SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: GestureDetector(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(0),
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: FractionalOffset.topLeft,
                            end: FractionalOffset.bottomRight,
                            colors: [
                              AppColor.primaryColor,
                              AppColor.primaryColor
                            ]),
                      ),
                      child: Center(
                          child: Text(
                        'Request to Approve',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Colors.white),
                      )),
                    ),
                  ),
                  onTap: () {
                    if (_ingamenameController.text == "") {
                      ValidationClass.onBasicAlertPressed(context, "Validation",
                          "oops.. Missing In Game Name ....");
                      // Fluttertoast.showToast(
                      //     msg: "oops.. Missing In Game Name ....");
                    } else if (_appidController.text == "") {
                      ValidationClass.onBasicAlertPressed(
                          context, "Validation", "oops.. Missing Game Id ....");

                      // Fluttertoast.showToast(msg: "oops.. Missing App Id ....");
                    } else if (_levelController.text == "") {
                      ValidationClass.onBasicAlertPressed(
                          context, "Validation", "oops.. Missing Level ....");
                      // Fluttertoast.showToast(msg: "oops.. Missing Level ....");
                    } else {
                      requesttoApprove();
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<List<dynamic>> requesttoApprove() async {
    await pr.show();

    List<dynamic> _list = [];

    try {
      var res;
      print(data["game_id"].toString());
      res = await http.post(
        Connection.gamerequestadd.toString(),
        body: {
          "game_id": data["game_id"].toString(),
          "user_id": ValidationClass.userid.toString(),
          "ingame_name": _ingamenameController.text.toString(),
          "app_id": _appidController.text.toString(),
          "level": _levelController.text.toString()
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);
      var decodedData = json.decode(res.body);
      _list = decodedData;

      if (_list.length > 0) {
        Fluttertoast.showToast(msg: "Requested Successfully....");
        Navigator.pop(context);
      }
    } catch (e) {}
    pr.hide().then((isHidden) {
      print(isHidden);
    });
    return _list;
  }
}
