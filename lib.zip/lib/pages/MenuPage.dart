import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/login/LoginFormPage.dart';
import 'package:proplayerwar/pages/GameList.dart';

import 'package:proplayerwar/pages/Team/TeamList.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:proplayerwar/login/MobileLogin.dart';
import 'package:proplayerwar/pages/MyWallet.dart';
import 'package:proplayerwar/pages/AboutUs.dart';
import 'package:proplayerwar/pages/Terms.dart';
import 'package:proplayerwar/pages/Privacy.dart';

import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:url_launcher/url_launcher.dart';

class MenuPage extends StatefulWidget {
  @override
  _MenuPageState createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  int requestcount = 5;

  var matchplayed = 0;
  var matchkills = 0;
  var matchprizewon = 0;


  @override
  void initState() {
    super.initState();

    // getJSONData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        backgroundColor: AppColor.primaryColor,
        elevation: 0,
        // actions: [
        //   Icon(Icons.menu)
        // ],
        // actions: <Widget>[
        //   Icon(Icons.edit_attributes,color: Colors.white,),
        // ],
        // actions: <Widget>[
        //   Container(
        //     width: 60,
        //     // color: Colors.green,
        //     alignment: Alignment.center,
        //     child: Padding(
        //       padding: const EdgeInsets.all(10.0),
        //       child: InkWell(
        //         onTap: () {
        //           Navigator.of(context).push(
        //               MaterialPageRoute(builder: (context) => FriendRequest()));
        //         },
        //         child: Stack(
        //           children: <Widget>[
        //             Icon(
        //               Icons.people,
        //               color: Colors.white,
        //               size: 25,
        //             ),
        //             requestcount.toString() != "0"
        //                 ? Align(
        //                     alignment: Alignment.topRight,
        //                     child: Container(
        //                       height: 20,
        //                       width: 30,
        //                       decoration: BoxDecoration(
        //                           shape: BoxShape.circle, color: Colors.red),
        //                       child: Center(
        //                         child: Text(
        //                           requestcount.toString(),
        //                           style: TextStyle(
        //                               fontSize: 12, color: Colors.white),
        //                         ),
        //                       ),
        //                     ),
        //                   )
        //                 : Text("")
        //           ],
        //         ),
        //       ),
        //     ),
        //   ),
        // ],
      ),
      body: Column(
        children: <Widget>[
          Container(
            color: AppColor.primaryColor,
            width: double.infinity,
            child: Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                      // ValidationClass.userdata["Profiledata"].toString(),
                      Connection.profileImagePath.toString() +
                          ValidationClass.userimg.toString(),
                      // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                    ),
                    radius: 50.0,
                  ),
                  SizedBox(
                    height: 10.0,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                LoginFormPage(ValidationClass.mobile),
                            // TeamCreatepage(data, players),
                          ));
                    },
                    child: Text(
                      "Edit Profile",
                      style: TextStyle(
                        fontSize: 12.0,
                        color: Colors.red,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10.0,
                  ),
                  // SimpleRichText(
                  //   text: ValidationClass.username.toString(),
                  //   style: TextStyle(
                  //     fontSize: 20.0,
                  //     color: Colors.white,
                  //   ),
                  // ),
                  Text(
                    ValidationClass.username.toString(),
                    // "Alice James",
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: 5.0,
                  ),

                  Visibility(
                    visible: true,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 15.0),
                      child: Card(
                        margin: EdgeInsets.symmetric(
                            horizontal: 20.0, vertical: 5.0),
                        clipBehavior: Clip.antiAlias,
                        color: Colors.white,
                        elevation: 5.0,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8.0, vertical: 10.0),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Column(
                                  children: <Widget>[
                                    Text(
                                      "Match Played",
                                      style: AppTextStyle.blacktextstylenormal5,
                                    ),
                                    SizedBox(
                                      height: 5.0,
                                    ),
                                    Text(
                                      matchplayed.toString(),
                                      style: AppTextStyle.blacktextstyle4,
                                    )
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Column(
                                  children: <Widget>[
                                    Text(
                                      "Total Kills",
                                      style: AppTextStyle.blacktextstylenormal5,
                                    ),
                                    SizedBox(
                                      height: 5.0,
                                    ),
                                    Text(
                                      matchkills.toString(),
                                      style: AppTextStyle.blacktextstyle4,
                                    )
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Column(
                                  children: <Widget>[
                                    Text(
                                      "Win Prize",
                                      style: AppTextStyle.blacktextstylenormal5,
                                    ),
                                    SizedBox(
                                      height: 5.0,
                                    ),
                                    Text(
                                      matchprizewon.toString(),
                                      style: AppTextStyle.blacktextstyle4,
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListView(
                children: <Widget>[
                  addcard(Icon(Icons.ac_unit), "My Wallet", tapmywallet),
                  addcard(Icon(Icons.ac_unit), "Game Verify", tapgameverify),
                  addcard(Icon(Icons.ac_unit), "My Team", tapmyteam),
                  addcard(Icon(Icons.contacts), "About", tapaboutus),
                  addcard(Icon(Icons.contacts), "Privacy", tapprivacy),
                  addcard(Icon(Icons.contacts), "Terms", tapterms),
                  addcard(Icon(Icons.youtube_searched_for_outlined), "Youtube",
                      tapyoutube),
                  addcard(Icon(Icons.youtube_searched_for_outlined), "Facebook",
                      tapfacebook),
                  addcard(Icon(Icons.youtube_searched_for_outlined), "Instagram",
                      tapinstagram),
                  addcard(Icon(Icons.youtube_searched_for_outlined), "Telegram",
                      taptelegram),
                  addcard(Icon(Icons.ac_unit), "Logout", taplogoup),
                  // addcard(Icon(Icons.share), "Refer & Earn", shareapp),
                ],
              ),
            ),
          ),
          // SizedBox(
          //   height: 20.0,
          // ),
        ],
      ),
      // bottomNavigationBar: BottomNavigatorScreen()
    );
  }

  Widget addcard(Icon icon, String name, Function ontap) {
    return Card(
      child: ListTile(
        onTap: () {
          ontap();
        },
        trailing: Icon(Icons.arrow_forward_ios),
        title: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            name.toString(),
            style: AppTextStyle.blacktextstyle4,
          ),
        ),
      ),
    );
  }

  tapmyteam() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => TeamList()));
  }

  tapaboutus() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => AboutUs()));
  }

  tapprivacy() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => Privacy()));
  }

  tapterms() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => Terms()));
  }

  // shareapp() {
  //   _createDynamicLink(true);
  //   // initDynamicLinks();
  // }

  tapyoutube() {
    print('in taplink');
    _launchSocial('https://www.youtube.com/channel/UCFaoWDUPxiwgfwawc5mxQZw',
        'https://www.youtube.com/channel/UCFaoWDUPxiwgfwawc5mxQZw');
  }

  tapfacebook() {
    print('in taplink');
    _launchSocial('https://www.facebook.com/proplayerwar',
        'https://www.facebook.com/proplayerwar');
  }
  taptelegram() {
    print('in taplink');
    _launchSocial('https://t.me/proplayerwarofficial',
        'https://t.me/proplayerwarofficial');
  }
  tapinstagram() {
    print('in taplink');
    _launchSocial('https://www.instagram.com/proplayerwar',
        'https://www.instagram.com/proplayerwar');
  }


  _launchSocial(String url, String fallbackUrl)  async {
    // Don't use canLaunch because of fbProtocolUrl (fb://)


        try {
          bool launched =
              await launch(url, forceSafariVC: false, forceWebView: false);
          if (!launched) {
            await launch(fallbackUrl,
                forceSafariVC: false, forceWebView: false);
          }
        } catch (e) {
          await launch(fallbackUrl, forceSafariVC: false, forceWebView: false);
        }


  }

  taplogoup() async {
    print('before taplogoup');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.clear();
    print('center taplogoup');
    ValidationClass.userdata = Map();
    ValidationClass.userid = 0;
    ValidationClass.jwttoken = "";
    ValidationClass.token = "";

    Navigator.pop(context);
    print('before firebase taplogoup');
    FirebaseAuth.instance.signOut().then((value) => Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => MobileLogin(),
        )));
    print('end taplogoup');
  }

  tapgameverify() async {
    Navigator.push(context, MaterialPageRoute(builder: (c) => GameList()));
  }

  tapmywallet() async {
    Navigator.push(context, MaterialPageRoute(builder: (c) => MyWallet()));
  }

  // Future<List<dynamic>> getJSONData() async {
  //   List<dynamic> _profilelist = [];

  //   try {
  //     var res;

  //     res = await http.get(
  //       Connection.menu.toString(),
  //       // body: {},
  //       headers: {
  //         HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
  //       },
  //     );

  //     print("response" + res.body);
  //     var decodedData = json.decode(utf8.decode(res.bodyBytes));

  //     // var decodedData = json.decode(res.body);
  //     print("data : ${decodedData['match_played']}");

  //     matchplayed = decodedData['match_played'];
  //     matchkills = decodedData['total_kills'];
  //     matchprizewon = decodedData['win_prize'];

  //     // for (var i in decodedData) {
  //     //   print("inside");
  //     //   MenuProfileModel s = MenuProfileModel(
  //     //       matchplayed: i["match_played"],
  //     //       totalkills: i["total_kills"],
  //     //       winprizes: i["win_prize"]);

  //     //   setState(() {
  //     //     profilelist.add(s);
  //     //   });
  //     // }

  //     // final int statusCode = res.statusCode;

  //     // var resBody;
  //     // if (statusCode < 200 || statusCode > 400) {
  //     //   resBody = [];
  //     // }

  //     // if (res.body == "null") {
  //     //   resBody = [];
  //     // } else {
  //     //   resBody = json.decode(res.body);
  //     // }

  //     // setState(() {
  //     //   profilelist = decodedData;
  //     // });

  //     // print(decodedData.toString());
  //   } catch (e) {
  //     // return "Occur Error...";
  //   }

  //   return _profilelist;
  // }

  // void initDynamicLinks() async {
  //   FirebaseDynamicLinks.instance.onLink(
  //       onSuccess: (PendingDynamicLinkData dynamicLink) async {
  //     final Uri deepLink = dynamicLink?.link;
  //
  //     if (deepLink != null) {
  //       Navigator.pushNamed(context, deepLink.path);
  //     }
  //   }, onError: (OnLinkErrorException e) async {
  //     print('onLinkError');
  //     print(e.message);
  //   });
  //
  //   final PendingDynamicLinkData data =
  //       await FirebaseDynamicLinks.instance.getInitialLink();
  //   final Uri deepLink = data?.link;
  //
  //   if (deepLink != null) {
  //     Navigator.pushNamed(context, deepLink.path);
  //   }
  // }
  //
  // Future<void> _createDynamicLink(bool short) async {
  //   final DynamicLinkParameters parameters = DynamicLinkParameters(
  //     uriPrefix: 'https://proplayerwar.page.link',
  //     link: Uri.parse('https://proplayerwar.page.link/ppw'),
  //     androidParameters: AndroidParameters(
  //       packageName: 'com.rclick.proplayerwar',
  //       minimumVersion: 125,
  //     ),
  //     dynamicLinkParametersOptions: DynamicLinkParametersOptions(
  //       shortDynamicLinkPathLength: ShortDynamicLinkPathLength.short,
  //     ),
  //     // iosParameters: IosParameters(
  //     //   bundleId: 'com.google.FirebaseCppDynamicLinksTestApp.dev',
  //     //   minimumVersion: '0',
  //     // ),
  //   );
  //
  //   Uri url;
  //   var _linkMessage;
  //   if (short) {
  //     final ShortDynamicLink shortLink = await parameters.buildShortLink();
  //     url = shortLink.shortUrl;
  //   } else {
  //     url = await parameters.buildUrl();
  //   }
  //
  //   setState(() {
  //     _linkMessage = url.toString();
  //   });
  //   if (_linkMessage != null) {
  //     await Share.share(_linkMessage.toString());
  //   }
  // }

  Future<void> _launchURL() async {
    const url = 'https://www.youtube.com/channel/UCFaoWDUPxiwgfwawc5mxQZw';
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false,
        forceWebView: false,
        // headers: <String, String>{'my_header_key': 'my_header_value'},
      );
    } else {
      throw 'Could not launch $url';
    }
  }
}
