import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/Connection/Connection.dart';

import 'package:proplayerwar/model/WalletModel.dart';
import 'package:proplayerwar/model/matchdetailsModel.dart';

import 'package:proplayerwar/pages/Team/TeamCreate.dart';

import 'package:proplayerwar/pages/payment/PaymentPage.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:provider/provider.dart';

import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:http/http.dart' as http;

class MatchPlayerDetails extends StatefulWidget {
  final data;
  MatchPlayerDetails(this.data);
  @override
  _MatchPlayerDetailsState createState() => _MatchPlayerDetailsState(data);
}

class _MatchPlayerDetailsState extends State<MatchPlayerDetails> {
  var data;
  _MatchPlayerDetailsState(this.data);
  // WebSocketChannel _channel;

  Future<List<dynamic>> listprizefuture;
  Future<List<dynamic>> listleaderboardfuture;

  var _lclgameid = 0;
  ProgressDialog pr;
  var joined;
  List credentiallist;
  @override
  void initState() {
    super.initState();
    joined = "0";
    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);

    _lclgameid = ValidationClass.settoint(data["game_id"].toString());

    Provider.of<MatchdetailsModel>(context, listen: false).refreshmatch(
        data["match_id"].toString(), data["total_join"].toString());
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: Icon(
        //     Icons.home,
        //     size: 30,
        //   ),
        // ),
        // backgroundColor: Theme.of(context).primaryColor,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "Tournament", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "Tournament",
              style: TextStyle(fontSize: 20.0, color: Colors.white),
            ),
          ],
        ),

        elevation: 0,
      ),
      body: bodyTournament(context),
    );
  }

  Widget bodyTournament(context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6.0, vertical: 6.0),
      child: Column(
        children: <Widget>[
          Container(
            // height: MediaQuery.of(context).size.height / 4.3,
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.all(0.0),
            decoration: BoxDecoration(
              // border: Border.all(width: 0.0),
              borderRadius: BorderRadius.all(Radius.circular(2.0)),
              color: AppColor.whitecolor,
            ),
            child: Column(
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            width: MediaQuery.of(context).size.width / 2,
                            child: Text(
                              data["name"].toString(),
                              //  "PUBG MOBILE",
                              style: AppTextStyle.blacktextstyle1,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Row(
                              children: <Widget>[
                                // Padding(
                                //   padding: const EdgeInsets.only(left: 3.0),
                                //   child: Image.asset(
                                //     "assets/trophy.png",
                                //     fit: BoxFit.cover,
                                //     width: 15,
                                //     height: 15,
                                //   ),
                                // ),
                                // // Icon(
                                // //   Icons.image,
                                // //   color: Colors.grey[500],
                                // // ),
                                // SizedBox(
                                //   width: 5,
                                // ),
                                Row(
                                  children: <Widget>[
                                    Image.asset(
                                      "assets/coin.png",
                                      height: 25,
                                      width: 25,
                                    ),
                                    Text(
                                      "${data["winning_price"].toString()}",
                                      style: AppTextStyle.blacktextstyle3,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Text(
                            "Total Prize Pool",
                            style: AppTextStyle.blacktextstylelight,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: Row(
                              children: <Widget>[
                                Icon(
                                  Icons.access_time,
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Text(
                                  data["datetime"].toString(),
                                  // "Aug 04, 04:00PM",
                                  style: AppTextStyle.blacktextstyle2,
                                ),
                              ],
                            ),
                          ),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.person,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                data["team_size"].toString(),
                                //  "Solo",
                                style: AppTextStyle.blacktextstyle2,
                              ),
                            ],
                          ),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.person,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                data["match_type"].toString(),
                                //  "Solo",
                                style: AppTextStyle.blacktextstyle2,
                              ),
                            ],
                          ),
                          Visibility(
                            visible: data["match_type"].toString() == "Paid"
                                ? true
                                : false,
                            child: Row(
                              children: <Widget>[
                                // Icon(
                                //   Icons.person,
                                // ),
                                // SizedBox(
                                //   width: 5,
                                // ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.green,
                                      border: Border.all(width: 0.0),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(5.0)),
                                    ),
                                    height: 25,
                                    width: 50,
                                    child: Center(
                                      child: Row(
                                        children: <Widget>[
                                          Image.asset(
                                            "assets/coin.png",
                                            height: 15,
                                            width: 15,
                                          ),
                                          Text(
                                            data["entry_fee"].toString(),
                                            //  "Solo",
                                            style: AppTextStyle.whitetextstyle2,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Consumer<MatchdetailsModel>(
                        builder: (context, matchdetailsModel, child) {
                          print(matchdetailsModel.totaljoin);
                          return Text(
                            "${ValidationClass.settoint(data["players"].toString()) - ValidationClass.settoint(matchdetailsModel.totaljoin.toString())} LEFT",
                            style: AppTextStyle.blacktextstyle2,
                          );
                        },
                      ),
                      Text(
                        "TOTAL ${data["players"].toString()}",
                        style: AppTextStyle.blacktextstyle2,
                      ),
                    ],
                  ),
                ),
                Consumer<MatchdetailsModel>(
                  builder: (context, matchdetailsModel, child) {
                    return Padding(
                      padding: const EdgeInsets.only(
                          left: 8.0, right: 8.0, bottom: 8.0),
                      child: LinearProgressIndicator(
                        backgroundColor: Colors.grey,
                        value: ValidationClass.settoint(
                                matchdetailsModel.totaljoin.toString()) /
                            ValidationClass.settoint(data["players"]
                                .toString()), //join value/total member
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          // Divider(
          //   thickness: 0.0,
          //   color: AppColor.backColor,
          // ),
          Expanded(
            // height: MediaQuery.of(context).size.height / 1.5 - 60,
            // width: MediaQuery.of(context).size.width,
            // padding: EdgeInsets.only(top: 5.0),
            // decoration: BoxDecoration(
            //   border: Border.all(
            //       // color: AppColor.blackcolor, // set border color
            //       width: 0.0),
            //   borderRadius: BorderRadius.all(
            //     Radius.circular(
            //         15.0), //                 <--- border radius here
            //   ),
            // ),
            child: Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Container(
                color: AppColor.primaryColor,
                child: Column(
                  children: <Widget>[
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(
                          "Player Details",
                          style: AppTextStyle.whitetextstyle2,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                         width: MediaQuery.of(context).size.width-5,
                        color: AppColor.whitecolor,
                        child: ListView.builder(
                          shrinkWrap: true,
                          physics: ClampingScrollPhysics(),
                          itemCount:
                              ValidationClass.convertlist(data["data"]).length,
                          itemBuilder: (BuildContext ctxt, int ind) {
                            return addcardPrize(
                                ValidationClass.convertlist(data["data"])[ind]);
                            // Padding(
                            //   padding: const EdgeInsets.only(left:8.0,bottom: 0.0,top: 5.0),
                            //   child: Row(
                            //     children: <Widget>[
                            //       new Text("Player " + (ind+1).toString() + " : ",
                            //         style: AppTextStyle.blacktextstyle4,
                            //       ),Text(
                            //         ValidationClass.convertlist(
                            //                     data["data"])[ind]
                            //                 ["ingame_name"]
                            //             .toString(),
                            //         style: AppTextStyle.blacktextstyle4,
                            //       ),
                            //     ],
                            //   ),
                            // );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget addcardPrize(data) {
    return ListTile(

      leading: Container(
        height: 40,
        width: 40,
        decoration: BoxDecoration(
          border: Border.all(width: 0.0),
          borderRadius: BorderRadius.all(Radius.circular(50.0)),
          // color: AppColor.whitecolor,
        ),
        child: CircleAvatar(
          backgroundImage: NetworkImage(
            Connection.profileImagePath.toString() + data["image"].toString(),
          ),
        ),
      ),
      title: Container(
        //  width: MediaQuery.of(context).size.width * 0.50,
        child: Text(
          "${data["ingame_name"].toString()}",
          style: AppTextStyle.blacktextstyle5,
        ),
      ),

      trailing: InkWell(
        onTap: () {
          if (ValidationClass.settoint(
                      ValidationClass.userid.toString()) !=
                  ValidationClass.settoint(
                      data["leader_user_id"].toString()) &&
              ValidationClass.settoint(
                      ValidationClass.userid.toString()) ==
                  ValidationClass.settoint(data["user_id"].toString())) {
            showDialog<String>(
              context: context,
              barrierDismissible: false, // user must tap button!
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('Validation'),
                  content: SingleChildScrollView(
                    child: ListBody(
                      children: <Widget>[
                        Text('Are You Sure You Want to delete ?'),
                        // Text('You\’re like me. I’m never satisfied.'),
                      ],
                    ),
                  ),
                  actions: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                          width: MediaQuery.of(context).size.width / 3,
                          child:  FlatButton(
                            child: Text('OK',
                                style: TextStyle(color: Colors.white)),
                            onPressed: () {
                              deleteuser(data["team_id"].toString(),
                                  data["user_id"].toString());
                            },
                            color: Color.fromRGBO(0, 179, 134, 1.0),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width / 3,
                          child: FlatButton(
                            child: Text('Cancel',
                                style: TextStyle(color: Colors.white)),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            color: Color.fromRGBO(0, 179, 134, 1.0),
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              },
            );
          }
        },
        child: Icon(
          Icons.delete,
          size: 30,
          color: ValidationClass.settoint(
                      ValidationClass.userid.toString()) !=
                  ValidationClass.settoint(
                      data["leader_user_id"].toString()) &&
              ValidationClass.settoint(
                      ValidationClass.userid.toString()) ==
                  ValidationClass.settoint(data["user_id"].toString())
          ? Colors.black
          : Colors.grey[400],
        ),
      ),
    );
  }

  Widget addcardPrize1(data) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
      child: Container(
        //  width: MediaQuery.of(context).size.width,
        color: Colors.grey[300],
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  border: Border.all(width: 0.0),
                  borderRadius: BorderRadius.all(Radius.circular(50.0)),
                  // color: AppColor.whitecolor,
                ),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                    Connection.profileImagePath.toString() +
                        data["image"].toString(),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15.0, right: 15.0),
                child: Container(
                  height: 40,
                  width: 1,
                  color: AppColor.primaryColor,
                  child: Divider(
                    height: 1,
                  ),
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(left: 10.0, top: 2),
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.50,
                      child: Text(
                        "${data["ingame_name"].toString()}",
                        style: AppTextStyle.blacktextstyle5,
                      ),
                    ),
                  ),
                  Row(
                    //  crossAxisAlignment: CrossAxisAlignment.end,
                    //  mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(left: 0.0, right: 0.0),
                        child: Container(
                          height: 40,
                          width: 1,
                          color: AppColor.primaryColor,
                          child: Divider(
                            height: 1,
                          ),
                        ),
                      ),
                      Center(
                        child: Container(
                          color: Colors.red,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: InkWell(
                              onTap: () {
                                if (ValidationClass.settoint(ValidationClass
                                            .userid
                                            .toString()) !=
                                        ValidationClass.settoint(
                                            data["leader_user_id"]
                                                .toString()) &&
                                    ValidationClass.settoint(ValidationClass
                                            .userid
                                            .toString()) ==
                                        ValidationClass.settoint(
                                            data["user_id"].toString())) {
                                  showDialog<String>(
                                    context: context,
                                    barrierDismissible:
                                        false, // user must tap button!
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        title: Text('Validation'),
                                        content: SingleChildScrollView(
                                          child: ListBody(
                                            children: <Widget>[
                                              Text(
                                                  'Are You Sure You Want to delete ?'),
                                              // Text('You\’re like me. I’m never satisfied.'),
                                            ],
                                          ),
                                        ),
                                        actions: <Widget>[
                                          Row(
                                            children: <Widget>[
                                              Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width /
                                                    3,
                                                child: FlatButton(
                                                  child: Text('OK',
                                                      style: TextStyle(
                                                          color: Colors.white)),
                                                  onPressed: () {
                                                    deleteuser(
                                                        data["team_id"]
                                                            .toString(),
                                                        data["user_id"]
                                                            .toString());
                                                  },
                                                  color: Color.fromRGBO(
                                                      0, 179, 134, 1.0),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width /
                                                    3,
                                                child: FlatButton(
                                                  child: Text('Cancel',
                                                      style: TextStyle(
                                                          color: Colors.white)),
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  },
                                                  color: Color.fromRGBO(
                                                      0, 179, 134, 1.0),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                }
                              },
                              child: Center(
                                  child: Icon(
                                Icons.delete,
                                size: 30,
                                color: ValidationClass.settoint(ValidationClass
                                                .userid
                                                .toString()) !=
                                            ValidationClass.settoint(
                                                data["leader_user_id"]
                                                    .toString()) &&
                                        ValidationClass.settoint(ValidationClass
                                                .userid
                                                .toString()) ==
                                            ValidationClass.settoint(
                                                data["user_id"].toString())
                                    ? Colors.black
                                    : Colors.grey[400],
                              )),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),

              // SizedBox(width: 2,),
            ],
          ),
        ),
      ),
    );
  }

  Widget addcardLeaderboard(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 1.0),
      child: Container(
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        // decoration: BoxDecoration(
        //   border: Border.all(width: 0.0),
        //   borderRadius: BorderRadius.all(Radius.circular(0.0)),
        //   color: index == 0 || index % 2 == 0
        //       ? AppColor.whitecolor
        //       : AppColor.whitecolor,
        // ),
        // color: AppColor.whitecolor,
        child: ListTile(
          // contentPadding: EdgeInsets.all(0.0),
          // elevation: 0,
          // color: AppColor.whitecolor,
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(top: 1.0, bottom: 1.0, left: 5.0),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.all(Radius.circular(50.0)),
                    color: AppColor.whitecolor,
                  ),
                  // color: Colors.grey,
                  height: 40,
                  width: 40,
                  child: Center(
                    child: Icon(
                      Icons.person,
                      size: 30,
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 0.0, left: 5.0),
                child: Text(
                  s.data[index]["team_name"].toString() == ""
                      ? "${s.data[index]["user_name"].toString()}"
                      : "${s.data[index]["team_name"].toString()}",
                  style: AppTextStyle.blacktextstyle5,
                ),
              ),
            ],
          ),
          trailing: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Visibility(
                  visible: ValidationClass.settodouble(
                              s.data[index]["rank"].toString()) ==
                          0
                      ? false
                      : true,
                  child: Text("${s.data[index]["rank"].toString()}")),
              Visibility(
                  visible: ValidationClass.settodouble(
                              s.data[index]["winning_price"].toString()) ==
                          0
                      ? false
                      : true,
                  child: Text("${s.data[index]["winning_price"].toString()}")),
            ],
          ),
        ),
      ),
    );
  }

  void tripEditModalBottomSheet(context) {
    showModalBottomSheet(
        // shape: RoundedRectangleBorder(
        //   borderRadius: BorderRadius.all(Radius.circular(15)),
        // ),
        context: context,
        builder: (BuildContext bc) {
          return Container(
            decoration: BoxDecoration(
              // border: Border.all(width: 0.0),
              // borderRadius: BorderRadius.all(Radius.circular(15.0)),
              color: AppColor.whitecolor,
            ),
            height: MediaQuery.of(context).size.height * 0.60,
            child: Column(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    // border: Border.all(width: 0.0),
                    // borderRadius: BorderRadius.only(
                    //     topLeft: Radius.circular(15.0),
                    //     topRight: Radius.circular(15.0)),
                    color: AppColor.primaryColor,
                  ),
                  width: MediaQuery.of(context).size.width,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: <Widget>[
                        Text(
                          "Choose Team",
                          style: TextStyle(fontSize: 23.0, color: Colors.white),
                        ),
                        Spacer(),
                        InkWell(
                          onTap: () {
                            Navigator.of(context).pop();
                          },
                          child: Icon(Icons.cancel, size: 30),
                        ),
                      ],
                    ),
                  ),
                ),
                // Spacer(),
                Container(
                  // decoration: BoxDecoration(
                  //   border: Border.all(width: 0.0),
                  //   borderRadius: BorderRadius.all(Radius.circular(15.0)),
                  //   color: AppColor.primaryColor,
                  // ),
                  color: Colors.transparent,
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height / 2.6,
                  child: ListView.builder(
                    padding: EdgeInsets.only(top: 2),
                    scrollDirection: Axis.vertical,
                    // itemCount: myorder.length,
                    itemCount: 5,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.all(0.0),
                        child: Column(
                          children: <Widget>[
                            addcardPlayer(index, context),
                          ],
                        ),
                      );
                    },
                  ),
                ),

                Container(
                  // decoration: BoxDecoration(
                  //   border: Border.all(width: 0.0),
                  //   borderRadius: BorderRadius.all(Radius.circular(15.0)),
                  //   color: AppColor.primaryColor,
                  // ),
                  color: AppColor.primaryColor,
                  width: MediaQuery.of(context).size.width,
                  child: Padding(
                    padding: const EdgeInsets.all(1.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          // decoration: BoxDecoration(
                          //   border: Border.all(width: 0.0),
                          //   borderRadius:
                          //       BorderRadius.all(Radius.circular(15.0)),
                          //   color: Colors.grey,
                          // ),
                          color: AppColor.backColor,
                          width: MediaQuery.of(context).size.width / 1.13,
                          child: TextField(
                            style: AppTextStyle.textfromfieldstyle,
                            decoration: InputDecoration(
                              counterText: '',
                              counterStyle: TextStyle(fontSize: 0),
                              fillColor: Colors.white,
                              contentPadding:
                                  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                              border: new OutlineInputBorder(
                                borderRadius: new BorderRadius.circular(0.0),
                                borderSide: new BorderSide(),
                              ),
                            ),
                          ),
                        ),

                        // AppTextStyle.textWithStroke("Choose Player", 24.0,
                        //     3.0, Colors.white, Colors.red),
                        Spacer(),
                        Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Center(
                            child: Icon(
                              Icons.add,
                              size: 30,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }

  Widget addcardPlayer(int index, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 0.0),
      child: Container(
        width: MediaQuery.of(context).size.width,
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        child: Row(
          // crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 10.0, right: 20.0),
              child: Checkbox(value: true, onChanged: null),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 0.0, right: 100),
              child: Text(
                "KOW~VIRU",
                style: AppTextStyle.blacktextstyle4,
              ),
            ),
            Icon(
              Icons.delete,
              size: 30,
            )
          ],
        ),
      ),
    );
  }

  Future<List<dynamic>> matchdd(_matchid) async {
    await pr.show();

    List<dynamic> _list = [];

    try {
      // await ValidationClass.hubConnection.invoke('InsertMatch', args: [_lclmatchid.toString(), ValidationClass.userid.toString()]);

      var res;

      res = await http.post(
        Connection.matchadd.toString(),
        body: {
          "match_id": _matchid.toString(),
          "user_id": ValidationClass.userid.toString(),
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);

      var aa = json.decode(res.body);

      List resultlist = aa["Table"];

      if (resultlist.length > 0) {
        if (resultlist[0]["status"].toString() == "1") {
          await showDialog(
              context: context, builder: (context) => PaymentPage("Add Cash"));

          if (ValidationClass.paymentcancel == "0") {
            matchdd(_matchid);
            //  await ValidationClass.hubConnection.invoke('InsertMatch', args: [_matchid.toString(), ValidationClass.userid.toString()]);

          }
        } else if (resultlist[0]["status"].toString() == "3") {
          // pr.hide().then((isHidden) {
          //   print(isHidden);
          // });

          var data1;
          data1 = {
            "team_id": "0",
            "game_id": _lclgameid.toString(),
            "team_size_id": data["team_size_id"].toString(),
            "team_size": data["team_size"].toString(),
            "team_name": ""
          };
          Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => TeamCreatepage(data1, 0)));
        } else {
          List walletlist = aa["Table1"];

          var transactionlist = convertlist(aa["Table2"]);

          List joinedlist = aa["Table3"];

          if (joinedlist.length > 0) {
            joined = joinedlist[0]["joined"].toString();
          }

          var wallet =
              ValidationClass.settodouble(walletlist[0]["wallet"].toString());
          var bonuswallet = ValidationClass.settodouble(
              walletlist[0]["bonus_wallet"].toString());

          Provider.of<WalletModel>(context, listen: false)
              .refreshwallet(wallet, bonuswallet, transactionlist);
          setState(() {});
        }
      }

      await ValidationClass.hubConnection
          .invoke('MyMatch', args: [_matchid.toString()]);
    } catch (e) {}
    pr.hide().then((isHidden) {
      print(isHidden);
    });
    return _list;
  }

  Future<List<dynamic>> deleteuser(teamid, frienduserid) async {
    List<dynamic> _list = [];

    try {
      // await ValidationClass.hubConnection.invoke('InsertMatch', args: [_lclmatchid.toString(), ValidationClass.userid.toString()]);

      var res;

      res = await http.post(
        Connection.teamfrienddelete.toString(),
        body: {
          "team_id": teamid.toString(),
          "user_id": frienduserid.toString(),
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);
      Navigator.of(context).pop();
      Navigator.of(context).pop();
    } catch (e) {}

    return _list;
  }
}
