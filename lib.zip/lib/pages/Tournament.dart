import 'dart:convert';


import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import 'package:giffy_dialog/giffy_dialog.dart';

import 'package:progress_dialog/progress_dialog.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/model/FriendModel.dart';
import 'package:proplayerwar/model/JoinModel.dart';
import 'package:proplayerwar/model/LeaderBoardModel.dart';
import 'package:proplayerwar/model/PlayerModel.dart';

import 'package:proplayerwar/model/WalletModel.dart';
import 'package:proplayerwar/model/matchdetailsModel.dart';
import 'package:proplayerwar/pages/GameList.dart';

import 'package:proplayerwar/pages/Team/PlayerRequest.dart';

import 'package:proplayerwar/pages/Team/TeamCreate.dart';

import 'package:proplayerwar/pages/payment/AddMatch.dart';
import 'package:proplayerwar/pages/payment/PaymentPage.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:provider/provider.dart';

import 'package:socket_io_client/socket_io_client.dart';

import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:http/http.dart' as http;

class Tournamentpage extends StatefulWidget {
  final data;
  Tournamentpage(this.data);
  @override
  _TournamentpageState createState() => _TournamentpageState(data);
}

class _TournamentpageState extends State<Tournamentpage> {
  var data;
  _TournamentpageState(this.data);
  // WebSocketChannel _channel;
  Socket socket;

  Future<List<dynamic>> listprizefuture;
  Future<List<dynamic>> listleaderboardfuture;
  Future<List<dynamic>> listfriendfuture;

  var _lclmatchid = 0;
  var _lclgameid = 0;
  ProgressDialog pr;
  var joined;
  List credentiallist;
  List players;
  var _flgteam = false;
  @override
  void initState() {
    super.initState();
    joined = "0";
    pr = new ProgressDialog(context);
    pr = new ProgressDialog(context,
        type: ProgressDialogType.Normal, isDismissible: true, showLogs: true);

    _lclmatchid = ValidationClass.settoint(data["match_id"].toString());
    _lclgameid = ValidationClass.settoint(data["game_id"].toString());

    _tournament();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  Future<String> _tournament() async {
    print("token ValidationClass ${ValidationClass.token}");
    var response = await http.post(Connection.tournament, body: {
      "user_id": ValidationClass.userid.toString(),
      "match_id": _lclmatchid.toString(),
      "game_id": _lclgameid.toString(),
    }
        // headers: {
        //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // },

        );

    // Map<String, dynamic> decodedToken =
    //     JwtDecoder.decode(ValidationClass.to ken);
    // Now you can use your decoded token

    // print(candidate)
    print(response.body);
    // var aa = json.decode(response.body);
    var aa = json.decode(utf8.decode(response.bodyBytes));

    //upcoming

    var prizelist = aa["Table1"];

    if (prizelist == null) {
      prizelist = [];
    }

    listprizefuture = convertlist(prizelist);

    //ongoing

    var leaderboardlist = aa["Table"];

    if (leaderboardlist == null) {
      leaderboardlist = [];
    }

    // print('list${leaderboardlist}');
    listleaderboardfuture = convertlist(leaderboardlist);
    // print('list${listleaderboardfuture}');

    List joinedlist = aa["Table2"];

    if (joinedlist.length > 0) {
      joined = joinedlist[0]["joined"].toString();
    }

    List matchdet = aa["Table3"];

    Provider.of<MatchdetailsModel>(context, listen: false).refreshmatch(
        _lclmatchid.toString(), matchdet[0]["total_join"].toString());

    Provider.of<JoinModel>(context, listen: false).refreshjoin(joined);

    Provider.of<LeaderModel>(context, listen: false)
        .refreshleaderboard(listleaderboardfuture);

    List verificationlist = aa["Table4"];

    credentiallist = aa["Table5"];

    print(credentiallist);
    if (verificationlist.length > 0) {
      if (ValidationClass.settostring(
              verificationlist[0]["is_verification"].toString()) ==
          "0") {
        Navigator.pop(context);
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => GameList()));
      }
    }
    try {
      var aa = data["data"];
      if (aa != null) {
        Provider.of<JoinModel>(context, listen: false).refreshjoin("1");
      }
    } catch (e) {}

    players = aa["Table6"];

    if (players == null) {
      players = [];
    }

    ValidationClass.teamdata.clear();
    if (players.length == 0) {
      FriendModel friendModel = FriendModel();

      friendModel.userid = ValidationClass.userid;
      friendModel.frienduserid = ValidationClass.userid;
      // friendModel.frienduserid = s.data[index]["user_id"];
      friendModel.type = ValidationClass.matchtype;
      friendModel.name = ValidationClass.username;
      friendModel.image = ValidationClass.userimg;
      friendModel.teamid = 0;

      ValidationClass.teamdata.add(friendModel);
    } else {
      print('players' + players.toString());
      for (var item in players) {
        FriendModel friendModel = FriendModel();

        friendModel.userid = ValidationClass.userid;
        friendModel.frienduserid =
            ValidationClass.settoint(item["friend_user_id"].toString());
        // friendModel.frienduserid = s.data[index]["user_id"];
        friendModel.type = item["match_type"];
        friendModel.image = item["image"];
        friendModel.name = item["ingame_name"];
        friendModel.teamid =
            ValidationClass.settoint(item["team_id"].toString());
        ValidationClass.teamdata.add(friendModel);
       if ( friendModel.userid== friendModel.frienduserid){
         _flgteam = true;
       }
      }
    }

    Provider.of<PlayerModel>(context, listen: false)
        .refreshPlayer(ValidationClass.teamdata);

    setState(() {});
    return "";
  }

  // Future<String> getmatchcredential() async {
  //   print("token ValidationClass ${ValidationClass.token}");
  //   var response = await http.post(Connection.tournament, body: {
  //     "user_id": ValidationClass.userid.toString(),
  //     "match_id": _lclmatchid.toString()
  //   }
  //       // headers: {
  //       //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
  //       // },
  //
  //       );
  //
  //   // Map<String, dynamic> decodedToken =
  //   //     JwtDecoder.decode(ValidationClass.to ken);
  //   // Now you can use your decoded token
  //
  //   // print(candidate)
  //   print(response.body);
  //   var aa = json.decode(response.body);
  //
  //   //upcoming
  //
  //   credentiallist = aa;
  //
  //   if (credentiallist == null) {
  //     credentiallist = [];
  //   }
  //   setState(() {});
  //
  //   return "";
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: Icon(
        //     Icons.home,
        //     size: 30,
        //   ),
        // ),
        // backgroundColor: Theme.of(context).primaryColor,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "Tournament", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "Tournament",
              style: TextStyle(fontSize: 20.0, color: Colors.white),
            ),
          ],
        ),
        actions: <Widget>[
          Visibility(
            visible: data["status"].toString() == "Ongoing" ? true : false,
            child: InkWell(
                onTap: () {
                  var id, pass, seat;
                  print('pass');
                  print(credentiallist[0]["password"].toString());
                  id = credentiallist[0]["id"].toString();
                  pass = credentiallist[0]["password"].toString();
                  seat = credentiallist[0]["seatno"].toString();

                  showDialog(
                      context: context,
                      builder: (_) => NetworkGiffyDialog(
                            onlyOkButton: true,
                            image: Image.asset("assets/icon/ic_launcher.png"),
                            title: Text('Room Details',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 22.0,
                                    fontWeight: FontWeight.w600)),
                            description: Text(
                              'Room Id : ${id.toString()}\nPassword : ${pass.toString()}\nSlot No : ${seat.toString()}',
                              textAlign: TextAlign.left,
                            ),
                            entryAnimation: EntryAnimation.BOTTOM,
                            onOkButtonPressed: () {
                              Navigator.of(context).pop();
                            },
                          ));
                },
                child: Icon(
                  Icons.info_outline,
                  size: 30,
                )),
          ),
          Padding(padding: EdgeInsets.all(10.0)),
          // CartIcon(cartlist.length),
        ],
        elevation: 0,
      ),
      body: bodyTournament(context),
      bottomNavigationBar: Visibility(
        visible: data["status"].toString() == "Upcoming" ? true : false,
        child: ButtonBar(
          buttonPadding: EdgeInsets.only(bottom: 0.0, left: 6, right: 6),
          children: <Widget>[
            Consumer<JoinModel>(
              builder: (context, model, child) {
                return Container(
                  color: model.join == "1"
                      ? AppColor.disablebutton
                      : AppColor.primaryColor,
                  // decoration: BoxDecoration(
                  //   // border: Border.all(width: 0.0),
                  //   borderRadius: BorderRadius.all(Radius.circular(0.0)),
                  // color: AppColor.buttonColor,
                  // ),
                  width: MediaQuery.of(context).size.width,
                  child: FlatButton(
                    child: Text(
                      model.join == "1" ? 'Joined' : "Join",
                      style: AppTextStyle.button,
                    ),
                    // color: AppColor.primaryColor,
                    onPressed: () async {
                      if (model.join != "1") {
                        // await matchdd(_lclmatchid);

                        showDialog(
                            context: context,
                            builder: (context) => AddMatch(data));
                      }

                      // Navigator.of(context).push(MaterialPageRoute(
                      //     builder: (context) => TeamCreatepage(0, 0)));
                      // tripEditModalBottomSheet(context);
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget bodyTournament(context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6.0, vertical: 6.0),
      child: Column(
        children: <Widget>[
          Container(
            // height: MediaQuery.of(context).size.height / 4.3,
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.all(0.0),
            decoration: BoxDecoration(
              // border: Border.all(width: 0.0),
              borderRadius: BorderRadius.all(Radius.circular(2.0)),
              color: AppColor.whitecolor,
            ),
            child: Column(
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            width: MediaQuery.of(context).size.width / 2,
                            child: Text(
                              data["name"].toString(),
                              //  "PUBG MOBILE",
                              style: AppTextStyle.blacktextstyle1,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Row(
                              children: <Widget>[
                                // Padding(
                                //   padding: const EdgeInsets.only(left: 3.0),
                                //   child: Image.asset(
                                //     "assets/trophy.png",
                                //     fit: BoxFit.cover,
                                //     width: 15,
                                //     height: 15,
                                //   ),
                                // ),
                                // // Icon(
                                // //   Icons.image,
                                // //   color: Colors.grey[500],
                                // // ),
                                // SizedBox(
                                //   width: 5,
                                // ),
                                Row(
                                  children: <Widget>[
                                    Image.asset(
                                      "assets/coin.png",
                                      height: 25,
                                      width: 25,
                                    ),
                                    Text(
                                      "${data["winning_price"].toString()}",
                                      style: AppTextStyle.blacktextstyle3,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Text(
                            "Total Prize Pool",
                            style: AppTextStyle.blacktextstylelight,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: Row(
                              children: <Widget>[
                                Icon(
                                  Icons.access_time,
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Text(
                                  data["datetime"].toString(),
                                  // "Aug 04, 04:00PM",
                                  style: AppTextStyle.blacktextstyle2,
                                ),
                              ],
                            ),
                          ),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.person,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                data["team_size"].toString(),
                                //  "Solo",
                                style: AppTextStyle.blacktextstyle2,
                              ),
                            ],
                          ),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.person,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                data["match_type"].toString(),
                                //  "Solo",
                                style: AppTextStyle.blacktextstyle2,
                              ),
                            ],
                          ),
                          Visibility(
                            visible: data["match_type"].toString() == "Paid"
                                ? true
                                : false,
                            child: Row(
                              children: <Widget>[
                                // Icon(
                                //   Icons.person,
                                // ),
                                // SizedBox(
                                //   width: 5,
                                // ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.green,
                                      border: Border.all(width: 0.0),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(5.0)),
                                    ),
                                    height: 25,
                                    width: 50,
                                    child: Center(
                                      child: Row(
                                        children: <Widget>[
                                          Image.asset(
                                            "assets/coin.png",
                                            height: 15,
                                            width: 15,
                                          ),
                                          Text(
                                            data["entry_fee"].toString(),
                                            //  "Solo",
                                            style: AppTextStyle.whitetextstyle2,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Consumer<MatchdetailsModel>(
                        builder: (context, matchdetailsModel, child) {
                          print(matchdetailsModel.totaljoin);
                          return Text(
                            "${ValidationClass.settoint(data["players"].toString()) - ValidationClass.settoint(matchdetailsModel.totaljoin.toString())} LEFT",
                            style: AppTextStyle.blacktextstyle2,
                          );
                        },
                      ),
                      Text(
                        "TOTAL ${data["players"].toString()}",
                        style: AppTextStyle.blacktextstyle2,
                      ),
                    ],
                  ),
                ),
                Consumer<MatchdetailsModel>(
                  builder: (context, matchdetailsModel, child) {
                    return Padding(
                      padding: const EdgeInsets.only(
                          left: 8.0, right: 8.0, bottom: 8.0),
                      child: LinearProgressIndicator(
                        backgroundColor: Colors.grey,
                        value: ValidationClass.settoint(
                                matchdetailsModel.totaljoin.toString()) /
                            ValidationClass.settoint(data["players"]
                                .toString()), //join value/total member
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          // Divider(
          //   thickness: 0.0,
          //   color: AppColor.backColor,
          // ),
          Expanded(
            // height: MediaQuery.of(context).size.height / 1.5 - 60,
            // width: MediaQuery.of(context).size.width,
            // padding: EdgeInsets.only(top: 5.0),
            // decoration: BoxDecoration(
            //   border: Border.all(
            //       // color: AppColor.blackcolor, // set border color
            //       width: 0.0),
            //   borderRadius: BorderRadius.all(
            //     Radius.circular(
            //         15.0), //                 <--- border radius here
            //   ),
            // ),
            child: Consumer<JoinModel>(builder: (context, model, child) {
              return model.join == "1"  && _flgteam==true ? returntabbar() : returntabbar2();
            }),
          ),
        ],
      ),
    );
  }

  Widget returntabbar() {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: DefaultTabController(
        length: 3,
        child: Scaffold(
            backgroundColor: AppColor.primaryColor,
            appBar: TabBar(
              tabs: <Widget>[
                Tab(
                  child: Container(
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Player",
                      ),
                    ),
                  ),
                ),
                Tab(
                  child: Container(
                    child: Align(
                      alignment: Alignment.center,
                      // child: AppTextStyle.textWithStrokeTabbar(
                      //     "Prizes", 3.0, Colors.black, Colors.white),
                      child: Text(
                        "Prizes",
                      ),
                    ),
                  ),
                ),
                Tab(
                  child: Container(
                    child: Align(
                      alignment: Alignment.center,
                      // child: AppTextStyle.textWithStrokeTabbar(
                      //     "Leaderboard",
                      //     3.0,
                      //     Colors.black,
                      //     Colors.white),
                      child: Text("Leaderboard"),
                    ),
                  ),
                ),
              ],

              labelStyle: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
              labelColor: Colors.black,
              unselectedLabelColor: Colors.white,
              // labelColor: AppColor.whitecolor,
              // indicatorColor: Colors.green,

              unselectedLabelStyle: TextStyle(
                fontSize: 13.0,
                fontWeight: FontWeight.bold,
              ),
              // indicatorWeight: 0.0,

              // indicator: BoxDecoration(
              //     borderRadius: BorderRadius.circular(50),
              //     color: Colors.redAccent),

              indicator: ShapeDecoration(
                  shape: RoundedRectangleBorder(
                    // borderRadius:
                    //     BorderRadius.all(Radius.circular(15))
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(0),
                        topLeft: Radius.circular(0)),
                  ),
                  color: AppColor.tabColor),
              // indicatorWeight: 2 * kDefaultDotIndicatorRadius,
            ),
            body: returnbody()),
      ),
    );
  }

  Widget returntabbar2() {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
            backgroundColor: AppColor.primaryColor,
            appBar: TabBar(
              tabs: <Widget>[
                Tab(
                  child: Container(
                    child: Align(
                      alignment: Alignment.center,
                      // child: AppTextStyle.textWithStrokeTabbar(
                      //     "Prizes", 3.0, Colors.black, Colors.white),
                      child: Text(
                        "Prizes",
                      ),
                    ),
                  ),
                ),
                Tab(
                  child: Container(
                    child: Align(
                      alignment: Alignment.center,
                      // child: AppTextStyle.textWithStrokeTabbar(
                      //     "Leaderboard",
                      //     3.0,
                      //     Colors.black,
                      //     Colors.white),
                      child: Text("Leaderboard"),
                    ),
                  ),
                ),
              ],

              labelStyle: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
              labelColor: Colors.black,
              unselectedLabelColor: Colors.white,
              // labelColor: AppColor.whitecolor,
              // indicatorColor: Colors.green,

              unselectedLabelStyle: TextStyle(
                fontSize: 13.0,
                fontWeight: FontWeight.bold,
              ),
              // indicatorWeight: 0.0,

              // indicator: BoxDecoration(
              //     borderRadius: BorderRadius.circular(50),
              //     color: Colors.redAccent),

              indicator: ShapeDecoration(
                  shape: RoundedRectangleBorder(
                    // borderRadius:
                    //     BorderRadius.all(Radius.circular(15))
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(0),
                        topLeft: Radius.circular(0)),
                  ),
                  color: AppColor.tabColor),
              // indicatorWeight: 2 * kDefaultDotIndicatorRadius,
            ),
            body: returnbody2()),
      ),
    );
  }

  Widget returnbody() {
    return TabBarView(children: <Widget>[
      Container(
        color: AppColor.backColor,
        child: Padding(
          padding: const EdgeInsets.only(top: 2.0),
          child: Consumer<PlayerModel>(builder: (context, model, child) {
            return Container(
              width: MediaQuery.of(context).size.width - 5,
              color: AppColor.whitecolor,
              child: ListView.builder(
                shrinkWrap: true,
                physics: ClampingScrollPhysics(),
                itemCount: model.teamdata.length + 1,
                // 5,
                // ValidationClass.convertlist(data["data"]).length,
                itemBuilder: (BuildContext ctxt, int ind) {
                  return model.teamdata.length == ind && data["status"].toString() == "Upcoming"
                      ? Center(
                          child: InkWell(
                          onTap: () {
                            _playerlist();
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              // border: Border.all(width: 0.0),
                                borderRadius: BorderRadius.all(Radius.circular(5.0)),
                                color: Colors.green),
                            child: Padding(
                                padding: const EdgeInsets.only(top: 4.0,bottom: 4.0,left: 20.0,right: 20.0),
                                child: Text(
                                  "+",
                                  style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        ))
                      : addcardplayer1(model.teamdata[ind]);
                  // return addcardplayer();
                },
              ),
            );
          }),
        ),
      ),

      Container(
        color: AppColor.backColor,
        child: Padding(
          padding: const EdgeInsets.only(top: 2.0),
          child: _prizeFuture(),
        ),
      ),

      Container(
        color: AppColor.backColor,
        child: Consumer<LeaderModel>(
          builder: (context, model, child) {
            return Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 0.0),
                    child: _leaderbordFuture(model.listleaderboardfuture),
                  ),
                ),
              ],
            );
          },
        ),
        // child: Row(
        //   children: <Widget>[
        //     Expanded(
        //       child: Padding(
        //         padding: const EdgeInsets.only(top: 0.0),
        //         child: _upcomingFuture(listupcommingfuture),
        //       ),
        //     ),
        //   ],
        // ),
      ),
      // Container(
      //   color: AppColor.backColor,
      //   child: ListView.builder(
      //     padding: EdgeInsets.only(top: 2),
      //     scrollDirection: Axis.vertical,
      //     // padding: EdgeInsets.symmetric(horizontal: 5.0),
      //     // padding: EdgeInsets.symmetric(vertical: 0.0),

      //     // itemCount: myorder.length,
      //     itemCount: 20,
      //     itemBuilder: (BuildContext context, int index) {
      //       return Padding(
      //         padding: const EdgeInsets.all(0.0),
      //         child: Column(
      //           children: <Widget>[
      //             Visibility(
      //               visible: index == 0 ? true : false,
      //               child: SizedBox(
      //                 child: Container(
      //                   color: AppColor.backColor,
      //                 ),
      //                 height: 4.0,
      //               ),
      //             ),
      //             addcardLeaderboard(index, context),
      //           ],
      //         ),
      //       );
      //     },
      //   ),
      // ),
    ]);
  }

  Widget returnbody2() {
    return TabBarView(children: <Widget>[
      Container(
        color: AppColor.backColor,
        child: Padding(
          padding: const EdgeInsets.only(top: 2.0),
          child: _prizeFuture(),
        ),
      ),

      Container(
        color: AppColor.backColor,
        child: Consumer<LeaderModel>(
          builder: (context, model, child) {
            return Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 0.0),
                    child: _leaderbordFuture(model.listleaderboardfuture),
                  ),
                ),
              ],
            );
          },
        ),
        // child: Row(
        //   children: <Widget>[
        //     Expanded(
        //       child: Padding(
        //         padding: const EdgeInsets.only(top: 0.0),
        //         child: _upcomingFuture(listupcommingfuture),
        //       ),
        //     ),
        //   ],
        // ),
      ),
      // Container(
      //   color: AppColor.backColor,
      //   child: ListView.builder(
      //     padding: EdgeInsets.only(top: 2),
      //     scrollDirection: Axis.vertical,
      //     // padding: EdgeInsets.symmetric(horizontal: 5.0),
      //     // padding: EdgeInsets.symmetric(vertical: 0.0),

      //     // itemCount: myorder.length,
      //     itemCount: 20,
      //     itemBuilder: (BuildContext context, int index) {
      //       return Padding(
      //         padding: const EdgeInsets.all(0.0),
      //         child: Column(
      //           children: <Widget>[
      //             Visibility(
      //               visible: index == 0 ? true : false,
      //               child: SizedBox(
      //                 child: Container(
      //                   color: AppColor.backColor,
      //                 ),
      //                 height: 4.0,
      //               ),
      //             ),
      //             addcardLeaderboard(index, context),
      //           ],
      //         ),
      //       );
      //     },
      //   ),
      // ),
    ]);
  }

  Widget addcardplayer1(FriendModel frndmdl) {
    print('frndmdl.frienduserid ' + frndmdl.frienduserid.toString());
    print('frndmdl.userid ' + frndmdl.userid.toString());
    print("ValidationClass " + ValidationClass.userid.toString());
    return ListTile(
      leading: Container(
        height: 40,
        width: 40,
        decoration: BoxDecoration(
          border: Border.all(width: 0.0),
          borderRadius: BorderRadius.all(Radius.circular(50.0)),
          // color: AppColor.whitecolor,
        ),
        // child: CircleAvatar(
        //   backgroundImage:
        //    NetworkImage(
        //     Connection.profileImagePath.toString() + data["image"].toString(),
        //   ),
        // ),
        child: CachedNetworkImage(
          imageUrl: Connection.profileImagePath.toString() + frndmdl.image,
          imageBuilder: (context, imageProvider) => Container(
            width: 40.0,
            height: 40.0,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
            ),
          ),
          placeholder: (context, url) => CircularProgressIndicator(),
          errorWidget: (context, url, error) => Icon(Icons.error),
        ),
      ),
      title: Container(
        //  width: MediaQuery.of(context).size.width * 0.50,
        child: Text(
          "${frndmdl.name.toString()}",
          style: AppTextStyle.blacktextstyle5,
        ),
      ),
      trailing: InkWell(
        onTap: () {
          if (ValidationClass.settoint(frndmdl.frienduserid.toString()) !=
              ValidationClass.settoint(frndmdl.userid.toString())) {
            showDialog<String>(
              context: context,
              barrierDismissible: false, // user must tap button!
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('Validation'),
                  content: SingleChildScrollView(
                    child: ListBody(
                      children: <Widget>[
                        Text('Are You Sure You Want to delete ?'),
                        // Text('You\’re like me. I’m never satisfied.'),
                      ],
                    ),
                  ),
                  actions: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                          width: MediaQuery.of(context).size.width / 3,
                          child: FlatButton(
                            child: Text('OK',
                                style: TextStyle(color: Colors.white)),
                            onPressed: () {
                              deleteuser(frndmdl.teamid.toString(),
                                  frndmdl.frienduserid.toString());
                            },
                            color: Color.fromRGBO(0, 179, 134, 1.0),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width / 3,
                          child: FlatButton(
                            child: Text('Cancel',
                                style: TextStyle(color: Colors.white)),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            color: Color.fromRGBO(0, 179, 134, 1.0),
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              },
            );
          }
        },
        child: Icon(
          Icons.delete_forever_outlined,
          size: 35,
          color: ValidationClass.settoint(frndmdl.frienduserid.toString()) !=
                  ValidationClass.settoint(frndmdl.userid.toString())
              ? Colors.black
              : Colors.grey[400],
        ),
      ),
    );
  }

  Widget addcardplayer() {
    return ListTile(
      leading: Container(
        height: 40,
        width: 40,
        decoration: BoxDecoration(
          border: Border.all(width: 0.0),
          borderRadius: BorderRadius.all(Radius.circular(50.0)),
          // color: AppColor.whitecolor,
        ),
        child: CircleAvatar(
          backgroundImage: NetworkImage(
            Connection.profileImagePath.toString() +
                ValidationClass.userimg.toString(), // data["image"].toString(),
          ),
        ),
      ),
      title: Container(
        //  width: MediaQuery.of(context).size.width * 0.50,
        child: Text(
          "test",
          // "${data["ingame_name"].toString()}",
          style: AppTextStyle.blacktextstyle5,
        ),
      ),
      trailing: InkWell(
        onTap: () {
          if (ValidationClass.settoint(ValidationClass.userid.toString()) !=
                  ValidationClass.settoint(data["leader_user_id"].toString()) &&
              ValidationClass.settoint(ValidationClass.userid.toString()) ==
                  ValidationClass.settoint(data["user_id"].toString())) {
            showDialog<String>(
              context: context,
              barrierDismissible: false, // user must tap button!
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('Validation'),
                  content: SingleChildScrollView(
                    child: ListBody(
                      children: <Widget>[
                        Text('Are You Sure You Want to delete ?'),
                        // Text('You\’re like me. I’m never satisfied.'),
                      ],
                    ),
                  ),
                  actions: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                          width: MediaQuery.of(context).size.width / 3,
                          child: FlatButton(
                            child: Text('OK',
                                style: TextStyle(color: Colors.white)),
                            onPressed: () {
                              deleteuser(data["team_id"].toString(),
                                  data["user_id"].toString());
                            },
                            color: Color.fromRGBO(0, 179, 134, 1.0),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width / 3,
                          child: FlatButton(
                            child: Text('Cancel',
                                style: TextStyle(color: Colors.white)),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            color: Color.fromRGBO(0, 179, 134, 1.0),
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              },
            );
          }
        },
        child: Icon(
          Icons.delete,
          size: 30,
          color: Colors.black,
          // color: ValidationClass.settoint(
          //     ValidationClass.userid.toString()) !=
          //     ValidationClass.settoint(
          //         data["leader_user_id"].toString()) &&
          //     ValidationClass.settoint(
          //         ValidationClass.userid.toString()) ==
          //         ValidationClass.settoint(data["user_id"].toString())
          //     ? Colors.black
          //     : Colors.grey[400],
        ),
      ),
    );
  }

  Future<List<dynamic>> deleteuser(teamid, frienduserid) async {
    List<dynamic> _list = [];

    try {
      // await ValidationClass.hubConnection.invoke('InsertMatch', args: [_lclmatchid.toString(), ValidationClass.userid.toString()]);

      var res;

      res = await http.post(
        Connection.teamfrienddelete.toString(),
        body: {
          "team_id": teamid.toString(),
          "user_id": frienduserid.toString(),
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);
      Navigator.of(context).pop();
      // Navigator.of(context).pop();
    } catch (e) {}

    return _list;
  }

  Widget _prizeFuture() {
    return FutureBuilder(
        future: listprizefuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyprize(s, c);
            }
          }
        });
  }

  Widget bodyprize(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 0),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(0.0),
            child: Column(
              children: <Widget>[
                Visibility(
                  visible: index == 0 ? true : false,
                  child: addcardheader(s, index),
                ),
                addcardPrize(s, index),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addcardPrize(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 1.0),
      child: Container(
        width: MediaQuery.of(context).size.width,
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(left: 10.0, right: 100),
                child: Container(
                  width: MediaQuery.of(context).size.width / 5,
                  child: Center(
                    child: Text(
                      "#${s.data[index]["rank"].toString()}",
                      style: AppTextStyle.blacktextstyle5,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 20.0),
                child: Row(
                  children: <Widget>[
                    Image.asset(
                      "assets/coin.png",
                      height: 15,
                      width: 15,
                    ),
                    Text(
                      "${s.data[index]["prize"].toString()}",
                      style: AppTextStyle.blacktextstyle5,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget addcardheader(s, int index) {
    return Column(
      children: <Widget>[
        SizedBox(
          child: Container(
            color: AppColor.backColor,
          ),
          height: 5.0,
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          color: AppColor.headerColor,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 10.0, right: 100),
                  child: Text(
                    "Position",
                    style: AppTextStyle.whitetextstyle1,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 20.0),
                  child: Text(
                    "Prize",
                    style: AppTextStyle.whitetextstyle1,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _leaderbordFuture(_listleaderboardfuture) {
    return FutureBuilder(
        future: _listleaderboardfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyleaderbord(s, c);
            }
          }
        });
  }

  Widget bodyleaderbord(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 0),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.only(top: 0.0),
            child: Column(
              children: <Widget>[
                Visibility(
                  visible: index == 0 ? true : false,
                  child: SizedBox(
                    child: Container(
                      color: AppColor.backColor,
                    ),
                    height: 4.0,
                  ),
                ),
                addcardLeaderboard(s, index),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addcardLeaderboard(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 1.0),
      child: Container(
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        // decoration: BoxDecoration(
        //   border: Border.all(width: 0.0),
        //   borderRadius: BorderRadius.all(Radius.circular(0.0)),
        //   color: index == 0 || index % 2 == 0
        //       ? AppColor.whitecolor
        //       : AppColor.whitecolor,
        // ),
        // color: AppColor.whitecolor,
        child: ListTile(
          // contentPadding: EdgeInsets.all(0.0),
          // elevation: 0,
          // color: AppColor.whitecolor,
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(top: 1.0, bottom: 1.0, left: 5.0),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.0),
                    borderRadius: BorderRadius.all(Radius.circular(50.0)),
                    color: AppColor.whitecolor,
                  ),
                  // color: Colors.grey,
                  height: 40,
                  width: 40,
                  child: Center(
                    child: Icon(
                      Icons.person,
                      size: 30,
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 0.0, left: 5.0),
                child: Text(
                  s.data[index]["team_name"].toString() == ""
                      ? "${s.data[index]["user_name"].toString()}"
                      : "${s.data[index]["user_name"].toString()}",
                  style: AppTextStyle.blacktextstyle5,
                ),
              ),
            ],
          ),
          trailing: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Visibility(
                  visible: ValidationClass.settodouble(
                              s.data[index]["rank"].toString()) ==
                          0
                      ? false
                      : true,
                  child: Text("${s.data[index]["rank"].toString()}")),
              Visibility(
                  visible: ValidationClass.settodouble(
                              s.data[index]["winning_price"].toString()) ==
                          0
                      ? false
                      : true,
                  child: Text("${s.data[index]["winning_price"].toString()}")),
            ],
          ),
        ),
      ),
    );
  }

  //
  // void tripEditModalBottomSheet(context) {
  //   showModalBottomSheet(
  //       // shape: RoundedRectangleBorder(
  //       //   borderRadius: BorderRadius.all(Radius.circular(15)),
  //       // ),
  //       context: context,
  //       builder: (BuildContext bc) {
  //         return Container(
  //           decoration: BoxDecoration(
  //             // border: Border.all(width: 0.0),
  //             // borderRadius: BorderRadius.all(Radius.circular(15.0)),
  //             color: AppColor.whitecolor,
  //           ),
  //           height: MediaQuery.of(context).size.height * 0.60,
  //           child: Column(
  //             children: <Widget>[
  //               Container(
  //                 decoration: BoxDecoration(
  //                   // border: Border.all(width: 0.0),
  //                   // borderRadius: BorderRadius.only(
  //                   //     topLeft: Radius.circular(15.0),
  //                   //     topRight: Radius.circular(15.0)),
  //                   color: AppColor.primaryColor,
  //                 ),
  //                 width: MediaQuery.of(context).size.width,
  //                 child: Padding(
  //                   padding: const EdgeInsets.all(8.0),
  //                   child: Row(
  //                     children: <Widget>[
  //                       Text(
  //                         "Choose Team",
  //                         style: TextStyle(fontSize: 23.0, color: Colors.white),
  //                       ),
  //                       Spacer(),
  //                       InkWell(
  //                         onTap: () {
  //                           Navigator.of(context).pop();
  //                         },
  //                         child: Icon(Icons.cancel, size: 30),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //               // Spacer(),
  //               Container(
  //                 // decoration: BoxDecoration(
  //                 //   border: Border.all(width: 0.0),
  //                 //   borderRadius: BorderRadius.all(Radius.circular(15.0)),
  //                 //   color: AppColor.primaryColor,
  //                 // ),
  //                 color: Colors.transparent,
  //                 width: MediaQuery.of(context).size.width,
  //                 height: MediaQuery.of(context).size.height / 2.6,
  //                 child: ListView.builder(
  //                   padding: EdgeInsets.only(top: 2),
  //                   scrollDirection: Axis.vertical,
  //                   // itemCount: myorder.length,
  //                   itemCount: 5,
  //                   itemBuilder: (BuildContext context, int index) {
  //                     return Padding(
  //                       padding: const EdgeInsets.all(0.0),
  //                       child: Column(
  //                         children: <Widget>[
  //                           addcardPlayer(index, context),
  //                         ],
  //                       ),
  //                     );
  //                   },
  //                 ),
  //               ),
  //
  //               Container(
  //                 // decoration: BoxDecoration(
  //                 //   border: Border.all(width: 0.0),
  //                 //   borderRadius: BorderRadius.all(Radius.circular(15.0)),
  //                 //   color: AppColor.primaryColor,
  //                 // ),
  //                 color: AppColor.primaryColor,
  //                 width: MediaQuery.of(context).size.width,
  //                 child: Padding(
  //                   padding: const EdgeInsets.all(1.0),
  //                   child: Row(
  //                     crossAxisAlignment: CrossAxisAlignment.center,
  //                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                     children: <Widget>[
  //                       Container(
  //                         // decoration: BoxDecoration(
  //                         //   border: Border.all(width: 0.0),
  //                         //   borderRadius:
  //                         //       BorderRadius.all(Radius.circular(15.0)),
  //                         //   color: Colors.grey,
  //                         // ),
  //                         color: AppColor.backColor,
  //                         width: MediaQuery.of(context).size.width / 1.13,
  //                         child: TextField(
  //                           style: AppTextStyle.textfromfieldstyle,
  //                           decoration: InputDecoration(
  //                             counterText: '',
  //                             counterStyle: TextStyle(fontSize: 0),
  //                             fillColor: Colors.white,
  //                             contentPadding:
  //                                 EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
  //                             border: new OutlineInputBorder(
  //                               borderRadius: new BorderRadius.circular(0.0),
  //                               borderSide: new BorderSide(),
  //                             ),
  //                           ),
  //                         ),
  //                       ),
  //
  //                       // AppTextStyle.textWithStroke("Choose Player", 24.0,
  //                       //     3.0, Colors.white, Colors.red),
  //                       Spacer(),
  //                       Padding(
  //                         padding: const EdgeInsets.all(3.0),
  //                         child: Center(
  //                           child: Icon(
  //                             Icons.add,
  //                             size: 30,
  //                           ),
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         );
  //       });
  // }
  Widget addcardPlayer(int index, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 0.0),
      child: Container(
        width: MediaQuery.of(context).size.width,
        color: index == 0 || index % 2 == 0
            ? AppColor.whitecolor
            : AppColor.whitecolor,
        child: Row(
          // crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 10.0, right: 20.0),
              child: Checkbox(value: true, onChanged: null),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 0.0, right: 100),
              child: Text(
                "KOW~VIRU",
                style: AppTextStyle.blacktextstyle4,
              ),
            ),
            Icon(
              Icons.delete,
              size: 30,
            )
          ],
        ),
      ),
    );
  }

  Future<List<dynamic>> matchdd(_matchid) async {
    await pr.show();

    List<dynamic> _list = [];

    try {
      // await ValidationClass.hubConnection.invoke('InsertMatch', args: [_lclmatchid.toString(), ValidationClass.userid.toString()]);

      var res;

      res = await http.post(
        Connection.matchadd.toString(),
        body: {
          "match_id": _matchid.toString(),
          "user_id": ValidationClass.userid.toString(),
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);

      var aa = json.decode(res.body);

      List resultlist = aa["Table"];

      if (resultlist.length > 0) {
        if (resultlist[0]["status"].toString() == "1") {
          await showDialog(
              context: context, builder: (context) => PaymentPage("Add Cash"));

          if (ValidationClass.paymentcancel == "0") {
            matchdd(_matchid);
            //  await ValidationClass.hubConnection.invoke('InsertMatch', args: [_matchid.toString(), ValidationClass.userid.toString()]);

          }
        } else if (resultlist[0]["status"].toString() == "3") {
          // pr.hide().then((isHidden) {
          //   print(isHidden);
          // });

          var data1;
          data1 = {
            "team_id": "0",
            "game_id": _lclgameid.toString(),
            "team_size_id": data["team_size_id"].toString(),
            "team_size": data["team_size"].toString(),
            "team_name": ""
          };
          Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => TeamCreatepage(data1, 0)));
        } else {
          List walletlist = aa["Table1"];

          var transactionlist = convertlist(aa["Table2"]);

          List joinedlist = aa["Table3"];

          if (joinedlist.length > 0) {
            joined = joinedlist[0]["joined"].toString();
          }

          var wallet =
              ValidationClass.settodouble(walletlist[0]["wallet"].toString());
          var bonuswallet = ValidationClass.settodouble(
              walletlist[0]["bonus_wallet"].toString());

          Provider.of<WalletModel>(context, listen: false)
              .refreshwallet(wallet, bonuswallet, transactionlist);
          setState(() {});
        }
      }

      await ValidationClass.hubConnection
          .invoke('MyMatch', args: [_matchid.toString()]);
    } catch (e) {}
    pr.hide().then((isHidden) {
      print(isHidden);
    });
    return _list;
  }

  Future<String> _playerlist() async {
    await pr.show();

    print("token ValidationClass ${ValidationClass.token}");
    var response = await http.post(Connection.playerlist, body: {
      "user_id": ValidationClass.userid.toString(),
      "game_id": _lclgameid.toString(),
      "match_id": _lclmatchid.toString()
    }
        // headers: {
        //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // },
        );

    // print(candidate)
    print(response.body);
    // var aa = json.decode(response.body);
    var aa = json.decode(utf8.decode(response.bodyBytes));
    // var decodedData = json.decode(aa[0]);
    // // var decodedData = response.body;
    // print("data : $decodedData");

    //friend

    var friendlist = aa["Table"];

    if (friendlist == null) {
      friendlist = [];
    }

    listfriendfuture = convertlist(friendlist);

    pr.hide().then((isHidden) {
      print(isHidden);
    });

    showDialog(
        context: context,
        builder: (context) => PlayerRequest(friendlist, _lclmatchid));

    return "";
  }
}
