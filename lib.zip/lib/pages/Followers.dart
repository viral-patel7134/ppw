import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/pages/ProfilePage.dart';

import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';

import 'package:http/http.dart' as http;

class Followers extends StatefulWidget {
  final type, data;
  Followers(this.type, this.data);
  @override
  _FollowersState createState() => _FollowersState(type, data);
}

class _FollowersState extends State<Followers> {
  var type, data;
  _FollowersState(this.type, this.data);

 
  bool issearch = false;

  TextEditingController textEditingController = TextEditingController();

  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  Future<List<dynamic>> listtopplayerfuture;

  List li;
  @override
  void initState() {
    super.initState();

    listtopplayerfuture = getJSONData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: IconButton(
        //     icon: Icon(Icons.person_add),
        //     onPressed: () {
        //       scaffoldKey.currentState.openDrawer();
        //     },
        //   ),
        // ),
        // backgroundColor: Theme.of(context).primaryColor,
        // title: Column(
        //   crossAxisAlignment: CrossAxisAlignment.start,
        //   mainAxisAlignment: MainAxisAlignment.start,
        //   children: <Widget>[
        //     // AppTextStyle.textWithStroke(
        //     //     "TopPlayer", 23.0, 3.0, Colors.black, AppColor.backColor),
        //     Text(
        //       "Top Player",
        //       style: TextStyle(fontSize: 23.0, color: Colors.white),
        //     ),
        //   ],
        // ),

        actions: <Widget>[
          Visibility(
            visible: false,
            child: InkWell(
              onTap: () {
                setState(() {
                  listtopplayerfuture = getJSONData();
                });
              },
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  Icons.search,
                  size: 25,
                  color: AppColor.whitecolor,
                ),
              ),
            ),
          )
        ],
        title: issearch == true
            ? Padding(
                padding: const EdgeInsets.all(0.0),
                child: Container(
                  color: AppColor.primaryColor,
                  child: TextField(
                    controller: textEditingController,
                    style: AppTextStyle.whitetextstyle1,
                    autofocus: false,
                    decoration: InputDecoration(
                        // suffixIcon: InkWell(
                        //   onTap: () {
                        //     setState(() {
                        //       listtopplayerfuture = getJSONData();
                        //     });
                        //   },
                        //   child: Icon(
                        //     Icons.search,
                        //     size: 20,
                        //     color: AppColor.whitecolor,
                        //   ),
                        // ),
                        // prefixIcon: Icon(
                        //   Icons.search,
                        //   size: 25,
                        //   color: AppColor.whitecolor,
                        // ),
                        contentPadding: EdgeInsets.all(0.0),
                        border: InputBorder.none,
                        hintText: 'Search Here..',
                        hintStyle: TextStyle(
                            fontSize: 17.0,
                            fontWeight: FontWeight.bold,
                            color:Colors.white10)),
                  ),
                ),
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  // AppTextStyle.textWithStroke(
                  //     "Tournament", 23.0, 3.0, Colors.black, AppColor.backColor),
                  Text(
                    type == 'FOLLOWING' ? 'Following' : 'Follower',
                    style: TextStyle(fontSize: 20.0, color: Colors.white),
                  ),
                ],
              ),

        // actions: <Widget>[
        //   InkWell(
        //       onTap: () {
        //         setState(() {
        //           if (issearch == true) {
        //             issearch = false;
        //           } else {
        //             issearch = true;
        //           }
        //         });
        //       },
        //       child: Icon(
        //         issearch == true ? Icons.cancel : Icons.search,
        //         size: 25,
        //       )),
        //   Padding(padding: EdgeInsets.all(10.0)),
        //   // CartIcon(cartlist.length),
        // ],
        elevation: 0,
      ),
      // body: bodyTopPlayer(context),
      body: _topplayerFuture(),
      // drawer: Drawer(
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.start,
      //     crossAxisAlignment: CrossAxisAlignment.start,
      //     children: <Widget>[
      //       // DrawerHeader(
      //       //   decoration: BoxDecoration(color: Colors.red),
      //       //   margin: EdgeInsets.all(0.0),
      //       //   padding: EdgeInsets.all(0.0),
      //       //   child: TextField(
      //       //     autofocus: false,
      //       //     decoration: InputDecoration(
      //       //       contentPadding: EdgeInsets.all(9.0),
      //       //       border: InputBorder.none,
      //       //       hintText: 'Please enter text',
      //       //     ),
      //       //   ),
      //       // ),
      //       SizedBox(
      //         height: 25,
      //       ),
      //       Padding(
      //         padding: const EdgeInsets.all(2.0),
      //         child: Container(
      //           color: AppColor.primaryColor,
      //           child: TextField(
      //             style: AppTextStyle.whitetextstyle1,
      //             autofocus: false,
      //             decoration: InputDecoration(
      //                 // suffixIcon: InkWell(
      //                 //   onTap: () {},
      //                 //   child: Icon(
      //                 //     Icons.search,
      //                 //     size: 25,
      //                 //     color: AppColor.whitecolor,
      //                 //   ),
      //                 // ),
      //                 prefixIcon: Icon(
      //                   Icons.search,
      //                   size: 25,
      //                   color: AppColor.whitecolor,
      //                 ),
      //                 contentPadding: EdgeInsets.all(15.0),
      //                 border: InputBorder.none,
      //                 hintText: 'Search Here..',
      //                 hintStyle: AppTextStyle.whitetextstyle1),
      //           ),
      //         ),
      //       ),
      //       Expanded(
      //         child: ListView.builder(
      //           padding: EdgeInsets.only(top: 0),
      //           scrollDirection: Axis.vertical,

      //           // itemCount: myorder.length,
      //           itemCount: 20,
      //           itemBuilder: (BuildContext context, int index) {
      //             return addFriend(index, context);
      //           },
      //         ),
      //       ),
      //     ],
      //   ),
      // ),
    );
  }

  // Widget bodyTopPlayer(context) {
  //   return Column(
  //     mainAxisAlignment: MainAxisAlignment.start,
  //     crossAxisAlignment: CrossAxisAlignment.start,
  //     children: <Widget>[
  //       Padding(
  //         padding: const EdgeInsets.only(top: 4.0, bottom: 0.0),
  //         child: addFriendheader(0, context),
  //       ), // Container(
  //       //     height: 50,
  //       //     color: AppColor.headerColor,
  //       //     child: addFriendheader(0, context)),
  //       Expanded(
  //         child: ListView.builder(
  //           padding: EdgeInsets.only(top: 0),
  //           scrollDirection: Axis.vertical,

  //           // itemCount: myorder.length,
  //           itemCount: 20,
  //           itemBuilder: (BuildContext context, int index) {
  //             return addFriend(index, context);
  //           },
  //         ),
  //       ),
  //     ],
  //   );
  // }

  Widget addFriendheader(int index, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 0.0),
      child: Card(
        // elevation: 0,
        color: index == 0 || index % 2 == 0
            ? AppColor.headerColor
            : AppColor.headerColor,
        child: ListTile(
          leading: Text(
            "",
            style: AppTextStyle.whitetextstyle1,
          ),
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                child: Text(
                  "Name",
                  style: AppTextStyle.whitetextstyle1,
                ),
              ),
            ],
          ),
          trailing: Text(
            "Rank",
            style: AppTextStyle.whitetextstyle1,
          ),
        ),
      ),
    );
  }

  Widget addFriend(s, int index) {
    return Container(
      padding: EdgeInsets.only(left: 20, right: 20, top: 0),
      color: AppColor.whitecolor,
      child: ListTile(
        isThreeLine: false,
        // dense: true,
        leading: Padding(
          padding: const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(width: 0.0),
              borderRadius: BorderRadius.all(Radius.circular(50.0)),
              color: AppColor.whitecolor,
            ),
            // color: Colors.grey,
            height: 40,
            width: 40,
            // child: Center(
            //   child: Icon(
            //     Icons.person,
            //     size: 40,
            //     color: Colors.black,
            //   ),
            // ),

            //   child: CachedNetworkImage(
            //     fit: BoxFit.fill,
            //     imageUrl: Connection.profileImagePath.toString() +
            //         s.data[index]["image"].toString(),
            //     // "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
            //     placeholder: (context, url) =>
            //         CircularProgressIndicator(),
            //     // CircularProgressIndicator(),
            //     errorWidget: (context, url, error) =>
            //         new Icon(Icons.error),
            //   ),
            // ),

            child: InkWell(
              onTap: () {
                var data1;
                data1 = s.data[index];

                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ProfilePage(data1)));
                // Navigator.pushReplacement(
                //     context,
                //     MaterialPageRoute(
                //       builder: (context) => ProfilePage(data1),
                //     ));
              },
              child: CircleAvatar(
                backgroundImage: NetworkImage(
                  // ValidationClass.userdata["Profiledata"].toString(),
                    Connection.profileImagePath.toString() +
                        s.data[index]["image"].toString()
                  //  ValidationClass.userimg.toString(),
                  // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                ),
                radius: 90.0,
              ),
            ),
          ),
        ),
        title: Text(
          s.data[index]["name"].toString(),
        ),
        subtitle: Text(
          getmobile(s.data[index]["mobile"].toString()),
        ),
        trailing: Icon(Icons.arrow_forward_ios),
        // Padding(
        //   padding: const EdgeInsets.only(left: 2.0),
        //   child: Column(
        //     // crossAxisAlignment: CrossAxisAlignment.start,
        //     children: <Widget>[
        //       Container(
        //         width: MediaQuery.of(context).size.width * 0.7,
        //         child: Padding(
        //             padding: const EdgeInsets.only(top: 0.0, left: 15.0),
        //             child: Text(
        //               s.data[index]["name"].toString(),
        //
        //               // "Viral Patel",
        //
        //               style: AppTextStyle.blacktextstyle4,
        //             )),
        //       ),
        //     ],
        //   ),
        // ),

      ),
    );
  }


  Widget addFriend2(s, int index) {
    return InkWell(
      onTap: () {
        var data1;
        data1 = s.data[index];

        Navigator.push(context,
            MaterialPageRoute(builder: (context) => ProfilePage(data1)));
        // Navigator.pushReplacement(
        //     context,
        //     MaterialPageRoute(
        //       builder: (context) => ProfilePage(data1),
        //     ));
      },
      child: Container(
        color: AppColor.whitecolor,
        child: ListTile(
          // dense: true,
          leading: Padding(
            padding: const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(width: 0.0),
                borderRadius: BorderRadius.all(Radius.circular(50.0)),
                color: AppColor.whitecolor,
              ),
              // color: Colors.grey,
              height: 40,
              width: 40,
              // child: Center(
              //   child: Icon(
              //     Icons.person,
              //     size: 40,
              //     color: Colors.black,
              //   ),
              // ),

              //   child: CachedNetworkImage(
              //     fit: BoxFit.fill,
              //     imageUrl: Connection.profileImagePath.toString() +
              //         s.data[index]["image"].toString(),
              //     // "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
              //     placeholder: (context, url) =>
              //         CircularProgressIndicator(),
              //     // CircularProgressIndicator(),
              //     errorWidget: (context, url, error) =>
              //         new Icon(Icons.error),
              //   ),
              // ),

              child: CircleAvatar(
                backgroundImage: NetworkImage(
                    // ValidationClass.userdata["Profiledata"].toString(),
                    Connection.profileImagePath.toString() +
                        s.data[index]["image"].toString()
                    //  ValidationClass.userimg.toString(),
                    // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                    ),
                radius: 90.0,
              ),
            ),
          ),
          title: Padding(
            padding: const EdgeInsets.only(left: 2.0),
            child: Column(
              // crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: MediaQuery.of(context).size.width * 0.7,
                  child: Padding(
                      padding: const EdgeInsets.only(top: 0.0, left: 15.0),
                      child: Text(
                        s.data[index]["name"].toString(),

                        // "Viral Patel",

                        style: AppTextStyle.blacktextstyle4,
                      )),
                ),
              ],
            ),
          ),
          trailing: Icon(Icons.arrow_forward_ios),
        ),
      ),
    );
  }

  Widget addFriend1(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 5.0, left: 10.0, right: 10.0),
      child: InkWell(
        onTap: () {
          var data1;
          data1 = s.data[index];

          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ProfilePage(data1)));
          // Navigator.pushReplacement(
          //     context,
          //     MaterialPageRoute(
          //       builder: (context) => ProfilePage(data1),
          //     ));
        },
        child: Material(
          elevation: 1,
          color:
              ValidationClass.settoint(s.data[index]["user_id"].toString()) ==
                      ValidationClass.userid
                  ? AppColor.whitecolor
                  : AppColor.whitecolor,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: <Widget>[
                Padding(
                  padding:
                      const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(width: 0.0),
                      borderRadius: BorderRadius.all(Radius.circular(50.0)),
                      color: AppColor.whitecolor,
                    ),
                    // color: Colors.grey,
                    height: 60,
                    width: 60,
                    // child: Center(
                    //   child: Icon(
                    //     Icons.person,
                    //     size: 40,
                    //     color: Colors.black,
                    //   ),
                    // ),

                    //   child: CachedNetworkImage(
                    //     fit: BoxFit.fill,
                    //     imageUrl: Connection.profileImagePath.toString() +
                    //         s.data[index]["image"].toString(),
                    //     // "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
                    //     placeholder: (context, url) =>
                    //         CircularProgressIndicator(),
                    //     // CircularProgressIndicator(),
                    //     errorWidget: (context, url, error) =>
                    //         new Icon(Icons.error),
                    //   ),
                    // ),

                    child: CircleAvatar(
                      backgroundImage: NetworkImage(
                          // ValidationClass.userdata["Profiledata"].toString(),
                          Connection.profileImagePath.toString() +
                              s.data[index]["image"].toString()
                          //  ValidationClass.userimg.toString(),
                          // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                          ),
                      radius: 70.0,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Column(
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        width: MediaQuery.of(context).size.width * 0.7,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Padding(
                                padding:
                                    const EdgeInsets.only(top: 0.0, left: 15.0),
                                child: Text(
                                  s.data[index]["name"].toString(),

                                  // "Viral Patel",

                                  style: AppTextStyle.blacktextstyle4,
                                )),
                            Icon(Icons.arrow_forward_ios)
                          ],
                        ),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.only(top: 1.0),
                      //   child: Row(
                      //     // crossAxisAlignment: CrossAxisAlignment.start,

                      //     // mainAxisAlignment: MainAxisAlignment.spaceBetween,

                      //     children: <Widget>[
                      //       Padding(
                      //         padding:
                      //             const EdgeInsets.only(top: 0.0, left: 0.0),
                      //         child: Text(
                      //           "K.D " + s.data[index]["KD"].toString(),
                      //           style: AppTextStyle.blacktextstylelight,
                      //         ),
                      //       ),
                      //       Padding(
                      //         padding:
                      //             const EdgeInsets.only(top: 0.0, left: 10.0),
                      //         child: Text(
                      //           "Match Played  " +
                      //               s.data[index]["total_kills"].toString(),
                      //           style: AppTextStyle.blacktextstylelight,
                      //         ),
                      //       ),
                      //       Padding(
                      //         padding:
                      //             const EdgeInsets.only(top: 0.0, left: 25.0),
                      //         child: Text(
                      //           "Kills  " +
                      //               s.data[index]["total_kills"].toString(),
                      //           style: AppTextStyle.blacktextstylelight,
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // child: ListTile(
          //   onTap: () {
          //     var data1;
          //     data1 = s.data[index];
          //     // data = {
          //     //   "ppw_id": s.data[index]["ppw_id"],
          //     //   "user_id": s.data[index]["user_id"],
          //     //   "name": s.data[index]["name"],
          //     //   "mobile": s.data[index]["mobile"],
          //     //   "gender": s.data[index]["gender"],
          //     //   "birth_date": s.data[index]["birth_date"],
          //     //   "image": s.data[index]["image"],
          //     //   "pubg_id": s.data[index]["pubg_id"],
          //     //   "pubg_name": s.data[index]["pubg_name"],
          //     //   "pubg_level": s.data[index]["pubg_level"],
          //     //   "match_played": s.data[index]["match_played"],
          //     //   "total_kills": s.data[index]["total_kills"],
          //     //   "point": s.data[index]["point"]
          //     // };

          //     // Navigator.push(
          //     //     context, MaterialPageRoute(builder: (c) => ProfilePage(data1)));

          //     Navigator.pushReplacement(
          //         context,
          //         MaterialPageRoute(
          //           builder: (context) => ProfilePage(data1),
          //         ));
          //   },
          //   leading: Padding(
          //     padding: const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
          //     child: Container(
          //       decoration: BoxDecoration(
          //         border: Border.all(width: 0.0),
          //         borderRadius: BorderRadius.all(Radius.circular(50.0)),
          //         color: AppColor.whitecolor,
          //       ),
          //       // color: Colors.grey,
          //       height: 50,
          //       width: 50,
          //       // child: Center(
          //       //   child: Icon(
          //       //     Icons.person,
          //       //     size: 40,
          //       //     color: Colors.black,
          //       //   ),
          //       // ),
          //       child: CircleAvatar(
          //         backgroundImage: NetworkImage(
          //             // ValidationClass.userdata["Profiledata"].toString(),
          //             Connection.profileImagePath.toString() +
          //                 s.data[index]["image"].toString()
          //             //  ValidationClass.userimg.toString(),
          //             // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
          //             ),
          //         radius: 50.0,
          //       ),
          //     ),
          //   ),
          //   title: Column(
          //     children: <Widget>[
          //       Row(
          //         crossAxisAlignment: CrossAxisAlignment.start,
          //         children: <Widget>[
          //           Padding(
          //               padding: const EdgeInsets.only(top: 0.0, left: 0.0),
          //               child: Text(
          //                 s.data[index]["name"].toString(),
          //                 // "Viral Patel",
          //                 style: AppTextStyle.blacktextstyle5,
          //               )),
          //         ],
          //       ),
          //       Row(
          //         crossAxisAlignment: CrossAxisAlignment.start,
          //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //         children: <Widget>[
          //           Padding(
          //             padding: const EdgeInsets.only(top: 0.0, left: 0.0),
          //             child: Text(
          //               "K.D " + s.data[index]["KD"].toString(),
          //               style: AppTextStyle.blacktextstylelight,
          //             ),
          //           ),
          //           Padding(
          //             padding: const EdgeInsets.only(top: 0.0, left: 0.0),
          //             child: Text(
          //               "Match Played  " +
          //                   s.data[index]["total_kills"].toString(),
          //               style: AppTextStyle.blacktextstylelight,
          //             ),
          //           ),
          //           Padding(
          //             padding: const EdgeInsets.only(top: 0.0, right: 20.0),
          //             child: Text(
          //               "Kills  " + s.data[index]["total_kills"].toString(),
          //               style: AppTextStyle.blacktextstylelight,
          //             ),
          //           ),
          //         ],
          //       ),
          //     ],
          //   ),
          //   trailing: Text(
          //     (index + 1).toString(),
          //     style: AppTextStyle.blacktextstylenormal5,
          //   ),
          // ),
        ),
      ),
    );
  }

  Widget _topplayerFuture() {
    return FutureBuilder(
        future: listtopplayerfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodytopplayer(s, c);
            }
          }
        });
  }

  Widget bodytopplayer(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 1),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(0.0),
            child: Column(
              children: <Widget>[
                // Visibility(
                //   visible: index == 0 ? true : true,
                //   child: SizedBox(
                //     child: Container(
                //       color: AppColor.backColor,
                //     ),
                //     height: 2.0,
                //   ),
                // ),
                addFriend(s, index),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Future<List<dynamic>> getJSONData() async {
    List<dynamic> _topplayerlist = [];

    try {
      var res;

      // res = await http.get(
      //   Connection.topplayer.toString(),
      //   // body: {},
      //   headers: {
      //     HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
      //   },
      // );

      if (type == "FOLLOWER") {
        res = await http.post(Connection.followerlist, body: {
          "user_id":
              ValidationClass.settoint(data["user_id"].toString()).toString()
        });
      } else {
        res = await http.post(Connection.followinglist, body: {
          "user_id":
              ValidationClass.settoint(data["user_id"].toString()).toString()
        });
      }

      print("response" + res.body);
      // var decodedData = json.decode(res.body);
      var decodedData = json.decode(utf8.decode(res.bodyBytes));
      // print("data : ${decodedData['match_played']}");

      // for (var i in decodedData) {
      //   print("inside");
      //   MenuProfileModel s = MenuProfileModel(
      //       matchplayed: i["match_played"],
      //       totalkills: i["total_kills"],
      //       winprizes: i["win_prize"]);

      //   setState(() {
      //     profilelist.add(s);
      //   });
      // }

      // final int statusCode = res.statusCode;

      // var resBody;
      // if (statusCode < 200 || statusCode > 400) {
      //   resBody = [];
      // }

      // if (res.body == "null") {
      //   resBody = [];
      // } else {
      //   resBody = json.decode(res.body);
      // }
      _topplayerlist = decodedData;

      if (_topplayerlist == null) {
        _topplayerlist = [];
      }

      // print(decodedData.toString());
    } catch (e) {
      // return "Occur Error...";
    }

    return _topplayerlist;
  }

  String replaceCharAt(String oldString, int index, String newChar) {
    return oldString.substring(0, index) +
        newChar +
        oldString.substring(index + 1);
  }

  String getmobile(number) {
    var newNumber = number;
    for (int i = 5; i < number.length - 2; i++) {
      newNumber = replaceCharAt(newNumber, i, "*");
      print("PHONE_NUMBER_LOOP:$newNumber");
    }
    return newNumber;
  }
}
