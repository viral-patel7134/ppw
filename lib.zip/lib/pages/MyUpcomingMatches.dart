import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/model/MatchdetailsModel.dart';
import 'package:proplayerwar/pages/MatchPlayerDetails.dart';


import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ValidationClass.dart';

import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

class MyUpcomingMatchespage extends StatefulWidget {
  @override
  _MyUpcomingMatchespageState createState() => _MyUpcomingMatchespageState();
}

class _MyUpcomingMatchespageState extends State<MyUpcomingMatchespage> {

  bool issearch = true;

  TextEditingController textEditingController = TextEditingController();

  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  Future<List<dynamic>> listMyUpcomingMatchesfuture;

  List li;
  @override
  void initState() {
    super.initState();

    listMyUpcomingMatchesfuture = getJSONData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: IconButton(
        //     icon: Icon(Icons.person_add),
        //     onPressed: () {
        //       scaffoldKey.currentState.openDrawer();
        //     },
        //   ),
        // ),
        // backgroundColor: Theme.of(context).primaryColor,
        // title: Column(
        //   crossAxisAlignment: CrossAxisAlignment.start,
        //   mainAxisAlignment: MainAxisAlignment.start,
        //   children: <Widget>[
        //     // AppTextStyle.textWithStroke(
        //     //     "MyUpcomingMatches", 23.0, 3.0, Colors.black, AppColor.backColor),
        //     Text(
        //       "Top Player",
        //       style: TextStyle(fontSize: 23.0, color: Colors.white),
        //     ),
        //   ],
        // ),

        // actions: <Widget>[
        //   InkWell(
        //     onTap: () {
        //       setState(() {
        //         listMyUpcomingMatchesfuture = getJSONData();
        //       });
        //     },
        //     child: Padding(
        //       padding: const EdgeInsets.all(8.0),
        //       child: Icon(
        //         Icons.search,
        //         size: 25,
        //         color: AppColor.whitecolor,
        //       ),
        //     ),
        //   )
        // ],
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "Tournament", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "My Upcoming Matches",
              style: TextStyle(fontSize: 20.0, color: Colors.white),
            ),
          ],
        ),

        // actions: <Widget>[
        //   InkWell(
        //       onTap: () {
        //         setState(() {
        //           if (issearch == true) {
        //             issearch = false;
        //           } else {
        //             issearch = true;
        //           }
        //         });
        //       },
        //       child: Icon(
        //         issearch == true ? Icons.cancel : Icons.search,
        //         size: 25,
        //       )),
        //   Padding(padding: EdgeInsets.all(10.0)),
        //   // CartIcon(cartlist.length),
        // ],
        elevation: 0,
      ),
      // body: bodyMyUpcomingMatches(context),
      body: _myUpcomingMatchesFuture(),
      // drawer: Drawer(
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.start,
      //     crossAxisAlignment: CrossAxisAlignment.start,
      //     children: <Widget>[
      //       // DrawerHeader(
      //       //   decoration: BoxDecoration(color: Colors.red),
      //       //   margin: EdgeInsets.all(0.0),
      //       //   padding: EdgeInsets.all(0.0),
      //       //   child: TextField(
      //       //     autofocus: false,
      //       //     decoration: InputDecoration(
      //       //       contentPadding: EdgeInsets.all(9.0),
      //       //       border: InputBorder.none,
      //       //       hintText: 'Please enter text',
      //       //     ),
      //       //   ),
      //       // ),
      //       SizedBox(
      //         height: 25,
      //       ),
      //       Padding(
      //         padding: const EdgeInsets.all(2.0),
      //         child: Container(
      //           color: AppColor.primaryColor,
      //           child: TextField(
      //             style: AppTextStyle.whitetextstyle1,
      //             autofocus: false,
      //             decoration: InputDecoration(
      //                 // suffixIcon: InkWell(
      //                 //   onTap: () {},
      //                 //   child: Icon(
      //                 //     Icons.search,
      //                 //     size: 25,
      //                 //     color: AppColor.whitecolor,
      //                 //   ),
      //                 // ),
      //                 prefixIcon: Icon(
      //                   Icons.search,
      //                   size: 25,
      //                   color: AppColor.whitecolor,
      //                 ),
      //                 contentPadding: EdgeInsets.all(15.0),
      //                 border: InputBorder.none,
      //                 hintText: 'Search Here..',
      //                 hintStyle: AppTextStyle.whitetextstyle1),
      //           ),
      //         ),
      //       ),
      //       Expanded(
      //         child: ListView.builder(
      //           padding: EdgeInsets.only(top: 0),
      //           scrollDirection: Axis.vertical,

      //           // itemCount: myorder.length,
      //           itemCount: 20,
      //           itemBuilder: (BuildContext context, int index) {
      //             return addFriend(index, context);
      //           },
      //         ),
      //       ),
      //     ],
      //   ),
      // ),
    );
  }

  // Widget bodyMyUpcomingMatches(context) {
  //   return Column(
  //     mainAxisAlignment: MainAxisAlignment.start,
  //     crossAxisAlignment: CrossAxisAlignment.start,
  //     children: <Widget>[
  //       Padding(
  //         padding: const EdgeInsets.only(top: 4.0, bottom: 0.0),
  //         child: addFriendheader(0, context),
  //       ), // Container(
  //       //     height: 50,
  //       //     color: AppColor.headerColor,
  //       //     child: addFriendheader(0, context)),
  //       Expanded(
  //         child: ListView.builder(
  //           padding: EdgeInsets.only(top: 0),
  //           scrollDirection: Axis.vertical,

  //           // itemCount: myorder.length,
  //           itemCount: 20,
  //           itemBuilder: (BuildContext context, int index) {
  //             return addFriend(index, context);
  //           },
  //         ),
  //       ),
  //     ],
  //   );
  // }

  Widget addFriendheader(int index, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 0.0),
      child: Card(
        // elevation: 0,
        color: index == 0 || index % 2 == 0
            ? AppColor.headerColor
            : AppColor.headerColor,
        child: ListTile(
          leading: Text(
            "",
            style: AppTextStyle.whitetextstyle1,
          ),
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                child: Text(
                  "Name",
                  style: AppTextStyle.whitetextstyle1,
                ),
              ),
            ],
          ),
          trailing: Text(
            "Rank",
            style: AppTextStyle.whitetextstyle1,
          ),
        ),
      ),
    );
  }

  Widget addupcomingcard(s, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 3.0, bottom: 4.0,left: 4.0,right: 4.0),
      child: Column(
        children: <Widget>[
          InkWell(
            onTap: () {
              var data = s.data[index];

              // ValidationClass.matchtype =
              //     s.data[index]["match_type"].toString();
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (context) => MatchPlayerDetails(data)));

              // if (s.data[index]["is_verification"].toString() == "0") {
              //   Navigator.of(context)
              //       .push(MaterialPageRoute(builder: (context) => GameList()));
              // } else {
              //   ValidationClass.matchtype = s.data[index]["match_type"].toString();
              //   Navigator.of(context).push(
              //       MaterialPageRoute(builder: (context) => Tournamentpage(data)));
              // }

              Provider.of<MatchdetailsModel>(context, listen: false)
                  .refreshmatch(data["match_id"].toString(),
                      data["total_join"].toString());
            },
            child: Material(
              elevation: 2,

              // height: 80,
              color: AppColor.whitecolor,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(right: 8.0, bottom: 0),
                        child: Container(
                          height: 90,
                          width: 90,
                          color: AppColor.primaryColor,
                          // child: Image.asset(
                          //   "assets/plate1.png",
                          //   fit: BoxFit.cover,
                          // ),

                          child: CachedNetworkImage(
                            fit: BoxFit.fill,
                            imageUrl:
                                '${Connection.gameImagePath}/${s.data[index]["image"]}',
                            // "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
                            placeholder: (context, url) =>
                                CircularProgressIndicator(),
                            // CircularProgressIndicator(),
                            errorWidget: (context, url, error) =>
                                new Icon(Icons.error),
                          ),

                          // child:  Image.network(

                          //       _imageUrl,
                          //       fit: BoxFit.cover,
                          //     ),
                          // child: ClipRRect(
                          //   child: Icon(
                          //     Icons.person,
                          //     size: 75,
                          //     color: AppColor.whitecolor,
                          //   ),
                          // ),

                          // child: ClipRRect(

                          //   borderRadius: BorderRadius.circular(50),
                          //   child: SizedBox(
                          //     width: 100,
                          //     height: 100,
                          //     child: Image.network(
                          //       _imageUrl,
                          //       fit: BoxFit.cover,
                          //     ),
                          //   ),
                          // ),
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(
                              left: 2.0,
                              right: 2.0,
                              top: 5.0,
                              bottom: 5.0,
                            ),
                            child: Container(
                              width: MediaQuery.of(context).size.width - 121,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 5.0, right: 5.0),
                                    child: Row(
                                      // crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,

                                      children: <Widget>[
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              2.1,
                                          child: Text(
                                            s.data[index]["name"].toString(),
                                            // "PUBG Mobile",
                                            style: AppTextStyle.blacktextstyle5,
                                          ),
                                        ),
                                        Container(
                                          width: 50.0,
                                          decoration: BoxDecoration(
                                              // border: Border.all(width: 0.0),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(15.0)),
                                              color: AppColor.greenColor),
                                          child: Padding(
                                            padding: const EdgeInsets.all(4.0),
                                            child: Center(
                                              child: s.data[index]["status"] ==
                                                      "Upcoming"
                                                  ? Text(
                                                      s.data[index]["total_join"]
                                                                  .toString() ==
                                                              s.data[index][
                                                                      "players"]
                                                                  .toString()
                                                          ? "Full"
                                                          : "Open",
                                                      style: AppTextStyle
                                                          .cardbutton)
                                                  : Text("Live",
                                                      style: AppTextStyle
                                                          .cardbutton),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(1.0),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Icon(
                                          Icons.access_time,
                                          color: AppColor.greyColor,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          s.data[index]["datetime"]
                                              .toString(), // "Aug 04, 04:00 PM",
                                          style:
                                              AppTextStyle.blacktextstylelight,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(1.0),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Row(
                                          children: <Widget>[
                                            Icon(
                                              Icons.person,
                                              color: AppColor.greyColor,
                                            ),
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Text(
                                              s.data[index]["team_size"]
                                                  .toString(), // "Solo",
                                              style: AppTextStyle
                                                  .blacktextstylelight,
                                            ),
                                          ],
                                        ),
                                        // SizedBox(
                                        //   width: 5,
                                        // ),
                                        Row(
                                          children: <Widget>[
                                            Icon(
                                              Icons.assistant_photo,
                                              color: AppColor.greyColor,
                                            ),
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Text(
                                              "${s.data[index]["map"].toString()}",
                                              style: AppTextStyle
                                                  .blacktextstylelight,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 3.0),
                                            child: Image.asset(
                                              "assets/trophy.png",
                                              fit: BoxFit.cover,
                                              width: 10,
                                              height: 10,
                                            ),
                                          ),
                                          // Icon(
                                          //   Icons.image,
                                          //   color: Colors.grey[500],
                                          // ),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          Text(
                                            "${s.data[index]["winning_price"].toString()}",
                                            style: AppTextStyle
                                                .blacktextstylelight,
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Row(
                                        children: <Widget>[
                                          Icon(
                                            Icons.people,
                                            color: AppColor.greyColor,
                                          ),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          Text(
                                            "${s.data[index]["total_join"].toString()}/${s.data[index]["players"].toString()}",
                                            style: AppTextStyle
                                                .blacktextstylelight,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                  // Container(
                  //   color: AppColor.primaryColor,
                  //   child: Column(
                  //     children: <Widget>[
                  //       Center(
                  //         child: Padding(
                  //           padding: const EdgeInsets.all(2.0),
                  //           child: Text(
                  //             "Player Details",
                  //             style: AppTextStyle.whitetextstyle2,
                  //           ),
                  //         ),
                  //       ),
                  //       Container(
                  //           color: AppColor.greenColor,
                  //         child: ListView.builder(
                  //           shrinkWrap: true,
                  //           physics: ClampingScrollPhysics(),
                  //           itemCount: ValidationClass.convertlist(
                  //                   s.data[index]["data"])
                  //               .length,
                  //           itemBuilder: (BuildContext ctxt, int ind) {
                  //             return Padding(
                  //               padding: const EdgeInsets.only(left:8.0,bottom: 3.0),
                  //               child: Row(
                  //                 children: <Widget>[
                  //                   new Text("Player " + (ind+1).toString() + " : ",
                  //                     style: AppTextStyle.whitetextstyle2,
                  //                   ),Text(
                  //                     ValidationClass.convertlist(
                  //                                 s.data[index]["data"])[ind]
                  //                             ["ingame_name"]
                  //                         .toString(),
                  //                     style: AppTextStyle.whitetextstyle2,
                  //                   ),
                  //                 ],
                  //               ),
                  //             );
                  //           },
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  // ),

                  // ExpansionTile(
                  //   backgroundColor: Colors.white,
                  //   initiallyExpanded: true,
                  //   title: Text(
                  //     "aa",
                  //     style: TextStyle(
                  //         fontSize: 12.0, fontWeight: FontWeight.bold),
                  //   ),
                  //   children: <Widget>[
                  //     Text(
                  //       "aa",
                  //       style: TextStyle(
                  //           fontSize: 12.0, fontWeight: FontWeight.bold),
                  //     ),
                  //   ],
                  // )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _myUpcomingMatchesFuture() {
    return FutureBuilder(
        future: listMyUpcomingMatchesfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyUpcoming(s, c);
            }
          }
        });
  }

  Widget bodyUpcoming(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 2),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(0.0),
            child: Column(
              children: <Widget>[
                Visibility(
                  visible: index == 0 ? true : false,
                  child: SizedBox(
                    child: Container(
                      color: AppColor.backColor,
                    ),
                    height: 4.0,
                  ),
                ),
                addupcomingcard(s, index),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Future<List<dynamic>> getJSONData() async {
    List<dynamic> _myUpcomingMatcheslist = [];

    try {
      // var res;

      // res = await http.get(
      //   Connection.MyUpcomingMatches.toString(),
      //   // body: {},
      //   headers: {
      //     HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
      //   },
      // );

      var res = await http.post(Connection.myupcomingmatcheslist,
          body: {"user_id": ValidationClass.userid.toString()});

      print("response" + res.body);
      var decodedData =json.decode(utf8.decode(res.bodyBytes)); 
      // print("data : ${decodedData['match_played']}");

      // for (var i in decodedData) {
      //   print("inside");
      //   MenuProfileModel s = MenuProfileModel(
      //       matchplayed: i["match_played"],
      //       totalkills: i["total_kills"],
      //       winprizes: i["win_prize"]);

      //   setState(() {
      //     profilelist.add(s);
      //   });
      // }

      // final int statusCode = res.statusCode;

      // var resBody;
      // if (statusCode < 200 || statusCode > 400) {
      //   resBody = [];
      // }

      // if (res.body == "null") {
      //   resBody = [];
      // } else {
      //   resBody = json.decode(res.body);
      // }
      _myUpcomingMatcheslist = decodedData;

      if (_myUpcomingMatcheslist == null) {
        _myUpcomingMatcheslist = [];
      }

      // print(decodedData.toString());
    } catch (e) {
      // return "Occur Error...";
    }

    return _myUpcomingMatcheslist;
  }
}
