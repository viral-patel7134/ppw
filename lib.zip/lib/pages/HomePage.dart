import 'dart:async';
import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:connectivity/connectivity.dart';

// import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';

import 'package:logging/logging.dart';

import 'package:proplayerwar/BottomNavigatorScreen.dart';
import 'package:proplayerwar/Connection/Connection.dart';

import 'package:proplayerwar/model/HomePageModel.dart';
import 'package:proplayerwar/model/WalletModel.dart';

import 'package:proplayerwar/model/matchdetailsModel.dart';
import 'package:proplayerwar/pages/MenuPage.dart';
import 'package:proplayerwar/pages/MyWallet.dart';
import 'package:proplayerwar/pages/NotificationPage.dart';

import 'package:proplayerwar/pages/Tournament.dart';
import 'package:proplayerwar/model/HomeBannerModel.dart';
import 'package:proplayerwar/util/AppColor.dart';
import 'package:proplayerwar/util/AppTextStyle.dart';
import 'package:proplayerwar/util/ConnectionLost.dart';
import 'package:proplayerwar/util/ValidationClass.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:signalr_client/signalr_client.dart' as signalr;

class Homepage extends StatefulWidget {
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  Future<List<HomeBannerModel>> _banner;
  final List<HomeBannerModel> bannsrs = [];
  final List<String> imgLists = [];
  List<HomeBannerModel> bannrs = [];

  Future<List<dynamic>> listupcommingfuture;
  Future<List<dynamic>> listongoingfuture;
  Future<List<dynamic>> listmytournamentfuture;

  var lbltemp = 'HomePage';
  String deviceId;

  var cnt = 0;
  // String _connectionStatus = 'Unknown';
  // final Connectivity _connectivity = Connectivity();
  // StreamSubscription<ConnectivityResult> _connectivitySubscription;
  bool flginternet = true;
  @override
  void initState()  {
    super.initState();
    getpreference();
     checkconnection();
    // setState(() {});
    // initConnectivity();

    // _connectivitySubscription =
    //     _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
  }

  Future<String> getpreference() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      setState(() {
        ValidationClass.userdata = json.decode(prefs.getString("userjsondata"));
        ValidationClass.userid = ValidationClass.settoint(
            ValidationClass.userdata['user_id'].toString());

        ValidationClass.jwttoken = ValidationClass.settostring(
            ValidationClass.userdata['jwt'].toString());

        // ValidationClass.token = ValidationClass.settostring(
        //     ValidationClass.userdata['token'].toString());

        ValidationClass.username = ValidationClass.settostring(
            ValidationClass.userdata['name'].toString());

        ValidationClass.userimg = ValidationClass.settostring(
            ValidationClass.userdata['image'].toString());

        ValidationClass.email = ValidationClass.settostring(
            ValidationClass.userdata['email'].toString());

        ValidationClass.mobile = ValidationClass.settostring(
            ValidationClass.userdata['mobile'].toString());

        ValidationClass.ingamename = ValidationClass.settostring(
            ValidationClass.userdata['pubgname'].toString());
      });
    } catch (e) {}
    print('initState _getData before' + DateTime.now().toString());
    _banners();
    // _getData();
    print('initState _getData after' + DateTime.now().toString());
    return "Success";
  }

  Future<bool> checkconnection() async {
    print('checkconnection before' + DateTime.now().toString());
    var connectivityResult = await (Connectivity().checkConnectivity());
    print('checkconnection after' + DateTime.now().toString());
    if (connectivityResult == ConnectivityResult.mobile) {
      flginternet = false;
      return true;
    } else if (connectivityResult == ConnectivityResult.wifi) {
      flginternet = false;
      return true;
    }
    flginternet = true;
    return false;
  }

  @override
  void dispose() {
    // _connectivitySubscription.cancel();
    super.dispose();
  }
  //
  // Future<void> initConnectivity() async {
  //   ConnectivityResult result = ConnectivityResult.none;
  //   // Platform messages may fail, so we use a try/catch PlatformException.
  //   try {
  //     result = await _connectivity.checkConnectivity();
  //   } on PlatformException catch (e) {
  //     print(e.toString());
  //   }
  //
  //   // If the widget was removed from the tree while the asynchronous platform
  //   // message was in flight, we want to discard the reply rather than calling
  //   // setState to update our non-existent appearance.
  //   if (!mounted) {
  //     return Future.value(null);
  //   }
  //
  //   return _updateConnectionStatus(result);
  // }
  //
  // Future<void> _updateConnectionStatus(ConnectivityResult result) async {
  //   switch (result) {
  //     case ConnectivityResult.wifi:
  //       setState(() {
  //         _getData();
  //       });
  //       break;
  //     case ConnectivityResult.mobile:
  //       setState(() {
  //         _getData();
  //       });
  //       break;
  //     case ConnectivityResult.none:
  //       setState(() => _connectionStatus = result.toString());
  //       break;
  //     default:
  //       setState(() => _connectionStatus = 'Failed to get connectivity.');
  //       break;
  //   }
  // }
  //
  // // Future<String> _getId() async {
  // //   var deviceInfo = DeviceInfoPlugin();
  // //   if (Platform.isIOS) {
  // //     // import 'dart:io'
  // //     var iosDeviceInfo = await deviceInfo.iosInfo;
  // //     return iosDeviceInfo.identifierForVendor; // unique ID on iOS
  // //   } else {
  // //     var androidDeviceInfo = await deviceInfo.androidInfo;
  // //     return androidDeviceInfo.androidId; // unique ID on Android
  // //   }
  // // }

  // Future<void> _getData() async {
  //   // deviceId = await _getId();
  //   print('_banner ${_banner}');
  //   _banner = _banners();
  //
  // }

  void signalrinitialize() {
    final hubProtLogger = Logger("SignalR - hub");
    final transportProtLogger = Logger("SignalR - transport");

    final serverUrl = Connection.urlnewsocket + "/MyHub";
    print("url" + serverUrl.toString());
    // final connectionOptions = signalr.HttpConnectionOptions;
    final httpOptions = new signalr.HttpConnectionOptions(
      logger: transportProtLogger,
      transport: signalr.HttpTransportType.LongPolling,

      //  accessTokenFactory: jwttoken
    );

    ValidationClass.hubConnection = signalr.HubConnectionBuilder()
        .withUrl(serverUrl, options: httpOptions)
        .configureLogging(hubProtLogger)
        .build();

    new Timer.periodic(Duration(seconds: 1), (Timer t) {
      if (ValidationClass.hubConnection.state.toString() ==
          "HubConnectionState.Disconnected") {
        ValidationClass.hubConnection = signalr.HubConnectionBuilder()
            .withUrl(serverUrl, options: httpOptions)
            .configureLogging(hubProtLogger)
            .build();
        print('in timer');
        signalrconnection();
      }
    });
  }

  void signalrconnection() async {
    print("DisConnected");
    lbltemp = 'DisConnected';
    setState(() {});
    try {
      //   if (ValidationClass.hubConnection.state.toString() ==
      //     "HubConnectionState.Connected") {

      //  await ValidationClass.hubConnection.stop();
      // }

      // if (ValidationClass.hubConnection.state.toString() ==
      //     "HubConnectionState.Connected") {

      //  await ValidationClass.hubConnection.stop();
      // }

      ValidationClass.hubConnection.start().then((result) async {
        print("Connected");
        lbltemp = 'Connected';
        setState(() {});

        // ValidationClass.hubConnection.invoke("AddUser",
        //     args: <Object>[ValidationClass.userid.toString()]);

        ValidationClass.hubConnection.on('MatchDetails', (message) async {
          Provider.of<MatchdetailsModel>(context, listen: false).refreshmatch(
              message[0].toString(),
              ValidationClass.settoint(message[1].toString()));
        });

        // ValidationClass.hubConnection.on('AddUser', (message) async {
        //   print(message.toString());
        //   // print(message[0].toString());
        //   // print(message[1].toString());
        // });

        // ValidationClass.hubConnection.on('SendNotification', (message) async {
        //   print(message[0].toString());
        //   // print(message[0].toString());
        //   // print(message[1].toString());
        // });

        ValidationClass.hubConnection.on('sendupdate', (message) async {
          print(message[0].toString());

          ValidationClass.hubConnection
              .invoke("HomePage", args: [ValidationClass.userid.toString()]);
        });

        ValidationClass.hubConnection.on('GetHomePage', (message) async {
          print('in socket');
          print(message[0].toString());

          var bb = message[0].toString();
          var aa;

          try {
            aa = json.decode(bb.toString());
          } catch (e) {}

          var upcominglist = aa["Table"];

          if (upcominglist == null) {
            upcominglist = [];
          }

          listupcommingfuture = convertlist(upcominglist);

          //ongoing

          var ongoinglist = aa["Table1"];

          if (ongoinglist == null) {
            ongoinglist = [];
          }

          listongoingfuture = convertlist(ongoinglist);

//mymatches

          var mymatcheslist = aa["Table2"];

          if (mymatcheslist == null) {
            mymatcheslist = [];
          }

          listmytournamentfuture = convertlist(mymatcheslist);

          Provider.of<HomePageModel>(context, listen: false).refreshhomepage(
              listupcommingfuture, listongoingfuture, listmytournamentfuture);
        });
      });

      ValidationClass.hubConnection.onclose((error) {
        signalrconnection();
      });
    } catch (e) {
      signalrconnection();
    }

    // await ValidationClass.hubConnection.stop();

    // await ValidationClass.hubConnection
    //     .invoke("AddUser", args: <Object>[1, 0]);
    // ValidationClass.hubConnection.on("followuser", (message) async {
    //   print(message.toString());

    //   // Provider.of<FollowerModel>(context, listen: false).refreshfollower(
    //   //     message[0].toString(),
    //   //     ValidationClass.settoint(message[1].toString()));
    // });

    // ValidationClass.hubConnection.on('GetHomePage', (message) async {
    //     print(message.toString());

    //  _banner= _banners(message);
    //     // Provider.of<MatchdetailsModel>(context, listen: false).refreshmatch(
    //     //     message[0].toString(),
    //     //     ValidationClass.settoint(message[1].toString()));
    //   });

    // ValidationClass.hubConnection.invoke("HomePage", args: [ValidationClass.userid.toString()]);

    // ValidationClass.hubConnection.invoke("MoveViewFromServer").then((value) => print("invoke  : " +value));

// print(result);
    // hubConnection.start().then((result) async {
    //   final result =
    //       await hubConnection.invoke("AddUser", args: <Object>[1, 0]);
    //   print(result);
    // });

    // final conn = signalr.HubConnectionBuilder()
    //     .withUrl(
    //          Connection.urlnew + '/signalr/MyHub',

    //         //  'https://192.168.43.203:44321/MyHub',
    //         // signalr.HttpConnectionOptions(
    //         //   logging: (level, message) => print(message),
    //         // ),\
    //         )
    //     .build();

    // await conn.start();

    // conn.on('ReceiveMessage', (message) async {
    //   print(message.toString());
    //   await conn.invoke('SendMessage', args: ['Bob', 'Says hi!']);
    // });

// hubConnection.onclose( (error) => print("Connection Closed"));
  }

  // void socketconn() {
  //   socket = io(Connection.socketaddress, <String, dynamic>{
  //     'query': 'auth_token=${ValidationClass.jwttoken}',
  //     'transports': ['websocket'],
  //     'autoConnect': false,
  //     'extraHeaders': {'foo': 'bar'} // optional
  //   });
  //   socket.connect();
  //   socket.on(
  //       'reconnect',
  //       (attemptNumber) => {
  //             print('reconnected'),
  //             //_listbroad(),
  //           });
  //   socket.on(
  //       'connect',
  //       (attemptNumber) => {
  //             print('connected'),
  //             // _listbroad(),
  //           });
  //   socket.on(
  //       'reconnecting', (attemptNumber) => {print('reconnecting inisde')});
  //   socket.on('reconnect_error', (error) => {print('reconnect_error inside')});
  //   //_listupcomming();
  //   //_listongoing();
  //   //_listmytournament();
//  }

  // _listupcomming() async {
  //   print("inside upcoming");
  //   // socket.emitWithAck('UpcomingTournament', {'user': '1'}, ack: (data) {
  //   //   print("UpComingTournament data '$data'");
  //   //   // listupcomming =Future<List> [];
  //   //   setState(() {
  //   //     listupcommingfuture = convertlist(data);
  //   //   });
  //   //   // print("UpComingTournament data '$listupcommingfuture'");
  //   // });
  //   var response = await http.post(Connection.getdata, body: {
  //     "SpName": "match_masterGetData",
  //     "SearchParam": "match_master.status=1"
  //   });
  //   print(response.body);
  //   var decodedData = json.decode(response.body);
  //   if (decodedData == null) {
  //     decodedData = [];
  //   }
  //   listupcommingfuture = convertlist(decodedData);

  //   // socket.on("", (data) {
  //   //   upcominglist = data;
  //   // });
  //   _listongoing();
  // }

  // _listongoing() async {
  //   print("inside ongoing");
  //   // socket.emitWithAck('OngoingTournament', {'user': '1'}, ack: (data) {
  //   //   print("OngoingTournament data '$data'");
  //   //   // listupcomming =Future<List> [];
  //   //   setState(() {
  //   //     listongoingfuture = convertlist(data);
  //   //   });
  //   //   // print("UpComingTournament data '$listongoingfuture'");
  //   // });
  //   var response = await http.post(Connection.getdata, body: {
  //     "SpName": "match_masterGetData",
  //     "SearchParam": "match_master.status=2"
  //   });
  //   print(response.body);
  //   var decodedData = json.decode(response.body);
  //   if (decodedData == null) {
  //     decodedData = [];
  //   }
  //   listongoingfuture = convertlist(decodedData);
  //   _listmytournament();
  //   // socket.on("", (data) {
  //   //   upcominglist = data;
  //   // });
  // }

  // _listmytournament() {
  //   // print("inside ongoing");
  //   // socket.emitWithAck('OngoingTournament', {'user': '1'}, ack: (data) {
  //   //   print("OngoingTournament data '$data'");
  //   //   // listupcomming =Future<List> [];
  //   //   listmytournamentfuture = convertlist(data);
  //   //   // print("UpComingTournament data '$listongoingfuture'");
  //   // });
  //   setState(() {
  //     listmytournamentfuture = convertlist(ValidationClass.testlist);
  //   });
  // }

  Future<List> convertlist(list) async {
    return list;
  }

  Future<List<HomeBannerModel>> convertlistbanner(list) async {
    return list;
  }

  Future<List<HomeBannerModel>> _banners() async {
    print('_banners before' + DateTime.now().toString());

    try {
      print("token ValidationClass ${ValidationClass.token}");
      var response = await http.post(Connection.homepage, body: {
        "user_id": ValidationClass.userid.toString(),
        "token": ValidationClass.token.toString()
      }
          // headers: {
          //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
          // },
          );
      print('_banners after' + DateTime.now().toString());
      // print(response.body);

      // var aa = json.decode(response.body);
      var aa = json.decode(utf8.decode(response.bodyBytes));

      List bannerlist = aa["Table"];

      if (bannerlist == null) {
        bannerlist = [];
      }

      for (var i in bannerlist) {
        print("inside");
        HomeBannerModel s = HomeBannerModel(
            id: i["banner_id"], image: i["image"], title: i["title"]);
        var img = i['image'];
        setState(() {
          imgLists.add(img);
          print("images : $img");
          bannrs.add(s);
        });
      }

      _banner = convertlistbanner(bannrs);
      print("imgLists : ${imgLists.length}");

      //upcoming

      var upcominglist = aa["Table1"];

      if (upcominglist == null) {
        upcominglist = [];
      }

      listupcommingfuture = convertlist(upcominglist);

      //ongoing

      var ongoinglist = aa["Table2"];

      if (ongoinglist == null) {
        ongoinglist = [];
      }

      listongoingfuture = convertlist(ongoinglist);

//mymatches

      var mymatcheslist = aa["Table3"];

      if (mymatcheslist == null) {
        mymatcheslist = [];
      }

      listmytournamentfuture = convertlist(mymatcheslist);

      List walletlist = aa["Table4"];

      var transactionlist = convertlist(aa["Table5"]);
      var wallet =
          ValidationClass.settodouble(walletlist[0]["wallet"].toString());
      var bonuswallet =
          ValidationClass.settodouble(walletlist[0]["bonus_wallet"].toString());

      Provider.of<WalletModel>(context, listen: false)
          .refreshwallet(wallet, bonuswallet, transactionlist);

      Provider.of<HomePageModel>(context, listen: false).refreshhomepage(
          listupcommingfuture, listongoingfuture, listmytournamentfuture);

      ValidationClass.userlist = aa["Table6"];

      // signalrconnection();
      signalrinitialize();
      print('_banners end' + DateTime.now().toString());
    } catch (e) {
      print('_banners error' + DateTime.now().toString());
      print('error in banner');
      // _getData();
      if (cnt <= 5) {
        _banners();
      }
      cnt++;
    }

    return bannrs;
  }

  Widget _carausalBanner() {
    return FutureBuilder(
      future: _banner,
      builder: (c, s) {
        if (s.connectionState != ConnectionState.done) {
          return Container(
            height: 120,
          );
        } else {
          if (s.hasError) {
            return Container(
              height: 120,
              width: MediaQuery.of(context).size.width,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("Error in Loading the Banner"),
              ),
            );
          } else {
            if (s.hasData) {
              return CarouselSlider(
                options: CarouselOptions(
                    autoPlay: true,
                    viewportFraction: 1.0,
                    aspectRatio: 0.7,
                    enlargeCenterPage: true,
                    enlargeStrategy: CenterPageEnlargeStrategy.height,
                    height: 140.0),
                items: bannrs.map((i) {
                  return Builder(
                    builder: (BuildContext context) {
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        margin: EdgeInsets.symmetric(horizontal: 1.0),

                        decoration: BoxDecoration(color: Colors.white),
                        child: Image.network(
                          "${Connection.bannerImagePath}/${i.image}",
                          fit: BoxFit.fitWidth,
                          width: MediaQuery.of(context).size.width,
                        ),
                        // child: Text('text $i', style: TextStyle(fontSize: 16.0),)
                      );
                    },
                  );
                }).toList(),
              );

/*
              print("s.data.length ${s.data.length}");
              return (s.data == null)?SizedBox(): CarouselSlider.builder(
                  height: 140,
                  viewportFraction: 1.0,
                  aspectRatio: 0.7,
                  autoPlay: true,
                  enlargeCenterPage: true,
                  itemCount: (s.data.length == 0)? 0 :s.data.length,
                  itemBuilder: (c, i) {
                     print('ljkmmas /${s.data[i].image}');

                     print("s.data.hashCode ${s.data}");
                    return CachedNetworkImage(
                      // progressIndicatorBuilder: (context, url, progress) =>
                      // CircularProgressIndicator(
                      //   value: progress.progress,
                      // ),
                      placeholder: (context, url) => Container(
                        color: Colors.transparent,
                      ),
                      imageUrl:'${Connection.bannerImagePath}/${s.data[i].image}', //'${s.data[i].image}',
                      //  errorWidget: (context, url, error) => new Image.network('${Connections.s3urlsprofile}/${userdatamap['star_id']}/${profilePic[0]}',height: 50,width: 50,),


                    );
                  });*/
            } else {
              print('hasData${s.hasData}');
              return Container(
                height: 120,
              );
            }
          }
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return  flginternet == true ?  ConnectionLostScreen() : Scaffold(
      backgroundColor: AppColor.backColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,
        // leading: Padding(
        //   padding: const EdgeInsets.all(5.0),
        //   // child: Image.asset(
        //   //   "assets/ajaypackagingicon.png",
        //   //   height: 10.0,
        //   //   width: 10.0,
        //   // ),
        //   child: InkWell(
        //     onTap: () {
        //       _getData();
        //     },
        //     child: Icon(
        //       Icons.home,
        //       size: 30,
        //       color: lbltemp.toString() == "Connected"
        //           ? Colors.green
        //           : Colors.white,
        //     ),
        //   ),
        // ),
        //  // backgroundColor: Theme.of(context).primaryColor,
        title: Text(
          // _connectionStatus.toString(), // lbltemp.toString(),
          "Home",
          style: TextStyle(fontSize: 20.0, color: Colors.white),
        ),
        actions: <Widget>[
          InkWell(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (c) => NotificationPage()));
              },
              child: Icon(
                Icons.notifications_none_outlined,
                size: 25,
              )),
          Padding(padding: EdgeInsets.all(5.0)),
          InkWell(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (c) => MyWallet()));
              },
              child: Icon(
                Icons.account_balance_wallet,
                size: 25,
              )),
          Padding(padding: EdgeInsets.all(10.0)),
          // CartIcon(cartlist.length),
        ],
        elevation: 0,
      ),
      body: bodyHome(context),
      bottomNavigationBar: BottomNavigatorScreen(),
      drawer: Drawer(child: MenuPage() // Populate the Drawer in the next step.
          ),
    );
  }

  Widget bodyHome(context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 7.0, vertical: 7.0),
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 3.0, bottom: 8.0),
            child: Material(
              elevation: 5.0,
              color: AppColor.whitecolor,
              child: _carausalBanner(),
            ),
          ),
          Expanded(
            child: DefaultTabController(
              length: 3,
              child: Scaffold(
                  backgroundColor: AppColor.primaryColor,
                  appBar: TabBar(
                    tabs: <Widget>[
                      Tab(
                        child: Container(
                          child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              "Upcoming",
                            ),
                          ),
                        ),
                      ),
                      Tab(
                        child: Container(
                          child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              "Ongoing",
                            ),
                          ),
                        ),
                      ),
                      Tab(
                        child: Container(
                          child: Align(
                            alignment: Alignment.center,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Text("My"),
                                Text("Tournament"),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],

                    labelStyle: TextStyle(
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                    ),

                    labelColor: Colors.black,
                    unselectedLabelColor: Colors.white,

                    // indicatorColor: Colors.green,
                    unselectedLabelStyle: TextStyle(
                      fontSize: 12.0,
                      fontWeight: FontWeight.bold,
                    ),
                    // indicatorWeight: 0.0,
                    // indicator: BoxDecoration(
                    //     borderRadius: BorderRadius.circular(50),
                    //     color: Colors.redAccent),
                    indicator: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(0),
                                topRight: Radius.circular(0))
                            // borderRadius: BorderRadius.only(
                            //     topRight: Radius.circular(10),
                            //     topLeft: Radius.circular(10)),
                            ),
                        color: AppColor.tabColor),
                    // indicatorWeight: 2 * kDefaultDotIndicatorRadius,
                  ),
                  body: returnbody()),
            ),
          ),
        ],
      ),
    );
  }

  Widget returnbody() {
    return TabBarView(children: <Widget>[
      Container(
        color: AppColor.backColor,
        child: Consumer<HomePageModel>(
          builder: (context, model, child) {
            return Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 0.0),
                    child: _upcomingFuture(model.listupcommingfuture),
                  ),
                ),
              ],
            );
          },
        ),
        // child: Row(
        //   children: <Widget>[
        //     Expanded(
        //       child: Padding(
        //         padding: const EdgeInsets.only(top: 0.0),
        //         child: _upcomingFuture(listupcommingfuture),
        //       ),
        //     ),
        //   ],
        // ),
      ),
      Container(
        color: AppColor.backColor,
        child: Consumer<HomePageModel>(
          builder: (context, model, child) {
            return Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 0.0),
                    child: _ongoingFuture(model.listongoingfuture),
                  ),
                ),
              ],
            );
          },
        ),
        // child: Row(
        //   children: <Widget>[
        //     Expanded(
        //       child: Padding(
        //         padding: const EdgeInsets.only(top: 0.0),
        //         child: _ongoingFuture(listongoingfuture),
        //       ),
        //     ),
        //   ],
        // ),
      ),

      Container(
        color: AppColor.backColor,
        child: Consumer<HomePageModel>(
          builder: (context, model, child) {
            return Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 0.0),
                    child: _mytournamentFuture(model.listmytournamentfuture),
                  ),
                ),
              ],
            );
          },
        ),
        // child: Row(
        //   children: <Widget>[
        //     Expanded(
        //       child: Padding(
        //         padding: const EdgeInsets.only(top: 0.0),
        //         child: _mytournamentFuture(listmytournamentfuture),
        //       ),
        //     ),
        //   ],
        // ),
      ),

      // Container(
      //   color: AppColor.backColor,
      //   child: ListView.builder(
      //     padding: EdgeInsets.symmetric(vertical: 0.0),
      //     scrollDirection: Axis.vertical,
      //     // itemCount: myorder.length,
      //     itemCount: 5,
      //     itemBuilder: (BuildContext context, int index) {
      //       return Padding(
      //         padding: const EdgeInsets.all(0.0),
      //         child: Column(
      //           children: <Widget>[
      //             Visibility(
      //               visible: index == 0 ? true : false,
      //               child: SizedBox(
      //                 child: Container(
      //                   color: AppColor.backColor,
      //                 ),
      //                 height: 4.0,
      //               ),
      //             ),
      //             addcard(index, context),
      //           ],
      //         ),
      //       );
      //     },
      //   ),
      //   // color: Colors.redAccent,
      // ),
    ]);
  }

  Widget _upcomingFuture(_listupcommingfuture) {
    return FutureBuilder(
        future: _listupcommingfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyUpcoming(s, c);
            }
          }
        });
  }

  Widget bodyUpcoming(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 2),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(0.0),
            child: Column(
              children: <Widget>[
                Visibility(
                  visible: index == 0 ? true : false,
                  child: SizedBox(
                    child: Container(
                      color: AppColor.backColor,
                    ),
                    height: 4.0,
                  ),
                ),
                addupcomingcard(s, index),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget _ongoingFuture(_listongoingfuture) {
    return FutureBuilder(
        future: _listongoingfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyongoing(s, c);
            }
          }
        });
  }

  Widget bodyongoing(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 2),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(0.0),
            child: Column(
              children: <Widget>[
                Visibility(
                  visible: index == 0 ? true : false,
                  child: SizedBox(
                    child: Container(
                      color: AppColor.backColor,
                    ),
                    height: 4.0,
                  ),
                ),
                addupcomingcard(s, index),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget _mytournamentFuture(_listmytournamentfuture) {
    return FutureBuilder(
        future: _listmytournamentfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodymytournamet(s, c);
            }
          }
        });
  }

  Widget bodymytournamet(s, c) {
    return Container(
      color: AppColor.backColor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 2),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(0.0),
            child: Column(
              children: <Widget>[
                Visibility(
                  visible: index == 0 ? true : false,
                  child: SizedBox(
                    child: Container(
                      color: AppColor.backColor,
                    ),
                    height: 4.0,
                  ),
                ),
                addmymatchcard(s, index),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Widget addupcomingcard(s, int index) {
    return InkWell(
      onTap: () {
        // var data = {
        //   "name": s.data[index]["name"].toString(),
        //   "map": s.data[index]["map"].toString(),
        //   "winning_price": s.data[index]["winning_price"].toString(),
        //   "players": s.data[index]["players"].toString(),
        //   "team_size": s.data[index]["team_size"].toString(),
        //   "datetime": s.data[index]["datetime"].toString(),
        //   "type": s.data[index]["match_type"].toString(),
        //   "entry_fee": s.data[index]["entry_fee"].toString(),
        //   "id": s.data[index]["id"].toString(),
        //   "match_id": s.data[index]["match_id"].toString(),
        // };

        var data = s.data[index];

        ValidationClass.matchtype = s.data[index]["match_type"].toString();
        Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => Tournamentpage(data)));

        // if (s.data[index]["is_verification"].toString() == "0") {
        //   Navigator.of(context)
        //       .push(MaterialPageRoute(builder: (context) => GameList()));
        // } else {
        //   ValidationClass.matchtype = s.data[index]["match_type"].toString();
        //   Navigator.of(context).push(
        //       MaterialPageRoute(builder: (context) => Tournamentpage(data)));
        // }

        Provider.of<MatchdetailsModel>(context, listen: false).refreshmatch(
            data["match_id"].toString(), data["total_join"].toString());
      },
      child: Padding(
        padding: const EdgeInsets.only(top: 3.0, bottom: 5.0),
        child: Material(
          elevation: 2,

          // height: 80,
          color: AppColor.whitecolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(right: 8.0, bottom: 0),
                    child: Container(
                      height: 90,
                      width: 90,
                      color: AppColor.primaryColor,
                      // child: Image.asset(
                      //   "assets/plate1.png",
                      //   fit: BoxFit.cover,
                      // ),

                      child: CachedNetworkImage(
                        fit: BoxFit.fill,
                        imageUrl:
                            '${Connection.gameImagePath}/${s.data[index]["image"]}',
                        // "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
                        placeholder: (context, url) =>
                            CircularProgressIndicator(),
                        // CircularProgressIndicator(),
                        errorWidget: (context, url, error) =>
                            new Icon(Icons.error),
                      ),

                      // child:  Image.network(

                      //       _imageUrl,
                      //       fit: BoxFit.cover,
                      //     ),
                      // child: ClipRRect(
                      //   child: Icon(
                      //     Icons.person,
                      //     size: 75,
                      //     color: AppColor.whitecolor,
                      //   ),
                      // ),

                      // child: ClipRRect(

                      //   borderRadius: BorderRadius.circular(50),
                      //   child: SizedBox(
                      //     width: 100,
                      //     height: 100,
                      //     child: Image.network(
                      //       _imageUrl,
                      //       fit: BoxFit.cover,
                      //     ),
                      //   ),
                      // ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 2.0,
                          right: 2.0,
                          top: 5.0,
                          bottom: 5.0,
                        ),
                        child: Container(
                          width: MediaQuery.of(context).size.width - 121,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 5.0, right: 5.0),
                                child: Row(
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,

                                  children: <Widget>[
                                    Container(
                                      width: MediaQuery.of(context).size.width /
                                          2.1,
                                      child: Text(
                                        s.data[index]["name"].toString(),
                                        // "PUBG Mobile",
                                        style: AppTextStyle.blacktextstyle5,
                                      ),
                                    ),
                                    Container(
                                      // width: 50.0,
                                      decoration: BoxDecoration(
                                          // border: Border.all(width: 0.0),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(15.0)),
                                          color: AppColor.greenColor),
                                      child: Padding(
                                        padding: const EdgeInsets.all(4.0),
                                        child: Center(
                                          child: s.data[index]["status"] ==
                                                  "Upcoming"
                                              ? Row(
                                                  children: <Widget>[
                                                    // Icon(
                                                    //   Icons.person,
                                                    // ),
                                                    // SizedBox(
                                                    //   width: 5,
                                                    // ),
                                                    Container(
                                                      decoration: BoxDecoration(
                                                        color: Colors.green,
                                                        border: Border.all(
                                                            color: Colors.green,
                                                            width: 0.0),
                                                        borderRadius:
                                                            BorderRadius.all(
                                                                Radius.circular(
                                                                    5.0)),
                                                      ),
                                                      // height: 25,
                                                      // width: 50,
                                                      child: Center(
                                                        child: s.data[index][
                                                                        "match_type"]
                                                                    .toString() ==
                                                                "Paid"
                                                            ? Row(
                                                                children: <
                                                                    Widget>[
                                                                  Image.asset(
                                                                    "assets/coin.png",
                                                                    height: 15,
                                                                    width: 15,
                                                                  ),
                                                                  SizedBox(
                                                                    width: 2,
                                                                  ),
                                                                  Text(
                                                                    s.data[index]
                                                                            [
                                                                            "entry_fee"]
                                                                        .toString(),
                                                                    //  "Solo",
                                                                    style: AppTextStyle
                                                                        .whitetextstyle2,
                                                                  ),
                                                                ],
                                                              )
                                                            : Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            8.0,
                                                                        right:
                                                                            8.0),
                                                                child: Text(
                                                                  s.data[index][
                                                                          "match_type"]
                                                                      .toString(),
                                                                  style: AppTextStyle
                                                                      .whitetextstyle2,
                                                                ),
                                                              ),
                                                      ),
                                                    ),
                                                  ],
                                                )
                                              : Text("Live",
                                                  style:
                                                      AppTextStyle.cardbutton),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(1.0),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Icon(
                                      Icons.access_time,
                                      color: AppColor.greyColor,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      s.data[index]["datetime"]
                                          .toString(), // "Aug 04, 04:00 PM",
                                      style: AppTextStyle.blacktextstylelight,
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(1.0),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        Icon(
                                          Icons.person,
                                          color: AppColor.greyColor,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          s.data[index]["team_size"]
                                              .toString(), // "Solo",
                                          style:
                                              AppTextStyle.blacktextstylelight,
                                        ),
                                      ],
                                    ),
                                    // SizedBox(
                                    //   width: 5,
                                    // ),
                                    Row(
                                      children: <Widget>[
                                        Icon(
                                          Icons.assistant_photo,
                                          color: AppColor.greyColor,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          "${s.data[index]["map"].toString()}",
                                          style:
                                              AppTextStyle.blacktextstylelight,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(left: 3.0),
                                        child: Image.asset(
                                          "assets/trophy.png",
                                          fit: BoxFit.cover,
                                          width: 10,
                                          height: 10,
                                        ),
                                      ),
                                      // Icon(
                                      //   Icons.image,
                                      //   color: Colors.grey[500],
                                      // ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                        "${s.data[index]["winning_price"].toString()}",
                                        style: AppTextStyle.blacktextstylelight,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.people,
                                        color: AppColor.greyColor,
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Consumer<MatchdetailsModel>(
                                        builder: (context, matchdetailsModel,
                                            child) {
                                          return Text(
                                            ValidationClass.settoint(
                                                        matchdetailsModel
                                                            .matchid) ==
                                                    ValidationClass.settoint(s
                                                        .data[index]["match_id"]
                                                        .toString())
                                                ? "${matchdetailsModel.totaljoin.toString()}/${s.data[index]["players"].toString()}"
                                                : "${s.data[index]["total_join"].toString()}/${s.data[index]["players"].toString()}",
                                            style: AppTextStyle
                                                .blacktextstylelight,
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget addmymatchcard(s, int index) {
    return InkWell(
      onTap: () {
        // var data = {
        //   "name": s.data[index]["name"].toString(),
        //   "map": s.data[index]["map"].toString(),
        //   "winning_price": s.data[index]["winning_price"].toString(),
        //   "players": s.data[index]["players"].toString(),
        //   "team_size": s.data[index]["team_size"].toString(),
        //   "datetime": s.data[index]["datetime"].toString(),
        //   "type": s.data[index]["match_type"].toString(),
        //   "entry_fee": s.data[index]["entry_fee"].toString(),
        //   "id": s.data[index]["id"].toString(),
        //   "match_id": s.data[index]["match_id"].toString(),
        // };

        var data = s.data[index];
        ValidationClass.matchtype = s.data[index]["match_type"].toString();
        Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => Tournamentpage(data)));
      },
      child: Padding(
        padding: const EdgeInsets.only(top: 3.0, bottom: 5.0),
        child: Material(
          elevation: 2,

          // height: 80,
          color: AppColor.whitecolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(right: 8.0, bottom: 0),
                    child: Container(
                      height: 90,
                      width: 90,
                      color: AppColor.primaryColor,
                      // child: Image.asset(
                      //   "assets/plate1.png",
                      //   fit: BoxFit.cover,
                      // ),

                      child: CachedNetworkImage(
                        fit: BoxFit.fill,
                        imageUrl:
                            '${Connection.gameImagePath}/${s.data[index]["image"]}',
                        // "http://ekart.rightclickeducation.net/api/images/pubg.jpg",
                        placeholder: (context, url) =>
                            CircularProgressIndicator(),
                        // CircularProgressIndicator(),
                        errorWidget: (context, url, error) =>
                            new Icon(Icons.error),
                      ),

                      // child:  Image.network(

                      //       _imageUrl,
                      //       fit: BoxFit.cover,
                      //     ),
                      // child: ClipRRect(
                      //   child: Icon(
                      //     Icons.person,
                      //     size: 75,
                      //     color: AppColor.whitecolor,
                      //   ),
                      // ),

                      // child: ClipRRect(

                      //   borderRadius: BorderRadius.circular(50),
                      //   child: SizedBox(
                      //     width: 100,
                      //     height: 100,
                      //     child: Image.network(
                      //       _imageUrl,
                      //       fit: BoxFit.cover,
                      //     ),
                      //   ),
                      // ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 2.0,
                          right: 2.0,
                          top: 5.0,
                          bottom: 5.0,
                        ),
                        child: Container(
                          width: MediaQuery.of(context).size.width - 121,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 5.0, right: 5.0),
                                child: Row(
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,

                                  children: <Widget>[
                                    Container(
                                      width: MediaQuery.of(context).size.width /
                                          2.1,
                                      child: Text(
                                        s.data[index]["name"].toString(),
                                        // "PUBG Mobile",
                                        style: AppTextStyle.blacktextstyle5,
                                      ),
                                    ),
                                    Container(
                                      width: 50.0,
                                      decoration: BoxDecoration(
                                          // border: Border.all(width: 0.0),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(15.0)),
                                          color: AppColor.greenColor),
                                      child: Padding(
                                        padding: const EdgeInsets.all(4.0),
                                        child: Center(
                                          child: Text("Finished",
                                              style: AppTextStyle.cardbutton),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(1.0),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Icon(
                                      Icons.access_time,
                                      color: AppColor.greyColor,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      s.data[index]["datetime"]
                                          .toString(), // "Aug 04, 04:00 PM",
                                      style: AppTextStyle.blacktextstylelight,
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(1.0),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        Icon(
                                          Icons.person,
                                          color: AppColor.greyColor,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          s.data[index]["team_size"]
                                              .toString(), // "Solo",
                                          style:
                                              AppTextStyle.blacktextstylelight,
                                        ),
                                      ],
                                    ),
                                    // SizedBox(
                                    //   width: 5,
                                    // ),
                                    Row(
                                      children: <Widget>[
                                        Icon(
                                          Icons.assistant_photo,
                                          color: AppColor.greyColor,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          "${s.data[index]["map"].toString()}",
                                          style:
                                              AppTextStyle.blacktextstylelight,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(left: 3.0),
                                        child: Image.asset(
                                          "assets/trophy.png",
                                          fit: BoxFit.cover,
                                          width: 10,
                                          height: 10,
                                        ),
                                      ),
                                      // Icon(
                                      //   Icons.image,
                                      //   color: Colors.grey[500],
                                      // ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                        "${s.data[index]["winning_price"].toString()}",
                                        style: AppTextStyle.blacktextstylelight,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.people,
                                        color: AppColor.greyColor,
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                        "${s.data[index]["total_join"].toString()}/${s.data[index]["players"].toString()}",
                                        style: AppTextStyle.blacktextstylelight,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
