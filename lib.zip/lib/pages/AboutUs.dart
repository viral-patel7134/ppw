import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:proplayerwar/util/AppColor.dart';

import 'package:webview_flutter/webview_flutter.dart';

class AboutUs extends StatefulWidget {
  @override
  AboutUsState createState() {
    return AboutUsState();
  }
}

class AboutUsState extends State<AboutUs> {
  WebViewController _controller;

  var aa = '''

<html><body>
<p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:115%;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style="font-size:20px;line-height:115%;">ABOUT US</span></strong></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:115%;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;line-height:115%;font-family:"Arial","sans-serif";'>RIGHT CLICK SOLUTIONS</span></strong><span style="font-size:12px;line-height:115%;">&nbsp;</span><span style="font-size:16px;line-height:115%;">is an I.T company based out of 208,kavan arcade,station road,killa pardi,dist valsad,gujarat-396125,India. eSports or Competitive Gaming Tournaments are played across platforms such as PC, Console &amp; Mobile. Online eSports Portal was launched with an idea of bringing the tournaments experience online &amp; with a vision to reach out to every gamer in India. With a passion and a commitment to the best gaming experience, we at <strong>Pro Player War</strong>, have strived to create a community for gamers.</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:115%;font-size:15px;font-family:"Calibri","sans-serif";'><span style="font-size:16px;line-height:115%;">&nbsp;</span></p>
</body></html>
''';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About'),
        backgroundColor: AppColor.primaryColor,
      ),
      body: WebView(
        initialUrl: 'about:blank',
        onWebViewCreated: (WebViewController webViewController) {
          _controller = webViewController;
          _loadHtmlFromAssets();
        },
      ),
    );
  }

  _loadHtmlFromAssets() async {
    // String fileText = await rootBundle.loadString('assets/AboutUs.html');
    _controller.loadUrl(Uri.dataFromString(aa.toString(),
            mimeType: 'text/html', encoding: Encoding.getByName('utf-8'))
        .toString());
  }
}
