import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/Connection/Connection.dart';
import 'package:proplayerwar/model/NotificationModel.dart';
import 'package:proplayerwar/pages/ProfilePage.dart';
import 'package:proplayerwar/pages/Tournament.dart';

import 'package:proplayerwar/util/AppColor.dart';

import 'package:proplayerwar/util/ValidationClass.dart';

import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

class NotificationPage extends StatefulWidget {
  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  bool issearch = true;

  TextEditingController textEditingController = TextEditingController();

  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  Future<List<dynamic>> listNotificationfuture;

  List li;
  List notificationList;
  @override
  void initState() {
    super.initState();

    listNotificationfuture = getJSONData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<List> convertlist(list) async {
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: AppColor.whitecolor,
      appBar: AppBar(
        // iconTheme: IconThemeData(
        //   color: Colors.black, //change your color here
        // ),
        backgroundColor: AppColor.primaryColor,

        // actions: <Widget>[
        //   InkWell(
        //     onTap: () {
        //       setState(() {
        //         listNotificationfuture = getJSONData();
        //       });
        //     },
        //     child: Padding(
        //       padding: const EdgeInsets.all(8.0),
        //       child: Icon(
        //         Icons.search,
        //         size: 25,
        //         color: AppColor.whitecolor,
        //       ),
        //     ),
        //   )
        // ],
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // AppTextStyle.textWithStroke(
            //     "Tournament", 23.0, 3.0, Colors.black, AppColor.backColor),
            Text(
              "Notification",
              style: TextStyle(fontSize: 20.0, color: Colors.white),
            ),
          ],
        ),

        elevation: 2,
      ),
      // body: bodyNotification(context),
      body: _notificationFuture(),
    );
  }

  Widget addRoomCard(s, int index) {
    return Container(
      padding: EdgeInsets.only(left: 0, right: 0, top: 0),
      color: AppColor.whitecolor,
      child: Card(
        color: s.data[index]["is_view"].toString() == "1"
            ? AppColor.whitecolor
            : Colors.grey[100],
        elevation: 1,
        child: ListTile(
          visualDensity: VisualDensity.comfortable,
          isThreeLine: false,
          // dense: true,
          // leading: Container(
          //   child: Image.asset("assets/notification.png"),
          //   width: 40,
          //   height: 40,
          // ),
          leading: Icon(
            Icons.lock,
            size: 35,
            color: Colors.black87,
          ),
          title: RichText(
            text: new TextSpan(
              // Note: Styles for TextSpans must be explicitly defined.
              // Child text spans will inherit styles from parent
              style: new TextStyle(
                fontSize: 14.0,
                color: Colors.black,
              ),
              children: <TextSpan>[
                new TextSpan(text: 'Room Id '),
                new TextSpan(
                    text: s.data[index]["room_id"].toString(),
                    style: new TextStyle(fontWeight: FontWeight.bold)),
                new TextSpan(text: ', Password '),
                new TextSpan(
                    text: s.data[index]["room_password"].toString(),
                    style: new TextStyle(fontWeight: FontWeight.bold)),
                new TextSpan(text: ', Slot '),
                new TextSpan(
                    text: s.data[index]["room_slot"].toString(),
                    style: new TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),

          // Text(
          //        'Your Room Detail Id ' + s.data[index]["room_id"].toString() +
          //         ', Room Password ' + s.data[index]["room_password"].toString() +
          //            ', Room Slot ' + s.data[index]["room_slot"].toString() ,
          //         style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold),
          //       ),
          subtitle: Text(
            s.data[index]["name"].toString(),
            style: TextStyle(fontSize: 10),
          ),
        ),
      ),
    );
  }

  Widget addannouncementcard(s, int index) {
    return Container(
      padding: EdgeInsets.only(left: 0, right: 0, top: 0),
      color: AppColor.whitecolor,
      child: Card(
        color: s.data[index]["is_view"].toString() == "1"
            ? AppColor.whitecolor
            : Colors.grey[100],
        elevation: 1,
        child: ListTile(
          visualDensity: VisualDensity.comfortable,
          isThreeLine: false,
          leading: Container(
            child: Image.asset("assets/notification.png"),
            width: 40,
            height: 40,
          ),
          // dense: true,
          // leading: Icon(
          //   Icons.volume_up_outlined,
          //   size: 35,
          //   color: Colors.black,
          // ),
          title: Text(
            s.data[index]["announcement"].toString(),
            style: TextStyle(fontSize: 13),
          ),
        ),
      ),
    );
  }

  Widget addtournamentcard(s, int index) {
    return Container(
      padding: EdgeInsets.only(left: 0, right: 0, top: 0),
      color: AppColor.whitecolor,
      child: InkWell(
        onTap: () {
          ValidationClass.matchtype = s.data[index]["match_type"].toString();
          Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => Tournamentpage(s.data[index])));
        },
        child: Card(
          color: s.data[index]["is_view"].toString() == "1"
              ? AppColor.whitecolor
              : Colors.grey[100],
          elevation: 1,
          child: ListTile(
            visualDensity: VisualDensity.comfortable,
            isThreeLine: false,
            // dense: true,
            leading: Container(
              child: Image.asset("assets/notification.png"),
              width: 40,
              height: 40,
            ),
            // leading: Icon(
            //   Icons.volume_up_outlined,
            //   size: 35,
            //   color: Colors.black,
            // ),
            title: Text(
              s.data[index]["announcement"].toString(),
              style: TextStyle(fontSize: 13),
            ),
            subtitle: Text(
              s.data[index]["name"].toString(),
              style: TextStyle(fontSize: 10),
            ),
          ),
        ),
      ),
    );
  }

  Widget addyoutubecard(s, int index) {
    return Container(
      padding: EdgeInsets.only(left: 0, right: 0, top: 0),
      color: AppColor.whitecolor,
      child: InkWell(
        onTap: () {
          // launch(
          //   s.data[index]["youtube_link"].toString(),
          //   // forceSafariVC: false,
          //   // forceWebView: false,
          //   // headers: <String, String>{'my_header_key': 'my_header_value'},
          // );
        },
        child: Card(
          color: s.data[index]["is_view"].toString() == "1"
              ? AppColor.whitecolor
              : Colors.grey[100],
          elevation: 1,
          child: ListTile(
            visualDensity: VisualDensity.comfortable,
            isThreeLine: false,
            // dense: true,
            // leading: Container(
            //   child: Image.asset("assets/notification.png"),
            //   width: 40,
            //   height: 40,
            // ),
            leading: Icon(
              Icons.live_tv,
              size: 35,
              color: Colors.red,
            ),
            title: Text(
              s.data[index]["announcement"].toString(),
              style: TextStyle(fontSize: 13),
            ),
            subtitle: Text(
              s.data[index]["name"].toString(),
              style: TextStyle(fontSize: 10),
            ),
          ),
        ),
      ),
    );
  }

  Widget addNotificationrequest(s, int index) {
    return Container(
      padding: EdgeInsets.only(left: 0, right: 0, top: 0),
      color: AppColor.whitecolor,
      child: Card(
        color: s.data[index]["is_view"].toString() == "1"
            ? AppColor.whitecolor
            : Colors.grey[100],
        elevation: 1,
        child: ListTile(
          visualDensity: VisualDensity.comfortable,
          isThreeLine: false,
          // dense: true,
          leading: Padding(
            padding: const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(width: 0.0),
                borderRadius: BorderRadius.all(Radius.circular(50.0)),
                color: AppColor.whitecolor,
              ),
              // color: Colors.grey,
              height: 40,
              width: 40,

              child: InkWell(
                // onTap: () {
                //   var data1;
                //   data1 = s.data[index];
                //
                //   Navigator.pushReplacement(
                //       context,
                //       MaterialPageRoute(
                //           builder: (context) => ProfilePage(data1)));
                //
                // },
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                      // ValidationClass.userdata["Profiledata"].toString(),
                      Connection.profileImagePath.toString() +
                          s.data[index]["image"].toString()
                      //  ValidationClass.userimg.toString(),
                      // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                      ),
                  radius: 90.0,
                ),
              ),
            ),
          ),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                s.data[index]["username"].toString(),
                style: TextStyle(fontSize: 13),
              ),
              // Text(
              //  '15 Hr',
              //   style: TextStyle(fontSize: 10),
              // ),
            ],
          ),
          subtitle: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 0.40,
                child: Text(
                  s.data[index]["name"].toString(),
                  style: TextStyle(fontSize: 13),
                ),
              ),
              Row(
                children: [
                  InkWell(
                    onTap: () {
                      print('accept ' + s.data[index].toString());
                      requestaccept(
                          s.data[index]["request_from_id"].toString(),
                          s.data[index]["game_id"].toString(),
                          s.data[index]["match_id"].toString(),
                          'ACCEPT',
                          index);
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          // border: Border.all(width: 0.0),
                          borderRadius: BorderRadius.all(Radius.circular(5.0)),
                          color: Colors.green),
                      child: Padding(
                          padding: const EdgeInsets.all(6.0),
                          child: Text(
                            "Accept",
                            style: TextStyle(
                                fontSize: 11,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          )),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  InkWell(
                    onTap: () {
                      print('REJECT ' + s.data[index].toString());
                      requestaccept(
                          s.data[index]["request_from_id"].toString(),
                          s.data[index]["game_id"].toString(),
                          s.data[index]["match_id"].toString(),
                          'REJECT',
                          index);
                    },
                    child: Container(
                        decoration: BoxDecoration(
                            // border: Border.all(width: 0.0),
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            color: Colors.red),
                        child: Padding(
                            padding: const EdgeInsets.all(6.0),
                            child: Text(
                              "Reject",
                              style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ))),
                  ),
                ],
              ),
            ],
          ),

          // Padding(
          //   padding: const EdgeInsets.only(left: 2.0),
          //   child: Column(
          //     // crossAxisAlignment: CrossAxisAlignment.start,
          //     children: <Widget>[
          //       Container(
          //         width: MediaQuery.of(context).size.width * 0.7,
          //         child: Padding(
          //             padding: const EdgeInsets.only(top: 0.0, left: 15.0),
          //             child: Text(
          //               s.data[index]["name"].toString(),
          //
          //               // "Viral Patel",
          //
          //               style: AppTextStyle.blacktextstyle4,
          //             )),
          //       ),
          //     ],
          //   ),
          // ),
          // trailing: Column(
          //   mainAxisAlignment: MainAxisAlignment.end,
          //   children: [
          //     Container(
          //
          //       decoration: BoxDecoration(
          //           // border: Border.all(width: 0.0),
          //           borderRadius: BorderRadius.all(Radius.circular(5.0)),
          //           color: Colors.green),
          //       child: Padding(
          //         padding: const EdgeInsets.all(5.0),
          //         child: Icon(
          //          Icons.check
          //         ),
          //       ),
          //     ),
          //     SizedBox(
          //       height: 2,
          //     ),
          //     Container(
          //         decoration: BoxDecoration(
          //             // border: Border.all(width: 0.0),
          //             borderRadius: BorderRadius.all(Radius.circular(5.0)),
          //             color: Colors.green),
          //         child: Padding(
          //           padding: const EdgeInsets.all(5.0),
          //           child: Icon(
          //               Icons.cancel
          //           ),
          //         )),
          //   ],
          // ),
        ),
      ),
    );
  }

  Widget addNotificatinaccept(s, int index) {
    return Container(
      padding: EdgeInsets.only(left: 0, right: 0, top: 0),
      color: AppColor.whitecolor,
      child: Card(
        color: s.data[index]["is_view"].toString() == "1"
            ? AppColor.whitecolor
            : Colors.grey[100],
        elevation: 1,
        child: ListTile(
          visualDensity: VisualDensity.comfortable,
          isThreeLine: false,
          // dense: true,
          leading: Padding(
            padding: const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 0.0),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(width: 0.0),
                borderRadius: BorderRadius.all(Radius.circular(50.0)),
                color: AppColor.whitecolor,
              ),
              // color: Colors.grey,
              height: 40,
              width: 40,

              child: InkWell(
                // onTap: () {
                //   var data1;
                //   data1 = s.data[index];
                //
                //   Navigator.pushReplacement(
                //       context,
                //       MaterialPageRoute(
                //           builder: (context) => ProfilePage(data1)));
                //
                // },
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                      // ValidationClass.userdata["Profiledata"].toString(),
                      Connection.profileImagePath.toString() +
                          s.data[index]["image"].toString()
                      //  ValidationClass.userimg.toString(),
                      // "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
                      ),
                  radius: 90.0,
                ),
              ),
            ),
          ),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                s.data[index]["username"].toString(),
                style: TextStyle(fontSize: 13),
              ),
              // Text(
              //  '15 Hr',
              //   style: TextStyle(fontSize: 10),
              // ),
            ],
          ),
          subtitle: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 0.40,
                child: Consumer<NotificationModel>(
                    builder: (context, model, child) {
                  return Text(
                    notificationList[index]['announcement'].toString(),
                    // s.data[index]["announcement"].toString(),
                    style: TextStyle(fontSize: 13),
                  );
                }),
              ),
            ],
          ),

          // Padding(
          //   padding: const EdgeInsets.only(left: 2.0),
          //   child: Column(
          //     // crossAxisAlignment: CrossAxisAlignment.start,
          //     children: <Widget>[
          //       Container(
          //         width: MediaQuery.of(context).size.width * 0.7,
          //         child: Padding(
          //             padding: const EdgeInsets.only(top: 0.0, left: 15.0),
          //             child: Text(
          //               s.data[index]["name"].toString(),
          //
          //               // "Viral Patel",
          //
          //               style: AppTextStyle.blacktextstyle4,
          //             )),
          //       ),
          //     ],
          //   ),
          // ),
          // trailing: Column(
          //   mainAxisAlignment: MainAxisAlignment.end,
          //   children: [
          //     Container(
          //
          //       decoration: BoxDecoration(
          //           // border: Border.all(width: 0.0),
          //           borderRadius: BorderRadius.all(Radius.circular(5.0)),
          //           color: Colors.green),
          //       child: Padding(
          //         padding: const EdgeInsets.all(5.0),
          //         child: Icon(
          //          Icons.check
          //         ),
          //       ),
          //     ),
          //     SizedBox(
          //       height: 2,
          //     ),
          //     Container(
          //         decoration: BoxDecoration(
          //             // border: Border.all(width: 0.0),
          //             borderRadius: BorderRadius.all(Radius.circular(5.0)),
          //             color: Colors.green),
          //         child: Padding(
          //           padding: const EdgeInsets.all(5.0),
          //           child: Icon(
          //               Icons.cancel
          //           ),
          //         )),
          //   ],
          // ),
        ),
      ),
    );
  }

  String replaceCharAt(String oldString, int index, String newChar) {
    return oldString.substring(0, index) +
        newChar +
        oldString.substring(index + 1);
  }

  String getmobile(number) {
    var newNumber = number;
    for (int i = 5; i < number.length - 2; i++) {
      newNumber = replaceCharAt(newNumber, i, "*");
      print("PHONE_NUMBER_LOOP:$newNumber");
    }
    return newNumber;
  }

  Widget _notificationFuture() {
    return FutureBuilder(
        future: listNotificationfuture,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            ));
          } else {
            if (s.hasError) {
              return Center(
                child: Text(
                  'No Data Found. Error',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else if (s.data.isEmpty) {
              return Center(
                child: Text(
                  'No Data Found.',
                  style: TextStyle(color: Colors.black87, fontSize: 18),
                ),
              );
            } else {
              return bodyNotification(s, c);
            }
          }
        });
  }

  Widget bodyNotification(s, c) {
    return Container(
      color: AppColor.whitecolor,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 1),
        scrollDirection: Axis.vertical,
        // itemCount: myorder.length,
        itemCount: s.data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.only(top: 0.0, left: 10, right: 10),
            child: Column(
              children: <Widget>[
                // Visibility(
                //   visible: index == 0 ? true : false,
                //   child: SizedBox(
                //     child: Container(
                //       color: AppColor.backColor,
                //     ),
                //     height: 1.0,
                //   ),
                // ),
                s.data[index]["type"] == "REQUEST" &&
                        s.data[index]["request_accept"] == "REQUESTED"
                    ? addNotificationrequest(s, index)
                    : s.data[index]["type"] == "REQUEST" &&
                            s.data[index]["request_accept"] != "REQUESTED"
                        ? addNotificatinaccept(s, index)
                        : s.data[index]["type"] == "ROOM"
                            ? addRoomCard(s, index)
                            : s.data[index]["type"] == 'ANNOUNCEMENT'
                                ? addannouncementcard(s, index)
                                : s.data[index]["type"] == 'TOURNAMENT'
                                    ? addtournamentcard(s, index)
                                    : s.data[index]["type"] == 'YOUTUBE LINK'
                                        ? addyoutubecard(s, index)
                                        : s.data[index]["type"] ==
                                                'YOUTUBE LINK ALL'
                                            ? addyoutubecard(s, index)
                                            : Container(
                                                height: 10,
                                              ),
              ],
            ),
          );
        },
      ),
      // color: Colors.redAccent,
    );
  }

  Future<List<dynamic>> getJSONData() async {
    List<dynamic> _notificationlist = [];

    try {
      // var searchcrite = " (ifnull(user_master.name,'''') like '%" +
      //     textEditingController.text +
      //     "%' or ifnull(user_master.mobile,'''') like '%" +
      //     textEditingController.text +
      //     "%' ) and user_master.user_id != " +
      //     ValidationClass.userid.toString();
      var searchcrite =
          " notification_master.user_id = " + ValidationClass.userid.toString();
      print('searchcrite ' + searchcrite.toString());
      var res = await http.post(Connection.getdata, body: {
        "SpName": "App_notification_master",
        "SearchParam": searchcrite
      });

      print("response" + res.body);
      // var decodedData = json.decode(res.body);
      var decodedData = json.decode(utf8.decode(res.bodyBytes));
      // print("data : ${decodedData['match_played']}");

      // for (var i in decodedData) {
      //   print("inside");
      //   MenuProfileModel s = MenuProfileModel(
      //       matchplayed: i["match_played"],
      //       totalkills: i["total_kills"],
      //       winprizes: i["win_prize"]);

      //   setState(() {
      //     profilelist.add(s);
      //   });
      // }

      // final int statusCode = res.statusCode;

      // var resBody;
      // if (statusCode < 200 || statusCode > 400) {
      //   resBody = [];
      // }

      // if (res.body == "null") {
      //   resBody = [];
      // } else {
      //   resBody = json.decode(res.body);
      // }
      _notificationlist = decodedData;

      if (_notificationlist == null) {
        _notificationlist = [];
      }

      notificationList = _notificationlist;

      Provider.of<NotificationModel>(context, listen: false)
          .refreshPlayer(notificationList);

      // print(decodedData.toString());
    } catch (e) {
      // return "Occur Error...";
    }

    return _notificationlist;
  }

  Future<List<dynamic>> requestaccept(
      _fromuserid, _gameid, _matchid, _type, index) async {
    List<dynamic> _list = [];

    try {
      var res;
      res = await http.post(
        Connection.requestaccept.toString(),
        body: {
          "user_id": ValidationClass.userid.toString(),
          "request_from_id": _fromuserid.toString(),
          "game_id": _gameid.toString(),
          "match_id": _matchid.toString(),
          "status": _type.toString()
        },
        // headers: {
        // //   HttpHeaders.authorizationHeader: "Bearer ${ValidationClass.token}"
        // // },
      );

      print("response" + res.body);
      _list = json.decode(res.body);

      if (_list[0]['flg'].toString() == "3") {
        showDialog<String>(
          context: context,
          barrierDismissible: false, // user must tap button!
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Validation'),
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    Text('Already in team'),
                    // Text('You\’re like me. I’m never satisfied.'),
                  ],
                ),
              ),
              actions: <Widget>[
                Container(
                  width: MediaQuery.of(context).size.width,
                  child: FlatButton(
                    child: Text('OK', style: TextStyle(color: Colors.white)),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    color: Color.fromRGBO(0, 179, 134, 1.0),
                  ),
                ),
              ],
            );
          },
        );

      } else {
        if (_type.toString() == 'ACCEPT') {
          setState(() {
            notificationList[index]['request_accept'] = 'ACCEPT';
            notificationList[index]['announcement'] =
                'You Have Successfully accept invitation..';
          });

          Provider.of<NotificationModel>(context, listen: false)
              .refreshPlayer(notificationList);
          print('notificationList' + notificationList.toString());
        }

        if (_type.toString() == 'REJECT') {
          setState(() {
            notificationList[index]['request_accept'] = 'REJECT';
            notificationList[index]['announcement'] =
                'You Have Rejected invitation..';
          });

          Provider.of<NotificationModel>(context, listen: false)
              .refreshPlayer(notificationList);
          print('notificationList' + notificationList.toString());
        }
      }
    } catch (e) {}

    return _list;
  }
}
