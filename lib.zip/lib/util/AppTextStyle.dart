import 'package:flutter/material.dart';
import 'package:proplayerwar/util/AppColor.dart';

class AppTextStyle {
  static TextStyle header = TextStyle(
      fontSize: 19.0, color: AppColor.whitecolor, fontWeight: FontWeight.bold);

  static TextStyle blacktextstyle1 = TextStyle(
      fontSize: 18.0, fontWeight: FontWeight.bold, color: AppColor.blackcolor);

  static TextStyle blacktextstylenormal1 = TextStyle(
      fontSize: 19.0,
      fontWeight: FontWeight.normal,
      color: AppColor.blackcolor);

  static TextStyle blacktextstyle2 = TextStyle(
      fontSize: 11.0, fontWeight: FontWeight.bold, color: AppColor.blackcolor);

  static TextStyle blacktextstylenormal2 = TextStyle(
      fontSize: 11.0,
      fontWeight: FontWeight.normal,
      color: AppColor.blackcolor);

  static TextStyle blacktextstyle3 = TextStyle(
      fontSize: 26.0, fontWeight: FontWeight.bold, color: AppColor.blackcolor);

  static TextStyle blacktextstylenormal3 = TextStyle(
      fontSize: 30.0,
      fontWeight: FontWeight.normal,
      color: AppColor.blackcolor);

  static TextStyle blacktextstyle4 = TextStyle(
      fontSize: 16.0, fontWeight: FontWeight.bold, color: AppColor.blackcolor);

  static TextStyle blacktextstylenormal4 = TextStyle(
      fontSize: 17.0,
      fontWeight: FontWeight.normal,
      color: AppColor.blackcolor);

  static TextStyle blacktextstyle5 = TextStyle(
      fontSize: 14.0, fontWeight: FontWeight.bold, color: AppColor.blackcolor);

  static TextStyle blacktextstyle7 = TextStyle(
      fontSize: 15.0, fontWeight: FontWeight.bold, color: AppColor.blackcolor);

  static TextStyle blacktextstylenormal5 = TextStyle(
      fontSize: 13.0,
      fontWeight: FontWeight.normal,
      color: AppColor.blackcolor);

  static TextStyle blacktextstylelight = TextStyle(
      fontSize: 10.0, fontWeight: FontWeight.normal, color: AppColor.greyColor);

  static TextStyle blacktextstylelight2 = TextStyle(
      fontSize: 13.0, fontWeight: FontWeight.normal, color: AppColor.greyColor);

  static TextStyle blacktextstylelight3 = TextStyle(
      fontSize: 15.0, fontWeight: FontWeight.normal, color: AppColor.greyColor);

  static TextStyle whitetextstyle1 = TextStyle(
      fontSize: 17.0, fontWeight: FontWeight.bold, color: AppColor.whitecolor);

  static TextStyle whitetextstyle2 = TextStyle(
      fontSize: 13.0, fontWeight: FontWeight.bold, color: AppColor.whitecolor);

  static TextStyle whitetextstyle3 = TextStyle(
      fontSize: 16.0, fontWeight: FontWeight.bold, color: Colors.white);

  static TextStyle whitetextstyle4 = TextStyle(
      fontSize: 29.0, fontWeight: FontWeight.bold, color: AppColor.whitecolor);

  static TextStyle whitetextstyle5 = TextStyle(
      fontSize: 12.0, fontWeight: FontWeight.bold, color: AppColor.whitecolor);

  static TextStyle whitetextstyle6 = TextStyle(
      fontSize: 23.0, fontWeight: FontWeight.bold, color: AppColor.whitecolor);

  static TextStyle whitetextstyle7 = TextStyle(
      fontSize: 15.0, fontWeight: FontWeight.bold, color: AppColor.whitecolor);

  static TextStyle whitetextstylenormal1 = TextStyle(
      fontSize: 19.0,
      fontWeight: FontWeight.normal,
      color: AppColor.whitecolor);

  static TextStyle whitetextstylenormal2 = TextStyle(
      fontSize: 15.0,
      fontWeight: FontWeight.normal,
      color: AppColor.whitecolor);

  static TextStyle whitetextstylenormal3 = TextStyle(
      fontSize: 16.0, fontWeight: FontWeight.normal, color: Colors.white);

  static TextStyle whitetextstylenormal4 = TextStyle(
      fontSize: 29.0,
      fontWeight: FontWeight.normal,
      color: AppColor.whitecolor);

  static TextStyle whitetextstylenormal5 = TextStyle(
      fontSize: 12.0,
      fontWeight: FontWeight.normal,
      color: AppColor.whitecolor);

  static TextStyle whitetextstylenormal6 = TextStyle(
      fontSize: 10.0,
      fontWeight: FontWeight.normal,
      color: AppColor.whitecolor);

  static TextStyle textfromfieldstyle = TextStyle(
      fontSize: 19.0, fontWeight: FontWeight.bold, color: AppColor.blackcolor);

  static TextStyle cardbutton = TextStyle(
      fontSize: 10.0, fontWeight: FontWeight.bold, color: Colors.white);

  static TextStyle cardbuttonblack = TextStyle(
      fontSize: 10.0, fontWeight: FontWeight.bold, color: Colors.black);

  static TextStyle button = TextStyle(fontSize: 16, color: Colors.white);

  static TextStyle msghead = TextStyle(
      fontSize: 17.0, fontWeight: FontWeight.bold, color: Colors.black);

  static TextStyle msg = TextStyle(
      fontSize: 13.0, fontWeight: FontWeight.normal, color: Colors.black);

  static TextStyle msgtime = TextStyle(
      fontSize: 12.0, fontWeight: FontWeight.normal, color: Colors.grey);

  static TextStyle bluetextstyle = TextStyle(
      fontSize: 14.0, fontWeight: FontWeight.bold, color: Colors.blueAccent);

  static Widget textWithStrokeTabbar(
      String text, double strokeWidth, Color textColor, Color strokeColor) {
    return Stack(
      children: <Widget>[
        Text(
          text,
          style: TextStyle(
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = strokeWidth
              ..color = strokeColor,
          ),
        ),
        Text(text,
            style: TextStyle(
              color: textColor,
            )),
      ],
    );
  }

  static Widget textWithStroke(String text, double fontSize, double strokeWidth,
      Color textColor, Color strokeColor) {
    return Stack(
      children: <Widget>[
        Text(
          text,
          style: TextStyle(
            fontSize: fontSize,
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = strokeWidth
              ..color = strokeColor,
          ),
        ),
        Text(text,
            style: TextStyle(
              fontSize: fontSize,
              color: textColor,
            )),
      ],
    );
  }
}
