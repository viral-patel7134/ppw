import 'dart:convert';

import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:proplayerwar/model/FriendModel.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class ValidationClass {
  static Map userdata;
  static int userid = 0;
  static String username = "";
  static String userimg = "";
  static String ingamename = "";
  static String mobile = "";
  static String email = "";
  static var jwttoken;
  static var token = "";
  static String matchtype = "";

  static String paymentcancel = "";

  static List userlist;
  static List<FriendModel> teamdata = [];

  // static double wallet = 0;
  // static double bonuswallet = 0;

  //  accessTokenFactory: jwttoken

  static var hubConnection;

  // static Future<List<dynamic>> transactionlist;

  static double settodouble(String obj) {
    if (obj == null || obj == "" || obj == "null") {
      return 0;
    }
    return double.parse(obj.toString());
  }

  static int settoint(String obj) {
    if (obj == null || obj == "" || obj == "null") {
      return 0;
    }
    return int.parse(obj.toString());
  }

  static String settostring(String obj) {
    if (obj == null || obj == "" || obj == "null") {
      return "";
    }
    return obj.toString();
  }

  static bool isNumeric(String s) {
    if (s == null) {
      return false;
    }
    return double.tryParse(s) != null;
  }

  static double formatwithtwodigit(String obj) {
    if (obj == null || obj == "" || obj == "null") {
      return 0;
    }
    return double.parse(double.parse(obj.toString()).toStringAsFixed(2));
  }

  static onBasicAlertPressed(BuildContext context, header, msg) {
    // Alert(
    //   context: context,
    //   title: header.toString(),
    //   desc: msg.toString(),
    // ).show();

    Alert(
      context: context,
      // style: alertStyle,
      type: AlertType.info,
      title: header.toString(),
      desc: msg.toString(),
      buttons: [
        DialogButton(
          child: Text(
            "Ok",
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
          color: Color.fromRGBO(0, 179, 134, 1.0),
          radius: BorderRadius.circular(0.0),
        ),
      ],
    ).show();
  }

  static onBasicAlertPressed2(context, header, msg) {
    // Alert(
    //   context: context,
    //   title: header.toString(),
    //   desc: msg.toString(),
    // ).show();

    Alert(
      context: context,
      // style: alertStyle,
      type: AlertType.info,
      title: header.toString(),
      desc: msg.toString(),
      buttons: [
        DialogButton(
          child: Text(
            "Ok",
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(context);
            Navigator.pop(context);
          },
          color: Color.fromRGBO(0, 179, 134, 1.0),
          radius: BorderRadius.circular(0.0),
        ),
      ],
    ).show();
  }

  static List<dynamic> convertlist(aa) {
    return json.decode(aa);
  }

}
