import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AppColor {
  static Color whitecolor = Colors.white;
  static Color backColor = Color(0xffdadada);
  static Color backColor1 = Color(0xffFCFBFB);
  static Color primaryColor = Color(0xff232a3a);

  // static Color buttonColor = Color(0xfff78888);
  
   static Color buttonColor = Color(0xff232a3a);

  static Color cardbuttonColor = Color(0xff4163fe);

  static Color tabColor = Color(0xffecc654);

  static Color headerColor = Color(0xff7fd0ae);

  static Color greyColor = Color(0xff697b89);


  static Color greenColor = Color(0xff2CB903);

  // static Color primaryColor = Color(0xffC70039);
  static Color gradientStart = Color(0xddef32d9);
  static Color gradientEnd = Color(0xFF89fffd);

  static Color blackcolor = Colors.black;
  // static Color blackcolor = Color(0xff000000);
  static Color gradient1 = Color(0xfff0b612);
  static Color gradient2 = Color(0xffeb196d);
  static Color pinkcolor = Color(0xddfa5791);
  static Color gradient3 = Color(0xfffe5862);
  static Color gradient4 = Color(0xff6f5a7e);
  static Color darkyellow = Color(0xffe4d010);
  static Color gradient5 = Color(0xffeb196d);
  static Color gradient6 = Color(0xfff0b612);
  static Color headercolor = Color(0xffec7b9a);
  static Color successbtn = Color(0xff9ceda8);
  static Color cancelbtn = Color(0xffe677a3);
  static Color profiletop = Color(0xfff762a2);
  static Color profilebottom = Color(0xfff96666);

  static Color disableGradientstart = Color(0xffe677a3);
  static Color disableGradientEnd = Color(0xffe8cb79);
  static Color disablebutton = Color(0xff666666);

  static LinearGradient redGradian = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [
      Color(0xffC70030),
      Color(0xffC70039),
    ],
  );
}
