import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:proplayerwar/Connection/Connection.dart';

import 'package:install_plugin/install_plugin.dart';




class AutoUpdate extends StatefulWidget {
  @override
  _AutoUpdateState createState() => _AutoUpdateState();
}

class _AutoUpdateState extends State<AutoUpdate> {
  bool downloading = false;
  var progressString = "";
  var dwnldpath;
  bool startdwn = false;

  // int progress = 0;

  // ReceivePort _receivePort = ReceivePort();
  // static downloadingCallback(id, status, progress) {
  //   ///Looking up for a send port
  //   SendPort sendPort = IsolateNameServer.lookupPortByName("downloading");

  //   ///ssending the data
  //   sendPort.send([id, status, progress]);
  // }

  @override
  void initState() {
    super.initState();
    // IsolateNameServer.registerPortWithName(
    //     _receivePort.sendPort, "downloading");

    // _receivePort.listen((message) {
    //   setState(() {
    //     progress = message[2];
    //   });

    //   print(progress);
    // });

    // FlutterDownloader.registerCallback(downloadingCallback);

    downloadFile();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Image.asset(
          "assets/home/login.png",
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          fit: BoxFit.cover,
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Text(
                  "Download",
                  style: TextStyle(fontSize: 20.0, color: Colors.white),
                ),
              ],
            ),
            leading: Icon(
              Icons.file_download,
              size: 25,
            ),
          ),
          body: startdwn == true
              ? Center(
                  child: Container(
                  height: 120.0,
                  width: MediaQuery.of(context).size.width * 0.6,
                  child: Card(
                    color: Colors.transparent,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Visibility(
                            visible: downloading == true ? true : false,
                            child: CircularProgressIndicator()),
                        SizedBox(
                          height: 20.0,
                        ),
                        Text(
                          "Downloading File: $progressString",
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                        // SizedBox(
                        //   height: 20.0,
                        // ),

                        // FlatButton(
                        //   onPressed: () {
                        //     downloadFile();
                        //   },
                        //   child: Text("Start Downloading"),
                        //   color: Colors.redAccent,
                        //   textColor: Colors.white,
                        // )
                        SizedBox(
                          height: 20.0,
                        ),
                        Visibility(
                            visible: downloading == false ? true : false,
                            child: InkWell(
                              onTap: () {
                                onClickInstallApk();
                                // OpenFile.open(dwnldpath);
                              },
                              child: Container(
                                height: 25,
                                width: 125,
                                color: Colors.white,
                                child: Row(
                                  
                                  mainAxisAlignment:  MainAxisAlignment.center,
                                  children: <Widget>[
                                    Icon(
                                      Icons.file_upload,
                                      color: Colors.green,
                                      size: 20,
                                    ),
                                    Text(
                                      "Open",
                                      style: TextStyle(color: Colors.green),
                                    )
                                  ],
                                ),
                              ),
                            )),
                      ],
                    ),
                  ),
                ))
              : Center(child: CircularProgressIndicator()),
        ),
      ],
    );
  }

  void onClickInstallApk() async {
    if (dwnldpath.isEmpty) {
      print('make sure the apk file is set');
      return;
    }
    Map<Permission, PermissionStatus> permissions = await [
      Permission.location,
      Permission.storage,
    ].request();
    if (permissions[Permission.storage] == PermissionStatus.granted) {
      InstallPlugin.installApk(dwnldpath, 'com.rclick.proplayerwar')
          .then((result) {
        print('install apk $result');
      }).catchError((error) {
        print('install apk error: $error');
      });
    } else {
      print('Permission request fail!');
    }
  }

  Future<void> downloadFile() async {
    Dio dio = Dio();
    final status = await Permission.storage.request();

    try {
      if (status.isGranted) {
        print(Connection.apksize);
        startdwn = true;
        var dir = await getExternalStorageDirectory();
        dwnldpath = "${dir.path}/ppw.apk";
        await dio.download(
          Connection.apkpath,
          dwnldpath,
          data: (data) {
            print(data);
          },
          onReceiveProgress: (rec, total) {
            // if (total != -1) {
            print(((rec / Connection.apksize) * 100).toStringAsFixed(0) + "%");
            // }
            setState(() {
              downloading = true;
              progressString =
                  ((rec / Connection.apksize) * 100).toStringAsFixed(0) + "%";
            });
          },
          options: Options(
              responseType: ResponseType.bytes,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              }),
        );
      } else {
        print("Permission deined");
      }
    } catch (e) {
      print(e);
    }

    setState(() {
      downloading = false;
      progressString = "Completed";
    });
    print("Download completed");
  }

  // Future<void> downloadFile() async {
  //   final status = await Permission.storage.request();

  //   if (status.isGranted) {
  //     final externalDir = await getExternalStorageDirectory();

  //     final id = await FlutterDownloader.enqueue(
  //       url:Connection.apkpath,
  //       savedDir: externalDir.path,
  //       fileName: "ppw.apk",
  //       showNotification: true,
  //       openFileFromNotification: true,
  //     );
  //     print(id);
  //   } else {
  //     print("Permission deined");
  //   }
  // }
}
