class HomeBannerModel {
  var id, title, image;
  HomeBannerModel({this.id, this.image, this.title});
}
