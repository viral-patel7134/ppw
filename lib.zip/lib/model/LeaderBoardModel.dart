import 'package:flutter/material.dart';

class LeaderModel extends ChangeNotifier {
  Future<List<dynamic>> listleaderboardfuture;

  void refreshleaderboard(
      var _listleaderboardfuture) {
    print('in model');
    listleaderboardfuture = _listleaderboardfuture;

    notifyListeners();
  }
}
