import 'package:flutter/material.dart';

class WalletModel extends ChangeNotifier {
  var wallet;
  var bonuswallet;
  Future<List<dynamic>> listtransaction;

  // WalletModel();

  // double get wallet1 => wallet;
  // double get bonuswallet1 => bonuswallet;
  // Future<List<dynamic>> get listtransaction1 => listtransaction;

  void refreshwallet(
      var _wallet, var _bonuswallet, Future<List<dynamic>> _listtransaction) {
    wallet = _wallet;
    bonuswallet = _bonuswallet;

    listtransaction = _listtransaction;
    notifyListeners();
  }
}
