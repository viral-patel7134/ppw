import 'package:flutter/material.dart';


class TeamPlayerModel extends ChangeNotifier {
  List playerdata;

  void refreshPlayer(var _playerdata) {
    playerdata = _playerdata;

    notifyListeners();
  }
}
