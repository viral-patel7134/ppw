class FriendModel {
  int userid;
  int frienduserid;
  var name;
  var type;
  var image;
  int teamid;

}
