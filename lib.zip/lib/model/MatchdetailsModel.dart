import 'package:flutter/material.dart';

class MatchdetailsModel extends ChangeNotifier {
  var matchid;
  var totaljoin;

  // MatchdetailsModel();

  // double get wallet1 => wallet;
  // double get bonuswallet1 => bonuswallet;
  // Future<List<dynamic>> get listtransaction1 => listtransaction;

  void refreshmatch(
      var _matchid, var _totaljoin) {
    matchid = _matchid;
    totaljoin = _totaljoin;
    print(matchid);

    notifyListeners();
  }
}
