import 'package:flutter/material.dart';

class FollowerModel extends ChangeNotifier {
  var follower;
  var following;



  // JoinModel();

  // double get wallet1 => wallet;
  // double get bonuswallet1 => bonuswallet;
  // Future<List<dynamic>> get listtransaction1 => listtransaction;

  void refreshfollower(
      var _follower,var _following) {
    follower = _follower;
    following = _following;
    notifyListeners();
  }
}
