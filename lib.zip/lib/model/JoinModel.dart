import 'package:flutter/material.dart';

class JoinModel extends ChangeNotifier {
  var join;



  // JoinModel();

  // double get wallet1 => wallet;
  // double get bonuswallet1 => bonuswallet;
  // Future<List<dynamic>> get listtransaction1 => listtransaction;

  void refreshjoin(
      var _join) {
    join = _join;
    notifyListeners();
  }
}
