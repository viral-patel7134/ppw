class MenuProfileModel {
  var matchplayed, totalkills, winprizes;
  MenuProfileModel({this.matchplayed, this.totalkills, this.winprizes});
}
