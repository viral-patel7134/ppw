import 'package:flutter/material.dart';

class HomePageModel extends ChangeNotifier {
  Future<List<dynamic>> listupcommingfuture;
  Future<List<dynamic>> listongoingfuture;
  Future<List<dynamic>> listmytournamentfuture;
  // MatchdetailsModel();

  // double get wallet1 => wallet;
  // double get bonuswallet1 => bonuswallet;
  // Future<List<dynamic> get listtransaction1 => listtransaction;

  void refreshhomepage(
      var _listupcommingfuture, var _listongoingfuture,var _listmytournamentfuture) {
    listupcommingfuture = _listupcommingfuture;
    listongoingfuture = _listongoingfuture;
        listmytournamentfuture = _listmytournamentfuture;

    notifyListeners();
  }
}
