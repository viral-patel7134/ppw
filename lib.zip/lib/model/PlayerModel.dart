import 'package:flutter/material.dart';
import 'package:proplayerwar/model/FriendModel.dart';

class PlayerModel extends ChangeNotifier {
  List<FriendModel> teamdata;

  void refreshPlayer(var _teamdata) {
    teamdata = _teamdata;

    notifyListeners();
  }
}
