class LoginModel {
  var id,
      userId,
      name,
      email,
      phoneNo,
      facebookId,
      twitterId,
      level,
      city,
      country,
      profilePic,
      vipStatus,
      userType;

  LoginModel(
      {this.name,
      this.profilePic,
      this.userId,
      this.id,
      this.country,
      this.level,
      this.email,
      this.city,
      this.facebookId,
      this.phoneNo,
      this.twitterId,
      this.userType,
      this.vipStatus});
}
