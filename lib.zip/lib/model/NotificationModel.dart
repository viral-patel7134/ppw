import 'package:flutter/material.dart';


class NotificationModel extends ChangeNotifier {
  List teamdata;

  void refreshPlayer(var _teamdata) {
    teamdata = _teamdata;
print('_teamdata' + _teamdata.toString());
    notifyListeners();
  }
}
